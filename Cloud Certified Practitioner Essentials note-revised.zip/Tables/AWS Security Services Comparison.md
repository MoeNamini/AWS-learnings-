---
type: Table
title: AWS Security Services Comparison
description: null
icon: null
tags: [CCP, AWS]
coverImage: null
---

| **Service Name**     | **Primary Function**                                           | **Key Focus (What it Looks For)**                                                                                                                                             | **Output / Action**                                                                                                                                   |
| :------------------- | :------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Amazon Inspector** | **Vulnerability Assessment** and **Compliance Checking**       | **Proactive security flaws** in resources, such as: * Vulnerable software versions (CVEs) * Unintended network exposure * Deviations from security best practices             | Produces a list of **security findings** prioritized by severity with recommendations on how to fix the code/configuration.                           |
| **Amazon GuardDuty** | **Intelligent Threat Detection** and **Continuous Monitoring** | **Active, Malicious Activity** and **Anomalous Behavior**, such as: * Compromised EC2 instances/credentials * Unauthorized API calls * Communication with known malicious IPs | Generates detailed **threat findings** in near real-time, often leading to automated responses via Lambda/EventBridge.                                |
| **Amazon Detective** | **Security Investigation** and **Root Cause Analysis**         | **Relationships and Historical Context** between resources, users, and findings over time to establish a timeline.                                                            | Creates **interactive visualizations** (using graph theory and ML) to uncover the *who, what, when, and how* of a security incident.                  |
| **AWS Security Hub** | **Centralized Security Posture Management** and **Compliance** | **Consolidation** and **Standardization** of security alerts (findings) from dozens of integrated services (including the three above).                                       | Provides a **single, unified dashboard** view of your overall security state, compliance checks, and prioritized **insights** (actionable groupings). |


### Notes


