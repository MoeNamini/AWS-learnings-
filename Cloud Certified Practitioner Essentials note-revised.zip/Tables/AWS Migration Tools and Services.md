---
type: Table
title: 'AWS Migration Tools and Services '
description: null
icon: null
tags: []
coverImage: null
---

| **Service Name**                            | **Primary Focus / Analogy**                                 | **Function in Migration Lifecycle**                                                                                                                          | **Key Benefit / Output**                                                                                                                       |
| :------------------------------------------ | :---------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------- |
| **Application Discovery Service (ADS)**     | **The Migration Detective** (Inventory & Mapping)           | **Discovery & Planning:** Gathers configuration, performance, and dependency details for on-premises servers and databases.                                  | **Comprehensive Snapshot** of on-premises inventory; generates a detailed **migration plan**.                                                  |
| **Migration Evaluator**                     | **The Moving Consultant** (Cost Assessment & Business Case) | **Assessment:** Analyzes the data collected by ADS to create a data-driven business case for AWS adoption.                                                   | Provides **projected cloud costs** and visibility into multiple cost-effective scenarios, including **licensing reuse** insights.              |
| **Migration Hub**                           | **The Command Center** (Orchestration & Tracking)           | **Centralized Control:** Provides a unified, single location to track the progress of the entire migration (discovery, assessment, planning, and execution). | Offers **prescriptive journey templates** and enables collaboration while providing a single view of **migration status**.                     |
| **Application Migration Service (AWS MGN)** | **The Expert Movers** (Execution & Replication)             | **Execution:** Automates the block-level **replication** of on-premises applications and servers to AWS EC2 with minimal downtime.                           | **Streamlined, Expedited Migration** with support for **modernizing** applications during the process, maintaining normal business operations. |


### Notes


