---
type: Table
title: Amazon RDS vs. Amazon Aurora
description: null
icon: null
tags: []
coverImage: null
---

| **Feature**           | **Amazon RDS**                                                                                                                                    | **Amazon Aurora**                                                                                                                      |
| :-------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------ | :------------------------------------------------------------------------------------------------------------------------------------- |
| **Primary Use Case**  | Traditional workloads, "Lift and shift" migrations, or when you need a specific database engine (e.g., SQL Server, Oracle).                       | Cloud-native, high-performance applications, SaaS platforms, and workloads requiring instant scaling and global reach.                 |
| **Architecture**      | **Traditional.** Similar to running a database on a server (EC2) but managed. Compute and storage are tied together.                              | **Cloud-Native.** Built from the ground up for the cloud. Compute and storage are **decoupled**, allowing them to scale independently. |
| **Database Engines**  | Supports **6 Engines:**  1. MySQL  2. PostgreSQL  3. MariaDB  4. Oracle  5. SQL Server  6. Amazon Aurora                                          | Supports **2 Engines:**  1. MySQL-compatible  2. PostgreSQL-compatible                                                                 |
| **Performance**       | **Good.** Faster than a standard EC2 installation but limited by traditional database bottlenecks.                                                | **High.** Up to **5x faster** than standard MySQL and **3x faster** than standard PostgreSQL.                                          |
| **Storage**           | **Manual/Semi-Auto.** You choose the size (e.g., 500 GB). It can auto-scale up to **64 TB**, but typically not down.                              | **Fully Automatic.** Scales up *and down* automatically in 10 GB increments up to **128 TB**. You pay only for what you use.           |
| **Availability**      | **Multi-AZ (Standby).** You must enable "Multi-AZ" to get a standby instance. If the primary fails, the standby takes over (60–120 sec failover). | **6 Copies by Default.** Automatically replicates data 6 times across 3 Availability Zones. Failover is faster (< 30 sec).             |
| **Read Replicas**     | **Up to 15.(some only 5)** Replication is asynchronous and relies on "binlogs," which can cause lag (delay) during heavy write traffic.           | **Up to 15.** Replication uses the shared storage layer, resulting in **very low lag** (typically single-digit milliseconds).          |
| **Cost Model**        | Generally **Cheaper** for stable, predictable, or smaller workloads.                                                                              | Generally **~20% Higher** base cost but can be more cost-effective for high-throughput workloads due to better performance efficiency. |
| **Serverless Option** | **No true serverless.** (Though RDS Proxy helps with connection management).                                                                      | **Aurora Serverless v2.** Instantly scales compute (CPU/RAM) up and down based on live demand without dropping connections.            |


### Notes


