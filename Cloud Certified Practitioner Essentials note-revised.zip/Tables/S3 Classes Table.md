---
type: Table
title: S3 Classes Table
description: null
icon: null
tags: [AWS, CCP]
coverImage: null
---

| **Storage Class**                      | **Primary Access Frequency**          | **Retrieval Speed**                       | **Ideal Use Case**                                                                                                                | **Minimum Storage Duration**        | **Availability/Durability**                                                     |
| :------------------------------------- | :------------------------------------ | :---------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------- | :---------------------------------- | :------------------------------------------------------------------------------ |
| **S3 Standard**                        | **Frequent** (Default)                | **Millisecond** (Fast)                    | Dynamic websites, content distribution, frequently accessed data.                                                                 | None                                | High (99.99% Avail. / 11 9s Dur.)                                               |
| **S3 Standard-IA** (Infrequent Access) | **Infrequent**                        | **Millisecond** (Fast)                    | Backups, disaster recovery files, data accessed less than once a month.                                                           | **30 days**                         | High                                                                            |
| **S3 Express One Zone**                | **Most Frequent** (Latency-Sensitive) | **Single-Digit Millisecond** (Ultra-Fast) | **High-performance computing (HPC), AI/ML training data, interactive data analytics, and real-time streaming.**                   | None                                | Durability within a **single AZ** (Data is *not* replicated across AZs).        |
| **S3 One Zone-IA**                     | **Infrequent**                        | **Millisecond** (Fast)                    | Secondary backups of data that can be easily recreated; cost-optimized when cross-AZ replication isn't needed.                    | **30 days**                         | Lower (**single AZ**)                                                           |
| **S3 Glacier Instant Retrieval**       | **Archival** (Accessed rarely)        | **Millisecond** (Fast)                    | Archives that require immediate, on-demand access (e.g., historical medical records).                                             | **90 days**                         | High                                                                            |
| **S3 Glacier Flexible Retrieval**      | **Archival** (Accessed very rarely)   | **Minutes to Hours** (Configurable)       | Long-term archives, media assets where retrieval can wait for a few hours.                                                        | **90 days**                         | High                                                                            |
| **S3 Glacier Deep Archive**            | **Archival** (Extremely rare access)  | **Hours** (12–48 hours)                   | Long-term regulatory compliance archives; lowest-cost storage option.                                                             | **180 days**                        | High                                                                            |
| **S3 Intelligent-Tiering**             | **Varies** (Unknown/Changing)         | **Millisecond** (Fast)                    | Data with unpredictable access patterns; automatically optimizes cost by moving data between tiers.                               | None (Small monitoring fee applies) | High                                                                            |
| **S3 Outposts**                        | **Frequent** (Local Access)           | **Millisecond** (Local Network Speed)     | **Workloads with local data residency requirements** or on-premises applications requiring high-throughput, local object storage. | None                                | Durability is **across devices/servers on your Outpost rack** (local redundancy |


### Notes


