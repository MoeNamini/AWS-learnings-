---
type: Table
title: 'AWS DataSync vs Transfer Family '
description: null
icon: null
tags: []
coverImage: null
---

| **Feature**        | **AWS DataSync**                                      | **AWS Transfer Family**                          |
| :----------------- | :---------------------------------------------------- | :----------------------------------------------- |
| **Primary Goal**   | **Automated Migration & Sync**                        | **Managed File Transfer (B2B)**                  |
| **Protocols**      | NFS, SMB, HDFS, S3, Azure Files, Google Cloud Storage | SFTP, FTPS, FTP, AS2                             |
| **Connectivity**   | Requires an **Agent** installed on-premises           | Provides a **Server Endpoint** (no agent needed) |
| **Target Storage** | S3, EFS, FSx (all types)                              | S3, EFS                                          |
| **Use Case**       | Migrating 100TB of data; nightly backups              | Third-party vendor uploading weekly invoices     |
| **Speed**          | Optimized for speed (up to 10x faster than rsync)     | Limited by the standard protocol used            |
| **Pricing**        | Per-GB transferred                                    | Hourly server charge + Per-GB transferred        |


### Notes


