---
type: Table
title: 'AWS Health vs CloudWatch vs CloudTrail '
description: null
icon: null
tags: [CCP, AWS]
coverImage: null
---

| **Feature**           | **AWS Health**                                                                                                        | **Amazon CloudWatch**                                                        | **AWS CloudTrail**                                                          |
| :-------------------- | :-------------------------------------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------- | :-------------------------------------------------------------------------- |
| **Focus**             | **The AWS Cloud** (Events/Changes/Health impacting *your* resources).                                                 | **Your Resources** (Performance, operational health, and metrics).           | **Your Account Activity** (API calls, user actions, and security auditing). |
| **Question Answered** | "Is the problem with **AWS** (e.g., a service degradation, scheduled maintenance) or is it with my application?"      | "Is my **application** (e.g., CPU, latency, errors) performing correctly?"   | "Who changed **what** in my account, and when did they do it?"              |
| **Scope**             | **Account-specific** and **Service-specific** events (e.g., "Your specific EC2 host needs maintenance next Tuesday"). | Collects metrics and logs from *your* applications and resources.            | Logs every API call made *by* or *on behalf of* your account.               |
| **Type of Event**     | Service incidents, planned lifecycle events (e.g., an RDS patch window), or scheduled maintenance.                    | CPU utilization threshold breaches, high latency, custom application errors. | User "Rudy" terminated an EC2 instance.                                     |
| **Latency**           | Near instant alerts, focused on *proactive* and *remediation guidance*.                                               | Near real-time (1-minute intervals) for operational monitoring.              | Delayed (typically minutes) for auditing and forensic analysis.             |


### Notes


