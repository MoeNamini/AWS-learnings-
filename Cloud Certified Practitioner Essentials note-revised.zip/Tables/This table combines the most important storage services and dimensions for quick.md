---
type: Table
title: This table combines the most important storage services and dimensions for quick differentiation.
description: null
icon: null
tags: [AWS, CCP]
coverImage: null
---

| **Service**              | **Primary Access Type** | **Persistence**       | **Target Workload**                                      | **Latency/Performance**                       | **Key Differentiator**                                                                                            |
| :----------------------- | :---------------------- | :-------------------- | :------------------------------------------------------- | :-------------------------------------------- | :---------------------------------------------------------------------------------------------------------------- |
| **Amazon S3**            | Object                  | Persistent            | Data Lakes, Backups, Web Assets, Archives                | Variable (ms for Standard, hours for Glacier) | **Massive scale, 11 9s Durability, accessed via HTTP URL.**                                                       |
| **S3 Express One Zone**  | Object                  | Persistent            | AI/ML, HPC, High-Performance Analytics                   | **Single-Digit Millisecond**                  | **Ultra-low latency** object storage in a single AZ.                                                              |
| **Amazon EBS**           | Block                   | Persistent            | Boot Volumes, Databases (e.g., MySQL, Oracle)            | **Sub-millisecond**                           | **Persistent, high-performance** block device for a **single** EC2 instance.                                      |
| **EC2 Instance Store**   | Block                   | **Non-Persistent**    | Caching, scratch files, temporary buffers                | **Lowest Latency**                            | Highest I/O speed, but **data is lost** upon instance stop/terminate.                                             |
| **Amazon EFS**           | File (NFS)              | Persistent            | Shared Linux applications, home directories              | **Single-digit millisecond**                  | **Serverless, elastic** file system that scales automatically and **shares** data across many instances.          |
| **Amazon FSx**           | File (Specialized)      | Persistent            | Windows apps (SMB), HPC (Lustre), Enterprise NAS (ONTAP) | **Sub-millisecond to low millisecond**        | Provides managed, **specialized file systems** with advanced features (AD integration, high parallel throughput). |
| **AWS Storage Gateway**  | Hybrid (Bridge)         | Persistent (in cloud) | On-premises file shares, tape backups, iSCSI volumes     | **Local Network Speed** (for cached data)     | **Appliance deployed on-premises** to cache and sync local applications with S3/EBS/FSx.                          |
| **AWS Elastic DR (DRS)** | Block (Replication)     | Persistent            | Disaster Recovery and Migration                          | **Seconds RPO / Minutes RTO**                 | Continuous replication of entire servers (OS and data) to a **low-cost staging area** in the cloud.               |


### Notes



[💡 Five AWS Storage Scenarios](../Pages/%F0%9F%92%A1%20Five%20AWS%20Storage%20Scenarios.md)


AnyCompany Marketing needs to migrate their existing file shares to AWS to support their design teams who work with large creative files. They need help choosing a storage solution that can facilitate this migration.

The solution needs to meet the following requirements:

- Provide a fully managed service.

- Seamlessly integrate with Windows applications.

- Support SMB protocol.

- Offer Active Directory integration for user authentication.

- Support data deduplication to optimize storage costs.

- Provide consistent sub-millisecond latencies.

- Provide high availability.

Which AWS storage service BEST meets the requirements described in the scenario?

Amazon S3

Amazon FSx for Windows File Server

Amazon Elastic File System (Amazon EFS)

Amazon Storage Gateway




This comparison table summarizes the AWS data storage options, drawing details from the previous mind map response and the provided source material, including detailed information about specific database services like Amazon Aurora and DynamoDB.

## AWS Data Storage Options Comparison Table

[aws storages - NotebokkLM](./aws%20storages%20-%20NotebokkLM.md)
