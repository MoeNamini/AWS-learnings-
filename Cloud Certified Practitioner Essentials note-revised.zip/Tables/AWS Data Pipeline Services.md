---
type: Table
title: AWS Data Pipeline Services
description: null
icon: null
tags: [CCP, AWS]
coverImage: null
---

| **Service**                    | **What It Is**                               | **Purpose**                                                 | **Core Features**                                                                             | **Most Important Use Case**                                                     | **Role in Data Pipeline**                                                     |
| :----------------------------- | :------------------------------------------- | :---------------------------------------------------------- | :-------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------ | :---------------------------------------------------------------------------- |
| **Kinesis Data Streams (KDS)** | Real-time streaming ingestion service        | Capture, buffer, and process streaming data in milliseconds | Sharded streams, low latency, real-time processing, consumer apps (Lambda, Kinesis Analytics) | Real-time data ingestion (IoT, logs, clickstreams)                              | **Ingest → Stream** raw real-time data                                        |
| **Kinesis Data Firehose**      | Fully managed delivery/ingestion pipeline    | Automatically load streaming data into destinations         | No coding, auto-scaling, format conversion (JSON → Parquet), compression                      | Send streaming data directly to S3/Redshift/OpenSearch without managing servers | **Ingest → Transform → Load** (streaming ETL to storage or analytics systems) |
| **AWS Glue**                   | ETL & data integration service               | Prepare, clean, transform, and move data                    | Serverless ETL jobs, Spark-based jobs, DataBrew (no-code), workflows                          | Data transformation and cleaning for analytics                                  | **Transform → Prepare** data for databases or data warehouses                 |
| **Glue Data Catalog**          | Central metadata store                       | Store table metadata + schemas                              | Schema registry, crawlers, integration with Athena/Redshift/EMR                               | Keep track of datasets across S3 and databases                                  | **Metadata layer** powering query engines like Athena & Redshift Spectrum     |
| **EMR (Elastic MapReduce)**    | Big data processing cluster                  | Large-scale processing using Hadoop/Spark/Hive              | Fully managed Spark clusters, scalable compute, customizable runtime                          | Petabyte-scale processing (ML training, ETL, batch processing)                  | **Heavy Transform & Compute** for big data workflows                          |
| **Athena**                     | Serverless SQL query engine                  | Run SQL queries directly on S3                              | No infrastructure, pay-per-query, integrates with Glue Catalog                                | Interactive queries on S3 data (CSV/JSON/Parquet)                               | **Query Layer** for data stored in S3                                         |
| **Redshift**                   | Cloud data warehouse                         | High-performance analytics for structured data              | MPP architecture, Redshift Spectrum, columnar storage                                         | BI analytics at scale, dashboards, complex joins                                | **Warehouse/Analytics Layer** (store structured, query-ready data)            |
| **QuickSight**                 | Business Intelligence (BI) dashboarding tool | Visualize data + share insights                             | Dashboards, ML insights, natural language querying (Q)                                        | Executive dashboards, KPIs, business reporting                                  | **Visualization Layer** consuming Redshift/Athena datasets                    |
| **OpenSearch**                 | Search engine + log analytics                | Index and search text/log data                              | Full-text search, log ingestion, dashboards, real-time analysis                               | Application search, log analytics (ELK alternative)                             | **Search/Observability Layer** — analyze logs & semi-structured data          |


### Notes

# **One-Sentence “If I’m a PM, What Should I Remember?”**

- **Kinesis Streams** → Real-time data in.

- **Kinesis Firehose** → Stream → Destination automatically.

- **Glue** → Clean/transform data.

- **Glue Catalog** → Metadata so other tools know the schema.

- **EMR** → Heavy big data processing.

- **Athena** → SQL directly on S3.

- **Redshift** → Data warehouse for analytics.

- **QuickSight** → BI dashboards.

- **OpenSearch** → Fast search and log analytics.

