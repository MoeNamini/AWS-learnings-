---
type: Table
title: EBS vs EFS comparison table
description: null
icon: null
tags: [AWS, CCP]
coverImage: null
---

| **Feature**            | **Amazon Elastic Block Store (EBS)**                                                                                         | **Amazon Elastic File System (EFS)**                                                                                                  |
| :--------------------- | :--------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------ |
| **Storage Type**       | **Block Storage** (raw, unformatted volumes)                                                                                 | **File Storage** (NFS protocol-based file system)                                                                                     |
| **Access Protocol**    | Accessed via **Storage Area Network (SAN)** protocols. Appears to the OS as a traditional hard drive.                        | Accessed via the **NFS (Network File System) protocol**.                                                                              |
| **Concurrent Access**  | **No.** Can be attached to **only one** EC2 instance at a time (except for Multi-Attach on specific volume types).           | **Yes.** Can be mounted and accessed concurrently by **hundreds or thousands** of EC2 instances, Lambda functions, or ECS tasks.      |
| **Geographic Scope**   | **Zonal.** A volume exists within a **single Availability Zone (AZ)** and can only be attached to instances in that same AZ. | **Regional.** The file system spans **all Availability Zones** within a Region, allowing multi-AZ access.                             |
| **Capacity & Scaling** | **Fixed Capacity.** You provision a specific size (e.g., 500 GiB). To increase size, you must modify the volume.             | **Elastic/Automatic Scaling.** Grows and shrinks automatically as you add and remove files. Virtually unlimited capacity (petabytes). |
| **Performance Unit**   | Measured by **IOPS** (Input/Output Operations Per Second) and **Throughput** (MB/s).                                         | Measured by **Throughput** (MB/s) and scales with the size of the file system (or provisioned).                                       |
| **Ideal Use Case**     | **Boot Volumes** (OS), **Databases** (MySQL, PostgreSQL), single-instance applications requiring low latency.                | **Shared Storage**, content repositories, web serving content, development environments, and home directories.                        |
| **Mounting**           | Appears as a standard device to the OS (e.g., `/dev/sdc`). Requires formatting and mounting.                                 | Mounted as a **network file share** using a Mount Target in each AZ.                                                                  |
| **Cost Basis**         | Charged based on the **provisioned size** (GB/month) and the **provisioned performance** (IOPS/Throughput).                  | Charged based on the **average usage** (GB/month) and the access tier (Standard or Infrequent Access).                                |


### Notes


