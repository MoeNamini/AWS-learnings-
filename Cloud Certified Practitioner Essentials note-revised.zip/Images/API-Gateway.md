---
type: Image
title: API-Gateway
description: null
createdAt: '2025-12-03T07:15:55.985Z'
creationDate: 2025-12-03 10:45
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 15507
width: 512
height: 512
---


Media: ![Image](./Media/API-Gateway.png)


