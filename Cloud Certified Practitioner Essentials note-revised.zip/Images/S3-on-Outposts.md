---
type: Image
title: S3-on-Outposts
description: null
createdAt: '2025-12-04T14:13:36.158Z'
creationDate: 2025-12-04 17:43
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 13270
width: 512
height: 512
---


Media: ![Image](./Media/S3-on-Outposts.png)


