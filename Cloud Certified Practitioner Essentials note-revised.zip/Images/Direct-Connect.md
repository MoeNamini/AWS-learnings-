---
type: Image
title: Direct-Connect
description: null
createdAt: '2025-12-02T20:33:07.991Z'
creationDate: 2025-12-03 00:03
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 15333
width: 512
height: 512
---


Media: ![Image](./Media/Direct-Connect.png)


