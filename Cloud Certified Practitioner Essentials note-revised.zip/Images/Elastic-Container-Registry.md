---
type: Image
title: Elastic-Container-Registry
description: null
createdAt: '2025-11-24T09:28:25.616Z'
creationDate: 2025-11-24 12:58
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 14506
width: 512
height: 512
---


Media: ![Image](./Media/Elastic-Container-Registry.png)


