---
type: Image
title: Transit-Gateway
description: null
createdAt: '2025-12-03T07:17:16.373Z'
creationDate: 2025-12-03 10:47
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 17591
width: 512
height: 512
---


Media: ![Image](./Media/Transit-Gateway.png)


