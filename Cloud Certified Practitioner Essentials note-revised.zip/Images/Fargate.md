---
type: Image
title: Fargate
description: null
createdAt: '2025-11-24T09:29:46.801Z'
creationDate: 2025-11-24 12:59
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 15034
width: 512
height: 512
---


Media: ![Image](./Media/Fargate.png)


