---
type: Image
title: Aurora
description: null
createdAt: '2025-12-04T20:22:59.034Z'
creationDate: 2025-12-04 23:52
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 16136
width: 512
height: 512
---


Media: ![Image](./Media/Aurora.png)


