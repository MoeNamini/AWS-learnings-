---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:09:08.075Z'
creationDate: 2025-11-11 13:39
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 306386
width: 1680
height: 875
---


Media: ![Image](./Media/image%20(12).png)


