---
type: Image
title: Resource-Access-Manager
description: null
createdAt: '2025-11-23T08:59:33.705Z'
creationDate: 2025-11-23 12:29
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 15869
width: 512
height: 512
---


Media: ![Image](./Media/Resource-Access-Manager.png)


