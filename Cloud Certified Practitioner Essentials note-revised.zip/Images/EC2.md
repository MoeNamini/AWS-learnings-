---
type: Image
title: EC2
description: null
createdAt: '2025-12-01T12:19:33.457Z'
creationDate: 2025-12-01 15:49
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 12136
width: 512
height: 512
---


Media: ![Image](./Media/EC2.png)


