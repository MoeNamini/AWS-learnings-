---
type: Image
title: EventBridge
description: null
createdAt: '2025-12-01T20:04:40.269Z'
creationDate: 2025-12-01 23:34
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 16878
width: 512
height: 512
---


Media: ![Image](./Media/EventBridge.png)


