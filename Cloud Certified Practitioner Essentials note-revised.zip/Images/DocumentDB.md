---
type: Image
title: DocumentDB
description: null
createdAt: '2025-12-05T11:23:43.801Z'
creationDate: 2025-12-05 14:53
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 16170
width: 512
height: 512
---


Media: ![Image](./Media/DocumentDB.png)


