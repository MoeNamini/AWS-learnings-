---
type: Image
title: Storage-Gateway
description: null
createdAt: '2025-12-04T08:50:04.827Z'
creationDate: 2025-12-04 12:20
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 13751
width: 512
height: 512
---


Media: ![Image](./Media/Storage-Gateway.png)


