---
type: Image
title: Elastic-Disaster-Recovery
description: null
createdAt: '2025-12-04T08:50:30.352Z'
creationDate: 2025-12-04 12:20
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 12074
width: 512
height: 512
---


Media: ![Image](./Media/Elastic-Disaster-Recovery.png)


