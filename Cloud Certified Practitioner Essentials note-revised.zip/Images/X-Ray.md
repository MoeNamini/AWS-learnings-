---
type: Image
title: X-Ray
description: null
createdAt: '2025-11-19T18:19:04.127Z'
creationDate: 2025-11-19 21:49
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 15218
width: 512
height: 512
---


Media: ![Image](./Media/X-Ray.png)


