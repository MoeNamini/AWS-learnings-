---
type: Image
title: EMR
description: null
createdAt: '2025-12-05T12:16:16.477Z'
creationDate: 2025-12-05 15:46
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 17570
width: 512
height: 512
---


Media: ![Image](./Media/EMR.png)


