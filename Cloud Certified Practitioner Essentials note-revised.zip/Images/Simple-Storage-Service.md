---
type: Image
title: Simple-Storage-Service
description: null
createdAt: '2025-12-04T08:40:09.001Z'
creationDate: 2025-12-04 12:10
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 13495
width: 512
height: 512
---


Media: ![Image](./Media/Simple-Storage-Service.png)


