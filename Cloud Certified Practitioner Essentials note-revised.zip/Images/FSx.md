---
type: Image
title: FSx
description: null
createdAt: '2025-12-04T08:46:19.426Z'
creationDate: 2025-12-04 12:16
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 9595
width: 512
height: 512
---


Media: ![Image](./Media/FSx.png)


