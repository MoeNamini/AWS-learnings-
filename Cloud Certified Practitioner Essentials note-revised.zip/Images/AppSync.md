---
type: Image
title: AppSync
description: null
createdAt: '2025-11-19T18:21:23.416Z'
creationDate: 2025-11-19 21:51
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 15222
width: 512
height: 512
---


Media: ![Image](./Media/AppSync.png)


