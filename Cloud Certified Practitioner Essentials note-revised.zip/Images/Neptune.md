---
type: Image
title: Neptune
description: null
createdAt: '2025-12-05T11:39:28.196Z'
creationDate: 2025-12-05 15:09
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 17431
width: 512
height: 512
---


Media: ![Image](./Media/Neptune.png)


