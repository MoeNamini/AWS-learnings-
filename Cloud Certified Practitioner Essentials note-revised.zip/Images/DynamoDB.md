---
type: Image
title: DynamoDB
description: null
createdAt: '2025-12-04T20:56:36.037Z'
creationDate: 2025-12-05 00:26
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 18691
width: 512
height: 512
---


Media: ![Image](./Media/DynamoDB.png)


