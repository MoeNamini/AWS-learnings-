---
type: Image
title: Amplify
description: null
createdAt: '2025-11-19T18:22:35.663Z'
creationDate: 2025-11-19 21:52
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 14594
width: 512
height: 512
---


Media: ![Image](./Media/Amplify.png)


