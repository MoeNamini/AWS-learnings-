---
type: Image
title: image
description: null
createdAt: '2025-11-18T10:56:25.563Z'
creationDate: 2025-11-18 14:26
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 12843
width: 479
height: 479
---


Media: ![Image](./Media/image%20(92).png)


