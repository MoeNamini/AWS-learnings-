---
type: Image
title: Elastic-Block-Store
description: null
createdAt: '2025-12-04T08:37:15.921Z'
creationDate: 2025-12-04 12:07
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 10153
width: 512
height: 512
---


Media: ![Image](./Media/Elastic-Block-Store.png)


