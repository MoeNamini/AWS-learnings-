---
type: Image
title: image
description: null
createdAt: '2025-11-19T13:30:51.863Z'
creationDate: 2025-11-19 17:00
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 10013
width: 479
height: 479
---


Media: ![Image](./Media/image%20(109).png)


