---
type: Image
title: image
description: null
createdAt: '2025-11-19T09:53:56.934Z'
creationDate: 2025-11-19 13:23
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 14525
width: 479
height: 479
---


Media: ![Image](./Media/image%20(103).png)


