---
type: Concept
title: AWS Data Pipeline(s)
modificationDate: 2025-12-09 19:57
tags: [AWS, CCP, workflow]
relatedProject: [Cloud Certified Practitioner Essentials note]
relatedIdeas: [AWS Workflows]
---

# AWS Data Services — One‑Page Cheat Sheet + Diagram + Practice Questions

> Compact, exam‑focused reference for: Kinesis Data Streams, Kinesis Data Firehose, AWS Glue, Glue Data Catalog, EMR, Athena, Redshift, QuickSight, OpenSearch.

---

## 1) One‑Page Cheat Sheet (fast facts)

- **Kinesis Data Streams (KDS)**

    - **What:** Real‑time streaming ingestion (sharded streams).

    - **Purpose:** Capture & buffer high‑throughput event streams with millisecond latency.

    - **Core features:** Shards, producers/consumers, retention window, ordering per shard.

    - **Primary use case:** Clickstreams, IoT telemetry, real‑time analytics pipelines.

    - **Pipeline role:** *Ingest → Stream* (raw events into processing layer).

- **Kinesis Data Firehose**

    - **What:** Managed streaming delivery service (serverless ETL for streams).

    - **Purpose:** Deliver streaming data to destinations (S3, Redshift, OpenSearch, Splunk) with optional transformation.

    - **Core features:** Auto scaling, format conversion (JSON→Parquet/ORC), buffering, retry/delivery guarantees.

    - **Primary use case:** Load streaming logs/events into S3 or analytics stores with minimal code.

    - **Pipeline role:** *Ingest → Transform → Load* (streaming ETL/ingest to storage/analytics).

- **AWS Glue (ETL)**

    - **What:** Serverless ETL and data integration service (Spark under the hood).

    - **Purpose:** Clean, transform, catalog, and move data for analytics.

    - **Core features:** Glue Jobs (Spark), Glue Studio, DataBrew (no‑code), crawlers, triggers, job bookmarks.

    - **Primary use case:** Batch ETL to prepare data for analytics and warehousing.

    - **Pipeline role:** *Transform / Prepare* data (batch/stream integration with Glue streaming jobs).

- **Glue Data Catalog**

    - **What:** Central metadata store for datasets (table definitions, schema, partitions).

    - **Purpose:** Provide schema and table metadata to query engines and ETL jobs.

    - **Core features:** Crawlers, table metadata, schema versions, integration with Athena/Redshift Spectrum/EMR.

    - **Primary use case:** Single source of truth for dataset schemas and partitions on S3.

    - **Pipeline role:** *Metadata layer* (enables discovery & SQL queries without manual schema management).

- **EMR (Elastic MapReduce)**

    - **What:** Managed big data cluster service (Hadoop, Spark, Hive, Presto, etc.).

    - **Purpose:** Large‑scale batch processing, advanced analytics, machine learning at scale.

    - **Core features:** Customizable clusters, spot/EC2/EMR‑serverless, HDFS/EBS, support for Spark/Hive/HBase.

    - **Primary use case:** Petabyte ETL, complex transformations, iterative ML training.

    - **Pipeline role:** *Heavy transform & compute* (large batch jobs and custom big data workloads).

- **Amazon Athena**

    - **What:** Serverless interactive SQL engine for S3 (presto/Trino under the hood).

    - **Purpose:** Query data in S3 directly using SQL without provisioning servers.

    - **Core features:** Pay‑per‑query, integrates with Glue Catalog, supports Parquet/ORC/CSV/JSON.

    - **Primary use case:** Ad‑hoc analytics, quick exploration of S3 datasets.

    - **Pipeline role:** *Query layer* (ad‑hoc or scheduled queries on data lake storage).

- **Amazon Redshift**

    - **What:** Cloud data warehouse (MPP columnar analytics engine).

    - **Purpose:** High‑performance analytics on structured data, complex joins, BI workloads.

    - **Core features:** Columnar storage, sort/dist keys, Redshift Spectrum (query S3), concurrency scaling.

    - **Primary use case:** Enterprise BI and dashboard backends, complex reporting at scale.

    - **Pipeline role:** *Warehouse / analytics store* (served to BI and reporting tools).

- **Amazon QuickSight**

    - **What:** Managed Business Intelligence (BI) and dashboarding service.

    - **Purpose:** Visualize datasets, build dashboards, share insights; supports natural language Q (Q).

    - **Core features:** SPICE in‑memory engine, Q (NL query), ML insights (anomaly detection), scheduled reports.

    - **Primary use case:** Business dashboards for executives and analysts.

    - **Pipeline role:** *Visualization & consumption* (end‑user insights & reporting).

- **Amazon OpenSearch Service**

    - **What:** Managed search & analytics engine (Elasticsearch compatible) for text and logs.

    - **Purpose:** Full‑text search, observability (logs/metrics), app search and analytics.

    - **Core features:** Indexing, inverted indices, aggregations, real‑time dashboards (Kibana/OpenSearch Dashboards).

    - **Primary use case:** Log analytics (ELK style), application search, monitoring/alerting.

    - **Pipeline role:** *Search & observability layer* (index incoming logs/events for fast search and analytics).

---

## 2) Diagram — Storage vs Analytics vs ETL vs Streaming

```text
STREAMING                BATCH
                 (real‑time)              (scheduled / ad‑hoc)

 PRODUCE
 events/logs/metrics
    │
    ▼
 [Kinesis Data Streams]  <--->  real‑time consumers (Lambda, KDA, KDS apps)
    │
    ▼  (optionally)
 [Kinesis Data Firehose] ----> Destinations: S3 (lake), OpenSearch (logs), Redshift (analytics), Splunk
    │
    ▼
  S3 (Data Lake)  <--------------------------
    │                                         \
    │                                          \
    ▼                                           ▼
 [Glue / EMR]  (ETL/transform)           [Glue Catalog]  (metadata)
    │                                           │
    ▼                                           ▼
  Transformed datasets (Parquet/ORC)  --------> Query engines: Athena (serverless), Redshift Spectrum
                                              
    ▼
 [Redshift]  (data warehouse for BI)  ---> [QuickSight]  (dashboards & NL Q)
    

 Parallel path for logs/search:
 Raw logs/events -> Firehose -> OpenSearch -> Dashboards + alerting (observability)

 Role summary:
 - Streaming: Kinesis Data Streams / Firehose
 - Storage (lake): S3
 - ETL / Heavy compute: Glue, EMR
 - Metadata: Glue Data Catalog
 - Query engines: Athena, Redshift (plus Spectrum)
 - Visualization: QuickSight
 - Search/Observability: OpenSearch
```

---

## 3) The Decision Checklist: Do I need KDS?

You can decide if you need **Kinesis Data Streams (KDS)** by asking a few simple questions about your timing and consumers.

If you answer **YES** to any of these, you **NEED** KDS:

- [ ] **Is your source DynamoDB?** (DynamoDB Streams cannot talk directly to Firehose).

- [ ] **Do you need sub-second latency?** (Firehose has a minimum ~60s delay; KDS is ~70ms).

- [ ] **Do you have multiple** ***different*** **apps that need to read the same data simultaneously?** (e.g., one app for a live dashboard, another for archiving).

- [ ] **Do you need to "replay" data?** (e.g., "The system crashed; let's re-process the last 4 hours of data." Firehose cannot do this; KDS stores data for days).

If you answered **NO** to all of them, you likely **DO NOT** need KDS. You can simply use **Data Firehose** to save money and complexity.

### Common Pipeline Architectures

Here is how the architecture changes based on your destination and use case:

#### 1. Destination: Redshift (BI & Reporting)

- **Goal:** Load logs or event data into Redshift for querying.

- **Recommended Pipeline:** `Source` $\rightarrow$ `Data Firehose` $\rightarrow$ `S3` $\rightarrow$ `Redshift`

- **Why NOT use KDS?** You don't need real-time streams for Redshift. Firehose automatically batches the data, converts it to a friendly format (like Parquet), saves it to S3, and triggers the Redshift `COPY` command for you. Adding KDS here just adds management overhead.

#### 2. Destination: S3 (Data Lake)

- **Goal:** Dump all raw data into a Data Lake for future analysis.

- **Recommended Pipeline:** `Source` $\rightarrow$ `Data Firehose` $\rightarrow$ `S3`

- **Why NOT use KDS?** Firehose is the "easy button" for S3. It handles buffering, compression, and encryption automatically. KDS would require you to write a custom script (Lambda or KCL) just to write the files to disk.

#### 3. Destination: EMR (Big Data Analytics)

- **Scenario A (Batch Processing):** You run a nightly report on yesterday's data.

    - **Pipeline:** `Source` $\rightarrow$ `Data Firehose` $\rightarrow$ `S3` ... *(later)* ... `EMR (Reads S3)`

    - **Verdict:** **No KDS.** EMR reads the files directly from S3.

- **Scenario B (Real-Time Streaming):** You need to update a fraud dashboard instantly using Apache Spark Streaming.

    - **Pipeline:** `Source` $\rightarrow$ `Kinesis Data Streams (KDS)` $\rightarrow$ `EMR (Spark Streaming)`

    - **Verdict:** **Use KDS.** EMR needs a continuous, open "pipe" to read from in real-time. Firehose closes the pipe every 60 seconds to make a file, which is too slow for stream processing.

#### 4. The "Fan-Out" (Complex Architecture)

- **Goal:** You want to archive data to S3 **AND** update a real-time leaderboard **AND** send an alert if a value is high.

- **Recommended Pipeline:**

    - Code snippet

        ```text
        graph LR
        A[Source] --> B(Kinesis Data Streams)
        B --> C[Lambda - Realtime Alerts]
        B --> D[EC2 App - Live Leaderboard]
        B --> E[Firehose]
        E --> F[S3 - Archive]
        ```

    ![image](../Images/Media/image%20(61).png)
    [image](../Images/image%20(61).md)

- **Why use KDS?** KDS acts as the **central hub**. It holds the data so that Firehose (for archiving), Lambda (for alerts), and EC2 (for the app) can all read the exact same data record at their own speed without interfering with each other.



---

## 4) Practice Exam‑Style Questions (10) — services in scope

> **Instructions:** For each question pick the best answer. Answers and brief explanations follow.

**Q1.** Which service is best suited to ingesting real‑time clickstream events with the requirement for millisecond latency and ordered delivery per shard?

- A) Kinesis Data Firehose

- B) Kinesis Data Streams

- C) Athena

- D) Redshift

**Q2.** You want to deliver streaming logs directly to S3 in Parquet format with automatic batching and retries — minimal custom code. Which service is the best choice?

- A) Kinesis Data Streams

- B) Kinesis Data Firehose

- C) EMR

- D) Athena

**Q3.** Which component stores table schemas and partition metadata so that Athena and EMR can discover data stored on S3?

- A) Redshift Spectrum

- B) Glue Data Catalog

- C) QuickSight

- D) Kinesis Data Streams

**Q4.** For large, petabyte‑scale batch ETL with custom Spark logic and full control over cluster config, which service should you pick?

- A) AWS Glue (serverless ETL)

- B) Athena

- C) EMR

- D) Kinesis Data Firehose

**Q5.** Which service lets you run ad‑hoc SQL queries directly on data in S3 without provisioning servers, and is billed per amount of data scanned?

- A) Redshift

- B) Athena

- C) Glue

- D) OpenSearch

**Q6.** You need a managed columnar analytics store for dashboards with high concurrency and complex joins — which is the best AWS service?

- A) Athena

- B) OpenSearch

- C) Redshift

- D) Kinesis Data Streams

**Q7.** Which service is primarily used for full‑text search and log analytics (fast text queries, aggregations, alerting)?

- A) QuickSight

- B) OpenSearch

- C) Kinesis Data Streams

- D) Glue

**Q8.** Which service would you choose to provide business users with interactive dashboards and natural language question‑and‑answer capability?

- A) QuickSight

- B) Athena

- C) Redshift

- D) EMR

**Q9.** Which two services would you combine to reliably ingest streaming logs and make them searchable with minimal management overhead?

- A) Kinesis Data Streams + Redshift

- B) Kinesis Data Firehose + OpenSearch

- C) Athena + Glue

- D) EMR + QuickSight

**Q10.** What is the correct role of Glue in a typical data pipeline?

- A) Primary storage for raw data

- B) Metadata catalog only

- C) ETL / data transformation and orchestration (can use catalog)

- D) Visualization engine

---

### Answers & Explanations

1. **B — Kinesis Data Streams.** Streams give low latency, ordering per shard, and consumer apps.

2. **B — Kinesis Data Firehose.** Firehose is designed to deliver streaming data to S3 with format conversion and retries, no servers.

3. **B — Glue Data Catalog.** Central metadata store used by Athena, EMR, Redshift Spectrum.

4. **C — EMR.** For full control and large Spark/Hadoop clusters EMR is the fit; Glue is serverless Spark for many ETL needs but is less cluster‑configurable.

5. **B — Athena.** Serverless SQL on S3, pay per TB scanned.

6. **C — Redshift.** Designed for high‑performance analytical queries, complex joins, and supporting BI tools.

7. **B — OpenSearch.** Designed for search, log analytics, and observability.

8. **A — QuickSight.** BI tool with dashboards and natural language Q capability (Q).

9. **B — Kinesis Data Firehose + OpenSearch.** Firehose can deliver logs directly to OpenSearch for indexing and search with minimal management.

10. **C — ETL / data transformation and orchestration.** Glue runs ETL jobs and integrates with the Glue Data Catalog; it is not primary storage or a visualization tool.

---

If you want any edits (shorter, printable PDF layout, or a version with only flashcards and answers hidden), tell me which format and I’ll update the document.

