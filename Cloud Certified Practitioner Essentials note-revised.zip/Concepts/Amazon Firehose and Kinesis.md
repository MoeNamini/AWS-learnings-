---
type: Concept
title: Amazon Firehose and Kinesis
modificationDate: 2025-12-09 19:57
tags: [CCP, IT, AWS, Database]
relatedProject: [Cloud Certified Practitioner Essentials note]
relatedIdeas: [AWS Workflows]
---



| **Feature**              | **Kinesis Data Streams (KDS)**                                                                                                            | **Data Firehose**                                                                                                         |
| :----------------------- | :---------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------ |
| **Primary Goal**         | **Custom Processing & Real-Time Analytics**                                                                                               | **Automated Delivery & Loading**                                                                                          |
| **Latency**              | **Real-Time** (~70 ms with enhanced fan-out)                                                                                              | **Near Real-Time** (Lowest buffer is $\approx 60 \text{ seconds}$)                                                        |
| **Management & Scaling** | **Manual/Semi-Managed.** Requires manual **Shard Management** (provisioning, scaling, and scaling logic).                                 | **Fully Managed & Serverless.** Scales **automatically** to meet incoming data volume with zero administration.           |
| **Data Storage**         | **Built-in Storage.** Data persists for 24 hours (default), extendable up to 365 days.                                                    | **No Storage.** Data is immediately buffered and delivered; no built-in retention.                                        |
| **Data Consumers**       | **Open-Ended.** Supports **multiple consumers** reading the same data stream simultaneously (e.g., one consumer for Lambda, one for EMR). | **Closed-Ended.** Only delivers data to the **pre-configured destination** (one delivery stream = one main destination).  |
| **Data Transformation**  | Requires **custom code** in a consumer application (Lambda, KCL, Apache Flink).                                                           | Supports basic serverless transformations (format conversion to Parquet/ORC, compression, and optional Lambda functions). |
| **Pricing**              | Charged per **Shard Hour** and per **PUT Payload Unit** (more complex).                                                                   | Charged per **GB of data ingested** (simpler, pay-as-you-go).                                                             |

## Use Case Examples

### Kinesis Data Streams (KDS): The Custom Processor

Use KDS when you need maximum control, low latency, and the ability to process data with custom logic before it lands in storage.

- **Real-Time Dashboarding & Alerting:** Capturing financial transaction data or IoT sensor readings and immediately running custom code to identify anomalies or trigger an alert **within milliseconds**.

- **Complex Event Processing (CEP):** Consolidating clickstream data from a website, processing it with a custom application (using the Kinesis Client Library) to calculate complex user sessions, and then sending the derived data to multiple downstream systems concurrently.

- **Replay Capability:** Storing the raw stream data for up to a week to allow developers to re-run processing jobs or recover from application errors.

### Data Firehose: The Data Loader

Use Data Firehose when your main goal is simplicity, serverless scaling, and reliability in dumping streaming data into a permanent data store with minimal processing.

- **Log Ingestion to S3 Data Lake:** Streaming large volumes of application logs, network logs (like AWS WAF), or clickstream data directly into **Amazon S3** for long-term storage and subsequent analysis with **Athena** or **Redshift Spectrum**.

- **BI & Search Analytics:** Loading clean, pre-processed data streams directly into an analytics store like **Amazon Redshift** or **Amazon OpenSearch Service** (Elasticsearch) for immediate business intelligence (BI) reports.

- **Automated Format Conversion:** Automatically converting incoming JSON logs into the more efficient **Apache Parquet** format before saving them to S3, without writing a single line of ETL code.



## What Does Kinesis Data Streams Do? 

**The Missing Piece: DynamoDB Can't Talk Directly to Firehose!**

Think of it like this:

- **DynamoDB** speaks "Database language"

- **Firehose** speaks "Streaming data language"

- **Kinesis Data Streams** = The translator between them!

### The Real Problem:

**DynamoDB Streams** (DynamoDB's change log feature) captures every change:

- Customer added item to cart → DynamoDB records it

- Customer updated profile → DynamoDB records it

- But DynamoDB Streams **can't send directly to Firehose**

**Kinesis Data Streams bridges this gap:**

1. Reads changes from DynamoDB Streams

2. Converts them into streaming format

3. Feeds them to Firehose in the format it expects

### Visual Analogy:

```text
DynamoDB → "I have changes!" 
   ↓
Kinesis Streams → "Let me repackage those for you"
   ↓
Firehose → "Perfect! Now I can aggregate and deliver!"
```

---

## What Does "Ingesting" Mean?

**Ingesting = The process of bringing/collecting data into your system**

Think of it like eating:

- **Ingesting food** = Putting food into your mouth and stomach

- **Ingesting data** = Pulling data from sources into your data pipeline

### In This Pipeline:

**"Data Ingestion"** specifically means:

- **Capturing** data changes from DynamoDB

- **Streaming** them through Kinesis

- **Delivering** them to S3 via Firehose

**It's the entry point** of your data pipeline - like the mouth is the entry point for food!

---

## Why This 3-Step Process?

| Step                | Purpose                  | Why Needed?                          |
| :------------------ | :----------------------- | :----------------------------------- |
| **DynamoDB**        | Store operational data   | Fast reads/writes for app            |
| **Kinesis Streams** | Capture & stream changes | Bridge between DynamoDB and Firehose |
| **Firehose**        | Aggregate & deliver      | Batch data efficiently to S3         |

**Without Kinesis:** DynamoDB → ❌ → Firehose (can't connect directly!)
**With Kinesis:** DynamoDB → ✅ Kinesis → ✅ Firehose (works perfectly!)

---

Now let me create a full architecture diagram for you:Perfect! I've created a complete architecture diagram with all components clearly labeled and explained. Here's the summary:

## Key Answers to Your Questions:

### **Why Do We Need Kinesis?**

**Simple answer:** DynamoDB and Firehose can't talk to each other directly! They speak different "languages."

**The relay race analogy:**

1. **DynamoDB** = Fast runner (handles app data)

2. **Kinesis Streams** = Middle runner (passes the baton)

3. **Firehose** = Final runner (delivers to S3)

**You can't skip the middle runner!** Without Kinesis, there's no connection.

---

### **What is "Ingesting" in This Context?**

**Ingesting = The process of pulling/collecting data into your pipeline**

**Think of it like a restaurant:**

- **Ingestion** = Food arriving in the kitchen (data flowing in)

- **Processing** = Cooking the food (transforming it)

- **Serving** = Delivering to diners (storing in S3 for use)

**In this pipeline:**

- Kinesis Streams **ingests** changes from DynamoDB

- Firehose **ingests** streaming data from Kinesis

- Then delivers to S3

---

### **The Complete Flow:**

Customer Action → DynamoDB → **Kinesis (Bridge)** → **Firehose (Aggregator)** → Lambda (Transformer) → S3 → Athena/SageMaker

Each component has a **specific job** that others can't do! 🎯

