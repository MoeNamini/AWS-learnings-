---
type: Concept
title: Access Controls + CI/CD
modificationDate: 2025-12-09 19:57
tags: [AWS, IT]
relatedProject: [Cloud Certified Practitioner Essentials note]
relatedIdeas: []
---

You've highlighted two of the most valuable capabilities of AWS Service Catalog: providing standardized access and accelerating development workflows.

Here are the detailed explanations for those two use cases:

---

## 1. Explanation of "Apply Access Controls"

In the context of AWS Service Catalog, "applying access controls" means ensuring that users can only launch specific, pre-approved cloud resources, and, critically, that the launched resources are constrained to use only the permissions and configurations defined by the administrator.

This capability works on two levels:

### A. Discovery and Launch Access (Who sees what?)

- **Mechanism:** Service Catalog uses **Portfolios** (collections of approved products) and integrates with **AWS IAM (Users, Groups, or Roles)**.

- **Simple Explanation:** An administrator creates separate Portfolios for different teams (e.g., "Web Team," "Data Science Team," "Interns"). They then link the appropriate IAM Groups to the corresponding Portfolios. A Data Scientist, for instance, is only granted access to the "Data Science Portfolio," where they can only **see and launch** approved products like "Secure SageMaker Notebook Instance" but cannot see the "Production Database Cluster."

### B. Provisioning Permissions (What they can launch?)

- **Mechanism:** **Launch Constraints** (IAM roles).

- **Simple Explanation:** When a user (e.g., a junior developer with minimal IAM permissions) launches a Service Catalog Product, they aren't using their own low-privileged role. Instead, Service Catalog **assumes an Administrator-defined IAM Role (the Launch Constraint)** to provision the resources. This means:

    1. The user only needs permission to *launch the product*.

    2. The product is always launched using the necessary, but **least-privileged**, administrative role, ensuring the resulting infrastructure is secure and compliant, even if the user tried to launch resources outside the scope of the approved product.

    That's a fantastic idea—let's make that part crystal clear.

    This concept is all about **delegating power safely** so low-level users can provision complex infrastructure without getting administrative rights.

    ### 🔑 Provision

    That part—**Provisioning Permissions**—is often called **"Launch Constraints,"** and it's the security magic behind Service Catalog.

    Here is the simple explanation:

    ### The Vending Machine Analogy

    Imagine your IT department wants to let you launch a secure, approved web server (an EC2 instance), but they **don't** want to give you the super-powerful permissions needed to launch *any* kind of server or change its security settings.

    1. **Your Permission (The User):** You have very weak permissions. Your only permission is to press a single button: **"Launch Web Server."** You cannot touch the actual AWS infrastructure controls.

    2. **The Administrator's Role (The Launch Constraint):** The administrator links that "Launch Web Server" button to a powerful, trusted **Robot Arm** behind the scenes. This Robot Arm is the only thing that actually has permission to create the EC2 instance, set the network firewall, and attach the compliant roles.

    3. **The Result:** When you press the button, the Service Catalog uses the Robot Arm's powerful permissions to build the server exactly as it was designed—safely and compliantly—but **your own weak permissions never left the launch button.**

    **The core idea is:** The user can initiate the request, but the provisioning power is safely delegated to an administrator-controlled role. This is known as **least-privilege security.**

---

## 2. Real-World Scenario: Accelerating CI/CD Provisioning

The use case **"accelerate provisioning of continuous integration and continuous delivery (CI/CD) pipelines"** is vital for large organizations that have multiple application teams.

### Scenario: The Standardization Challenge

A large enterprise has twenty different development teams, and each needs a dedicated, secure, and standardized CI/CD pipeline to deploy its application. The pipeline must adhere to corporate security policies:

1. Use **AWS CodePipeline** as the orchestrator.

2. Use **AWS CodeBuild** with a specified, hardened Docker image.

3. Store source code in a pre-configured **AWS CodeCommit** repository.

4. Use an **IAM Role** with restricted cross-account permissions for deployment.

### 🚀 Service Catalog Solution: The "Pipeline-as-a-Product"

The central Cloud Enablement team uses Service Catalog to create a single **Product** called **"Standard CI/CD Pipeline."**

| Step                          | How Service Catalog Accelerates It                                                                                                                                                                                                                                                                                        |
| :---------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Preparation** (The Old Way) | Every team would write their own CloudFormation/Terraform template, leading to 20 different, non-compliant, insecure pipeline configurations.                                                                                                                                                                             |
| **Product Definition**        | The Cloud Team creates a single, approved CloudFormation template defining all the required services (CodePipeline, CodeBuild, CodeCommit, IAM Roles) with all security guardrails built-in.                                                                                                                              |
| **Deployment**                | A developer simply goes to the Service Catalog console (or clicks a button in their internal portal). They select **"Standard CI/CD Pipeline,"** enter one parameter (the application name, e.g., `inventory-app`), and click **Launch.**                                                                                 |
| **Result** (The Acceleration) | The pipeline is provisioned in **minutes**—securely and consistently—without the developer needing to know the underlying AWS services, IAM policies, or CodeBuild configuration details. The developer is instantly ready to commit code, dramatically accelerating their time to market while ensuring full governance. |
