---
type: Page
title: '30 CCP-style exam questions - Security '
description: null
icon: null
createdAt: '2025-12-07T17:56:10.849Z'
creationDate: 2025-12-07 21:26
modificationDate: 2025-12-12 12:03
tags: [CCP, AWS]
coverImage: null
---

Got it — here are **30 CCP-style exam questions** about AWS security: **15 “normal”** (typical CCP difficulty) and **15 “hard”** (scenario / multi-step). Each question is multiple choice (one best answer). **Answers and short explanations follow each section** so you can self-test then check reasoning.

---

# Section A — 15 Normal Questions (CCP level)

**N1.** Which statement about the AWS root user is correct?
A. Use the root user for daily administrative tasks.
B. Root user has unlimited privileges and you should enable MFA and lock away its credentials.
C. Root user cannot be used to create IAM users.
D. Root user permissions are limited to billing only.

**N2.** By default, an IAM user in AWS has which permissions?
A. Full administrator permissions.
B. Read-only across all AWS services.
C. Deny all until you explicitly grant permissions.
D. Access to billing and IAM only.

**N3.** Which of the following best describes an IAM role?
A. A permanent user account for developers.
B. Temporary credentials assumed by services, applications, or federated users.
C. A password manager for IAM users.
D. A service that issues X.509 certificates.

**N4.** What does “least privilege” mean in IAM policy design?
A. Give full admin rights to everyone to avoid permission errors.
B. Grant users only the permissions they need to perform their job and no more.
C. Remove all permissions and rely on root for everything.
D. Grant all permissions but restrict by time.

**N5.** AWS Identity Center (formerly AWS SSO) is primarily used for:
A. Managing VPC networks.
B. Single Sign-On and federation to multiple AWS accounts and apps.
C. Storing encryption keys.
D. Performing network intrusion detection.

**N6.** Which service provides automatic, always-on DDoS protection at no extra cost?
A. AWS Shield Advanced
B. AWS WAF
C. AWS Shield Standard
D. AWS GuardDuty

**N7.** AWS WAF is best used to:
A. Encrypt S3 objects at rest.
B. Block web attacks such as SQL injection and XSS at Layer 7.
C. Replace Security Groups for VPC-level traffic filtering.
D. Rotate database credentials.

**N8.** A Security Group in AWS is:
A. A stateless packet filter applied at the subnet level.
B. A stateful virtual firewall that controls inbound and outbound traffic to instances.
C. A tool to manage IAM groups.
D. A DNS firewall.

**N9.** Which AWS service manages encryption keys used to encrypt data at rest?
A. ACM
B. Secrets Manager
C. KMS (Key Management Service)
D. Macie

**N10.** Which service issues and manages SSL/TLS certificates for your load balancers and websites?
A. KMS
B. ACM (AWS Certificate Manager)
C. Secrets Manager
D. GuardDuty

**N11.** Where should you store database credentials so they can be automatically rotated?
A. In an S3 object without encryption
B. In a text file on an EC2 instance
C. In AWS Secrets Manager
D. As a parameter in Route 53

**N12.** Amazon Macie is primarily used for:
A. Detecting vulnerabilities in EC2 AMIs.
B. Discovering and classifying sensitive data (like PII) in S3.
C. Managing IAM policies.
D. Blocking invalid HTTP requests.

**N13.** Which service continuously analyzes events and logs to detect suspicious activity and threats?
A. Inspector
B. GuardDuty
C. Security Hub
D. Detective

**N14.** AWS Inspector is used to:
A. Centrally manage security findings from other services.
B. Visualize event graphs and root cause.
C. Scan EC2 instances for vulnerabilities and misconfigurations.
D. Replace WAF for web filtering.

**N15.** Which service aggregates and presents security findings across multiple AWS services in a single dashboard?
A. Detective
B. GuardDuty
C. Security Hub
D. Inspector

---

### Answers & short explanations — Normal

1. **N1: B.** Root has full privileges; best practice is enable MFA and avoid daily use.

2. **N2: C.** IAM users have no permissions until granted (default deny).

3. **N3: B.** Roles provide temporary credentials for services, EC2 instance profiles, federated users.

4. **N4: B.** Least privilege = give only necessary permissions.

5. **N5: B.** Identity Center = SSO/federation across accounts/apps.

6. **N6: C.** Shield Standard is always-on and free; Advanced is paid with extra protections.

7. **N7: B.** WAF protects at Layer 7 (web app attacks).

8. **N8: B.** Security Groups are stateful virtual firewalls at instance/network interface level.

9. **N9: C.** KMS manages keys for encryption at rest.

10. **N10: B.** ACM issues/manages SSL/TLS certs for AWS services.

11. **N11: C.** Secrets Manager stores and can rotate credentials.

12. **N12: B.** Macie discovers/classifies sensitive data in S3.

13. **N13: B.** GuardDuty uses logs & ML to detect threats.

14. **N14: C.** Inspector scans EC2/ECR/etc. for vulnerabilities.

15. **N15: C.** Security Hub consolidates findings from many services.

---

# Section B — 15 Hard Questions (scenario-based, higher difficulty)

**H1.** Your organization enforces that the root user credentials must never be used and MFA is mandatory. Which of the following is the MOST secure operational control?
A. Delete the root user.
B. Store root credentials in Secrets Manager and rotate them monthly.
C. Remove root user password, enable MFA, and store root credentials offline in a secure vault with strict access controls.
D. Create an IAM user with AdministratorAccess and use that instead.

**H2.** A developer needs temporary access to upload objects to an S3 bucket for a CI job running on EC2 without embedding long-term credentials on the instance. Best practice approach:
A. Store access keys in a file on the EC2 instance.
B. Create an IAM user, place keys in Secrets Manager, and pull them from the EC2 instance.
C. Attach an IAM role to the EC2 instance with least-privilege S3 permissions.
D. Use the root user credentials for the EC2 job.

**H3.** You must allow employees to sign into all AWS accounts using corporate credentials (Okta). You also want centralized permission control and just-in-time access. Which service combination should you implement?
A. Create IAM users in each account and synchronize passwords.
B. Use Identity Center (AWS SSO) integrated with your corporate IdP (Okta) plus permission sets (least privilege).
C. Configure public key authentication for all users.
D. Share the same IAM user across accounts.

**H4.** A public web application receives Layer-7 attacks. You need to block SQL injection and rate-limit traffic from abusive IPs before it hits the application but still allow legitimate users. Which combination is best?
A. Security Group + Shield Standard
B. WAF (with rules for SQLi and rate limiting) in front of CloudFront or ALB + Shield Standard
C. KMS + ACM
D. GuardDuty + Inspector

**H5.** An S3 bucket contains sensitive PII. You need to detect if objects containing PII are accidentally stored there and alert the security team. Which service helps detect and classify PII in S3 and integrates with Security Hub?
A. Macie
B. GuardDuty
C. Inspector
D. WAF

**H6.** Your compliance team requires automatic rotation of RDS credentials used by an application. Which AWS service provides built-in rotation for database credentials and integrates with IAM/KMS?
A. SSM Parameter Store (unencrypted)
B. Secrets Manager (automatic rotation)
C. KMS (manages keys only)
D. ACM

**H7.** A compromised EC2 instance may perform reconnaissance by calling AWS APIs. Which service monitors AWS account activity (API calls) and can generate findings about unusual API behavior?
A. GuardDuty (using CloudTrail data)
B. WAF
C. KMS
D. Macie

**H8.** Inspector finds a set of vulnerable packages on an EC2 fleet. You want an automated workflow: collect findings, open tickets, and trigger remediation runbooks. Which AWS service should you use to centralize findings and orchestrate responses?
A. Security Hub to aggregate findings, AWS Systems Manager Automation for remediation, and SNS/ITSM for tickets.
B. KMS only.
C. ACM only.
D. WAF only.

**H9.** You need to give an external partner temporary access to a single S3 prefix in one account without creating an IAM user. The partner uses their own AWS account. Best solution:
A. Create an IAM user for the partner in your account.
B. Create an IAM role in your account that the partner can assume (cross-account role) with least privilege to the prefix.
C. Share root credentials.
D. Put the objects in a public S3 bucket.

**H10.** You suspect unusual lateral movement inside your VPC. You want a service that analyzes VPC flow logs, CloudTrail, and DNS logs to surface suspicious activity and provide root-cause graphs. Which service is the best fit?
A. AWS Detective
B. AWS Inspector
C. AWS WAF
D. Secrets Manager

**H11.** Your external web application uses a TLS cert from ACM attached to an Application Load Balancer. A compliance audit requires central rotation tracking and no private key export. Why is ACM a good choice?
A. ACM stores private keys centrally and allows exporting them to anyone.
B. ACM issues/manages certificates with automatic renewal and the private keys are not exportable when ACM-provided certs are used.
C. ACM cannot be used with ALB.
D. ACM only supports self-signed certs.

**H12.** A critical data breach detected by GuardDuty triggers an alert. To investigate further, you want an aggregated view of all security alerts across accounts and automate cross-account alert forwarding. Which AWS service is purpose-built for aggregating findings and enabling cross-account, cross-region views?
A. Security Hub
B. Inspector
C. ACM
D. KMS

**H13.** Your team wants to block suspicious IP addresses at the edge (CloudFront) globally and also log all blocked requests. Which services should you combine?
A. ACLs only on the VPC subnet.
B. AWS WAF (IP block list + managed rules) associated with CloudFront + log to S3 or Kinesis Data Firehose.
C. Security Groups + Inspector.
D. GuardDuty + Macie.

**H14.** You must ensure encryption of S3 objects at rest with a key you control and audit all key usage. Which services and features do you use?
A. Server-side encryption with S3-managed keys only (SSE-S3).
B. SSE-KMS using a KMS CMK (customer-managed key) with CloudTrail logging of KMS API calls.
C. Encrypt objects on the client only (no KMS).
D. Store objects unencrypted and rely on network controls.

**H15.** A developer requests the ability to read secrets from Secrets Manager but should NOT be able to list, delete, or change rotation. Which policy approach enforces least privilege?
A. Attach AdministratorAccess to the developer.
B. Grant an IAM policy allowing only `secretsmanager:GetSecretValue` on the specific secret resource and deny other secretsmanager actions.
C. Give access to all secrets in the account.
D. Store the secret in SSM Parameter Store (unencrypted) instead.

---

### Answers & brief explanations — Hard

**H1: C.** You can’t delete root. Best practice: remove root password or store offline and enable MFA; strict vault storage.
**H2: C.** Attach an instance role (instance profile) to EC2 with least-privilege S3 put permissions — no long-term keys.
**H3: B.** Identity Center + corporate IdP provides SSO/federation and centralized permission sets (just-in-time).
**H4: B.** WAF (SQLi rules + rate limiting) fronting CloudFront or ALB plus Shield Standard for DDoS protection.
**H5: A.** Macie discovers and classifies PII in S3 and integrates with Security Hub.
**H6: B.** Secrets Manager supports automatic rotation for RDS and integrates with KMS to encrypt secrets.
**H7: A.** GuardDuty analyzes CloudTrail and other logs to detect suspicious API activity.
**H8: A.** Use Security Hub to aggregate findings, then Systems Manager Automation (or Lambda/Step Functions) + SNS/ITSM to create tickets and remediate.
**H9: B.** Create a cross-account role that the partner can assume for a specific S3 prefix — no user needed.
**H10: A.** Detective builds visualizations/graphs from VPC flow, CloudTrail, DNS logs to investigate lateral movement.
**H11: B.** ACM issues and renews certs, and ACM-managed certs keep private keys non-exportable — good for compliance.
**H12: A.** Security Hub aggregates findings from GuardDuty, Inspector, Macie, etc., across accounts/regions.
**H13: B.** WAF associated with CloudFront blocks at edge; logs can be pushed to S3/Firehose for auditing.
**H14: B.** Use SSE-KMS with a customer-managed CMK and enable CloudTrail logging of KMS APIs for auditing.
**H15: B.** Grant only `GetSecretValue` on the specific resource (least privilege); deny or omit list/delete/rotate actions.

---

# How to use these

- Take the **normal 15** as warm-up; time yourself (about 1.5–2 minutes per question).

- Use the **hard 15** to practice multi-step, architecture and control reasoning — annotate which services appear in each solution.

- If you want, I can:

    - Turn these into a **printable PDF**,

    - Make a **flashcard deck** (Q → hide answer until reveal),

    - Generate **detailed explanations** and AWS console links for any question, or

    - Produce **15 more very-high intensity** (deep architecture / policy writing) questions.

Which output would you like next?

