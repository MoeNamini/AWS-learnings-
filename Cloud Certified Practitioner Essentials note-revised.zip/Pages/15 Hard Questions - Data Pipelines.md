---
type: Page
title: '15 Hard Questions - Data Pipelines '
description: null
icon: null
createdAt: '2025-12-07T17:49:05.850Z'
creationDate: 2025-12-07 21:19
modificationDate: 2025-12-12 12:03
tags: [CCP, AWS]
coverImage: null
---

Done — I removed the **15 advanced practice questions** from the canvas document and left the rest (diagrams, cheat sheet, mnemonics, etc.) intact.

Below are the **15 advanced practice questions** (medium→high intensity), provided separately as you requested. Answers are included at the end.

---

## Advanced Practice Questions (Q1–Q15)

**Q1.** A campaign analytics team must compute 1-minute tumbling window aggregates on clickstream events with exactly-once semantics. They also want to enrich events with user profile data stored in DynamoDB. Which architecture best satisfies latency, ordering, and enrichment requirements?
A. Kinesis Data Streams → Lambda consumer (updates DynamoDB per event) → write aggregates to DynamoDB
B. Kinesis Data Streams → Kinesis Data Analytics (Flink) with stateful joins to DynamoDB via lookup function → write results to S3
C. Firehose → S3 → Athena scheduled queries
D. Kinesis Data Streams → Firehose → Redshift

---

**Q2.** A security team wants to index CloudTrail logs for near real-time search and also run long-term forensic analytics. They need sub-second search of new logs and cost-efficient long-term storage. Choose the best hybrid architecture.
A. Firehose → OpenSearch for indexing; Firehose also archives raw logs to S3 (Parquet) for Athena/Glue
B. Kinesis Streams → EMR → Redshift
C. Firehose → S3 only, and use Athena for searching
D. S3 → OpenSearch via Glue

---

**Q3.** You have small JSON files in S3 with inconsistent schemas. Analysts want fast interactive SQL and predictable Athena performance. Which two-step transformation minimizes scan cost and schema issues?
A. Use Glue crawler then query raw JSON with Athena
B. Run Glue jobs to normalize schema and write Parquet partitioned files; register tables in Glue Catalog
C. Move data into Redshift using COPY of JSON files
D. Re-index into OpenSearch and query

---

**Q4.** A dataset requires complex graph processing and iterative ML training across many node-to-node shuffles. Which service is best suited to this workload?
A. Athena
B. EMR with Spark / Hadoop
C. Glue
D. Firehose

---

**Q5.** Your company uses Redshift for dashboards but wants to query colder historical partitions on S3 without copying data into Redshift. What feature enables this integration?
A. Redshift Spectrum
B. Redshift Snapshot Export
C. Athena Federated Query
D. Glue Streaming

---

**Q6.** A pipeline must transform streaming telemetry in Python, preserve ordering, and allow consumers to rewind processing to an earlier offset for reprocessing. Which service combination gives you the best control?
A. Kinesis Data Streams with consumer applications (KCL or enhanced fan-out) + custom checkpointing (e.g., DynamoDB offsets)
B. Firehose with Lambda transforms
C. Kinesis Analytics SQL only
D. SQS FIFO queues with Lambda

---

**Q7.** A data product team needs a serverless, discoverable metadata layer that integrates with Athena and EMR and supports schema versioning. They also want automated schema inference. Which combination is correct?
A. Glue Data Catalog + Glue Crawlers
B. Redshift Catalog + Glue Jobs
C. Athena internal catalog only
D. OpenSearch mappings

---

**Q8.** A BI team complains that QuickSight dashboards are slow when querying Redshift during peak hours. Which option reduces latency and protects Redshift concurrency without changing dashboards?
A. Move QuickSight to use Athena instead
B. Use QuickSight SPICE to import dataset into in-memory engine
C. Increase Redshift node count only
D. Re-write queries to use Glue

---

**Q9.** A compliance requirement mandates isolation of workloads on physical hosts due to licensing restrictions. Which EC2-level option gives you full host control and license visibility while still using EC2 for Redshift or EMR nodes?
A. Dedicated Hosts for EC2 instances backing your cluster
B. Spot Instances only
C. Savings Plans
D. Kinesis Data Streams

---

**Q10.** A data team wants low-cost, large-scale ad-hoc analytics. They have massive cold datasets on S3 and want pay-per-query. However, many SQLs scan whole files repeatedly. Which combined strategy is best to lower cost and improve performance?
A. Convert files to columnar Parquet + partition appropriately; use Glue Catalog; employ Athena with partition projection if needed
B. Move everything to Redshift and stop using Athena
C. Run EMR to precompute all views daily and store results only
D. Index everything into OpenSearch

---

**Q11.** You need to run Spark jobs that use a custom native library requiring privileged OS access. Which service offers the greatest control to install and run native dependencies on cluster nodes?
A. EMR (provisioned EC2 nodes)
B. Glue (serverless)
C. Athena
D. Firehose

---

**Q12.** An architecture currently uses Firehose → OpenSearch. During peaks, OpenSearch cluster is overwhelmed by indexing throughput causing throttling and increased latency. What mitigation is the best next step to absorb bursts and protect OpenSearch while maintaining near real-time indexing?
A. Add a buffering S3 stage: Firehose delivers to S3 and a separate worker batch-indexes to OpenSearch with backpressure controls.
B. Increase OpenSearch instance types immediately.
C. Switch Firehose to Kinesis Data Streams.
D. Stop ingesting logs during peak hours.

---

**Q13.** A data scientist wants to perform exploratory joins between a large S3 data lake and an operational RDS database without moving data. Which modern serverless tools can accomplish cross-source querying?
A. Athena with federated query connectors (for RDS)
B. Redshift COPY only
C. Glue ETL moving RDS to S3 first
D. OpenSearch cross-cluster search

---

**Q14.** A pipeline processes clickstream events and writes both to a real-time analytics dashboard (seconds latency) and a historical S3 data lake for batch ML. Which pattern is most efficient and cost-effective?
A. Producer → Kinesis Data Streams; one consumer = KDA/real-time dashboard; another consumer = Firehose to S3 (or KCL consumer that writes to Firehose)
B. Producer → Firehose only to S3; dashboards read S3 via Athena
C. Producer → direct PUT to Redshift and OpenSearch simultaneously
D. Producer → SQS → Lambda → write to S3 and OpenSearch

---

**Q15.** A company wants to run ML model training on a curated dataset in Redshift, but the training framework requires Spark on many nodes and GPU acceleration. What is a good approach?
A. Unload curated dataset from Redshift to S3 (Parquet), spin up EMR or SageMaker training cluster (GPU instances), and run distributed training on data in S3.
B. Run training inside Redshift using UDFs.
C. Stream data via Firehose to OpenSearch and train there.
D. Use Athena to train models directly.

---

## Answers (Q1–Q15)

1. **B**

2. **A**

3. **B**

4. **B**

5. **A**

6. **A**

7. **A**

8. **B**

9. **A**

10. **A**

11. **A**

12. **A**

13. **A**

14. **A**

15. **A**

---

Would you like these converted into a printable PDF, a spaced-repetition flashcard deck, or another 15 *very high* intensity questions?

