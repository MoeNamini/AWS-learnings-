---
type: Project
title: Cloud Certified Practitioner Essentials note
description: null
tags: [AWS, 4MonthPlan, CareerDevelopment, CCP]
status: null
timeFrame: null
collaborators: null
toDoLists: []
ideas: []
---



# Notes

# AWS Certified Cloud Practitioner Essentials

[AWS CCP Essentials suammary notes](./AWS%20CCP%20Essentials%20suammary%20notes.md)

[A MediVault EU - A realworld scenario](./A%20MediVault%20EU%20-%20A%20realworld%20scenario.md)


## Module 1 - Intorduction to the Cloud

### Introduction to AWS Cloud Practitioner Essentials

**Rudy:** Hey everyone! Welcome to the course. We hope you're ready to dive in and learn the fundamentals of the AWS cloud.

**Alan:** We have a lot of material to cover. And we're going to start with defining; what is the cloud?

**Morgan:** But, before we do that, let's start with some introductions. Hi, I'm Morgan Willis, a Principal Cloud Technologist with AWS Training and Certification. I started in the IT world about 15 years ago. And along the way, I decided that I was missing something.

I missed the helping and teaching aspect that I had in my first job in IT support. So, I went into teaching at a software development bootcamp. And then I eventually landed here at Amazon Web Services, or AWS, where, as a Cloud Technologist, I get to support others in their cloud learning journey every day.

**Rudy:** Howzit learners! My name is Rudy Chetty and I'm a Chief Techfluencer and a Principle Solutions Architect for AWS Partners. I'm originally from sunny Cape Town, South Africa…the home of bunny chow, biltong and boerewors. I've been in the technology space for over two decades helping customers worldwide realize their application and cloud dreams. Education is my passion. Therefore, I cannot wait for you to dive into this course and learn all about the wonders of the cloud and AWS.

**Alan:** And I'm Alan Meridian. I'm an instructor in AWS Training and Certification.

Over the last eight plus years with AWS, I've delivered hundreds of trainings introducing learners like you to AWS concepts, services, and solutions-sometimes involving ukuleles. I'm glad you're here. We're going to learn a lot together.

**Rudy:** Look, cloud computing can be complex. But don’t worry. This is why we’re here! Our curriculum provides analogies, examples, and use cases that will help you better understand these concepts. We’ll cover all the essential information you need to be comfortable discussing AWS. Additionally, we'll throw in some AWS service demos to show you how things work in action. This layered approach to learning will really reinforce concepts. Oh, and we promise to keep it simple.

**Morgan:** AWS offers a massive range of services for every business. AWS is the world's most comprehensive and broadly adopted cloud, and millions of customers use AWS to be more agile, lower costs, and innovate faster. Whether you're looking for compute power, generative AI, databases, storage, content delivery, or specialized services for some other functionality, AWS has the services you need to help you build sophisticated applications for your business.

**Alan:** That is massive range of services, and I wish we had time to cover them all. But, we did promise to keep it simple. So, let's start this conversation with a fundamental concept of computing: the client-server model.

**Rudy:** And to get things percolating in your brain, we are going to brew up a coffee shop analogy. This coffee shop is going to act as a real-world metaphor to show you the different parts of the cloud computing model. And, the analogy will help you understand how AWS can change the way your IT operates.

First, let's think about the coffee shop and how it can represent the client-server model.

**Alan:** Let's have Morgan be the server, the barista. And I'll be the client, or the customer. I'm gonna make a request. In this case, it's for coffee. In the computing world, the request could be for anything. It could be rain pattern analysis in South Africa, or it could be the latest x-rays of your knee, or videos of kittens. Whatever the business needs is where the request starts. Basically, a customer makes a request, and with permissions, the server responds to that request. All I want is a caffeinated beverage. Morgan represents the server part of the client-server model. In AWS, she would be a virtual server. So, from a cloud computing architectural point of view, the coffee shop transaction is pretty straightforward. I, the user, made a request to Morgan, the server. Morgan validated that the request was legitimate. In this case, did I give her money? Is the item that I ordered something that they can make? Then she returned a response, which in this example, is a triple mocha with extra caramel shots.

**Morgan:** Now, in the real world, applications are usually more complicated than just a single transaction with a single server. In a business solution that is more mature, it can get beautifully complex. But again, we're going to start with the basics. As the curriculum progresses, these basic concepts will continue to build on each other. And hopefully, by the end, those beautifully complex concepts will make a lot more sense. You've already tackled your first cloud computing concept. So now, let's continue with a key concept of AWS, and that is, you only pay for what you use.

**Rudy:** Think about this principle as it applies to staffing a coffee shop. Employees are only paid for the hours they work in the actual shop. So, if say Morgan and I are off the clock, well, then we don't get paid because we didn’t work any hours. Moreover, the store owner decides how many baristas they need for any given day of the week. Busy days require more employees and slower days require fewer. Let’s take an example. Say the coffee shop is releasing a brand-new drink called Rudy’s Rhubarb Refresher. Trademark. The shop anticipates increased demand due to the beverage being very tasty, so they staff the shop with 10 baristas all day long. Although this works with a sudden surge of customers, it isn’t great for slower periods during the day. Some baristas could be idle, and it would be hard to justify paying them to just be there in case they are needed. The monetary cost just doesn’t make good financial sense.

**Alan:** And yet, this is exactly what happens in an on-premises data center where you can't just snap your fingers and triple your capacity. At AWS, you don't pre-pay for anything. And you don't have to worry about capacity constraints.

**Rudy:** When you need more resources, you just provision them right then and there. How cool is that? Then, when you don't need those resources anymore, you can deprovision just as quickly. You just set up the right configuration and it’s done automatically. And the best part is that when you deprovision the resources, you stop paying for them immediately. Just like you only pay your employees for the hours they’re working, you only pay for the AWS resources that you consume.

**Morgan:** Right. So, paying only for what you use is the first AWS specific concept we covered—and it’s just one of the many benefits when it comes to running your business on AWS. And that's really why we're here: so you can understand how AWS is built to help you run your business better.

**Alan:** Exactly. You’ve already learned some foundational concepts about the cloud…and that’s just the start!

**Rudy:** Yep, things are only going to get more interesting, folks, as we dive deeper! Thanks for joining us on this learning journey, future AWS Cloud Practitioner. See you soon.

### What is Cloud Computing?

Before we dive into cloud computing, let's rewind the clock and set some context for how Amazon grew to include Amazon Web Services. In the early 2000s, Amazon.com was an ecommerce site that customers used to buy books and other consumer goods. As more people started to use the site, the Amazon IT team had to continually make upgrades to keep things running smoothly. More servers, more storage, more compute. You name it. They were deploying it!

The team eventually decided to develop various standardized tools, mechanisms, and ways to make things more efficient and scalable. These methods proved to be quite effective, and in 2003, employees thought, "Maybe this knowledge would be valuable to other companies facing similar challenges." Thus, Amazon started to envision a service that would allow businesses to rent computing power, storage, and other resources, on-demand. This business model could eliminate the need for upfront investment in hardware.

Just a year later, in November 2004, AWS launched its first public infrastructure service: Amazon **Simple Queue** **Service**. Two years later, AWS launched Amazon **Simple Storage** Service for data storage and Amazon **Elastic Compute Cloud** for scalable compute. Initially, AWS was used by smaller start-ups and developers. However, its scalability, cost-effectiveness, and ease of use quickly attracted larger enterprises.

Over the next few years, AWS rapidly expanded its offerings by adding **databases**, **networking**, **analytics**, and many other cloud-based services. Fast forward to the present. AWS powers a significant portion of the internet, serving millions of customers worldwide. From small start-ups and businesses, to large corporations, government agencies, and more. What started as an internal solution for Amazon's own IT needs has grown into a global cloud computing leader.

With that quick history lesson in mind, let's look at a working definition of cloud computing. Cloud computing is essentially the **on-demand delivery of IT resources** over the internet with **pay-as-you-go** pricing. Shall we break this down a bit? I think we shall. On demand means you use resources as needed. Let's say your business needs 2,000 TB of storage. Open an AWS account, throw some files into Amazon S3, and Bob’s your uncle. You're good to go. If you don't need to store those files anymore? Delete them, and stop paying immediately.

The idea of the delivery of these on-demand IT resources, as you learned, is the concept that got AWS started in the first place. Let's say you have an application that you have to run, content you need stored, or data you need analyzed. Basically, you have stuff that uses IT resources that have to live and operate somewhere. All of that data is stored in a data center, which is essentially a building or set of buildings devoted to housing servers that contain all this data. Data centers are designed with redundant power, cooling, and security measures to ensure secure and continuous operation. Historically, businesses would run applications in their own data centers or co-locate with other customers in a shared facility. There was no alternative. Once AWS became available, companies could now run their applications in other data centers they didn't actually own. No more infrastructure to manage. No more repetitive tasks and time-consuming ones--goodbye. By using AWS, teams could now focus on innovation.

Oh, and the over-the-internet part means you can access those resources remotely. You can be in your house, place of business, or visiting family around the world. Hi Mom! In fact, all you need is an internet connection. Log into your AWS Account and manage your infrastructure right from your web-browser.

And with pay-as-you-go pricing, if you don’t need a particular part of your infrastructure, just deprovision it. Simple as that. No contracts. No need to call a sales rep.

To reiterate: cloud computing is the on-demand delivery of IT resources over the internet with pay-as-you-go pricing. So, as you tackle the rest of this content, keep this definition in mind. Happy learning!

### Benefits of the Cloud

Okay. You have a good working definition of cloud computing, and you've also touched on why it's beneficial from a business perspective. Now, you'll learn even more about the advantages of using a cloud computing model. We'll cover six primary benefits of the AWS Cloud.

Let's start by talking a bit more about that first concept we've mentioned: the ability to pay as you go. With the cloud, you can trade fixed expenses for variable expenses. Remember when we talked about how data is housed in a data center? When you’re building a traditional on-premises facility, you typically need to invest a large amount of money **upfront**. This includes investments in physical space, hardware, staff, and upkeep to make sure everything is running smoothly. For some businesses, this can be hundreds of thousands or even millions of dollars. Then, regardless of the data center's utilization rate, you have a **fixed cost**, and you have to set up your budget around that fixed cost.

Billing with AWS is fundamentally different. Your bill with AWS will be variable from month to month as you consume different amounts of resources. The great thing about this model is that if you’re just getting started, there's no need to come up with a big investment to build out your AWS environment. Instead, you can start small and get **billed for only what you use.** And, you can use **built-in billing and budgeting tools** to find ways to save money every month as your business grows. So, that's the first advantage.

The next advantage is that you benefit from massive **economies of scale**. AWS is building data centers all around the world. And in order to build all those data centers, AWS is buying a whole lot of hardware. Because AWS buys a good amount of hardware, we can purchase this hardware at a lower price. Then, we pass on those lower costs to the customer.

The next benefit? **Stop guessing capacity**. In a traditional data center, you purchase hardware based on projected usage. Let's say you estimate you'll have a user base of 10 million people over the next three years. That means you purchase enough hardware to support that growth over time. But what happens if, when that third year hits, you only have about 500,000 users? You're still stuck with the hardware you purchased to support 10 million users. Let’s flip the script. Imagine you underestimated your capacity. A growing customer base is great for your business, but the scramble to secure more hardware could be a real problem. You would need to rapidly procure more servers to handle that higher capacity. If you don’t adjust in time, your customers could have a degraded experience, or you might even lose them altogether.

This is the awesome part of AWS. You don't need to guess capacity. **Scaling** usually takes minutes, instead of the weeks or months it can take in an on-premises data center. You provision needed resources for the present. Then, you use scaling mechanisms to **scale these resources up or down based on the day-to-day demand.**

The next benefit is my personal favorite. Increase speed and agility. With AWS, you have more bandwidth to try new things. You can spin up test environments and run experiments, trying out new ways to solve a problem. And then, if that approach didn't work, you can just delete those resources and stop incurring cost. That way, you can **spend less time provisioning and deprovisioning** and more time innovating and optimizing.

Alright, next up. Stop spending money running and maintaining data centers. We've talked about the upfront cost of data centers, but there's more to it than that. Apart from the fixed cost of what it takes to build out a data center, AWS eases the **cost of running and maintaining servers**. This means instead of spending time and resources focusing on racking, stacking, and powering those servers, you’re spending more time focusing on customers.

And last but not least, we have **go global in minutes**. Let's say you're a company based in the US, and you want to expand your operations to India. Traditionally, you would need to run and operate data centers in India to effectively operate there. But with AWS, you don't need to do that on your own. You can instead deploy your applications to an AWS Region in India that is managed by AWS. The idea here is that the time it takes for you to expand into a secondary area of the world traditionally can be months or years. With AWS, it can just take minutes.

That's it. Those are the six main benefits of using the AWS Cloud. As you can tell, with AWS, your business can achieve cost savings, time savings, and the ability to tap into massive global infrastructure. As we continue to dive into the specifics of the infrastructure and services of AWS, it'll become more and more clear how your business can achieve these benefits.

- No fixed cost, No upfront money

- Economic of scale 

- 

### Introduction to the AWS Global Infrastructure

Let's talk about the AWS Global Infrastructure. You've already learned that AWS builds and maintains data centers around the world that you can use to go global in minutes, but there's a huge advantage to global reach that we haven't covered yet—and that's high availability.

To learn a little bit more about high availability, let's head back to our coffee shop. Say you've hired a new employee, and they're learning how to make a latte. They're doing awesome. They've got the right milk-to-espresso ratio, and they are even making some cool designs with their latte pour—until they miss the cup and they pour the latte all over the register. That is not good. The register is now fried, and it seems like it shorted the electricity everywhere in the shop. Yikes! That means we can't ring up the orders or make drinks for our customers. We're gonna have to close up shop until this is sorted out.

So, what does that mean for the business? Does this mean that the entire business isn't making any money until this is fixed? Well, luckily for us, we're prepared. The good news for our business—and for our customers—is that this isn't our coffee shop's only location. The shop is actually a chain, and we have locations all around the city. Customers can still get their coffee by visiting one of our shops just a few blocks away, and the business can continue even if one location is having a bad time.

So, whether an employee had a slight latte mishap, or a shop next door accidentally cut our internet line, or some other disaster keeps the shop from its day-to-day operations...no matter the reason, we know that our product will be highly available for our customers. They still get their coffee, and the business is still generating income. All is well.

AWS has a similar set up with our global infrastructure. It's risky to have one giant data center where all of the resources are housed. If something were to happen to that data center, like a power outage or a natural disaster, everyone's applications would go down all at once. You need high availability and fault tolerance. Let’s clarify those terms. High availability is all about making sure your applications stay accessible with minimal downtime. Even if one component fails, another is ready to pick up the slack so your service keeps running.

Fault tolerance takes it a step further by designing a system to continue to operate even if multiple components fail. It’s basically building resilience into every layer so that no one single failure brings down the whole system. Designing for high availability and fault tolerance is part of the reason why AWS operates in Regions, which are located in different areas around the world. These Regions are built to be as close to AWS customers as possible. This includes locations like Paris, Tokyo, Sao Paulo, Dublin, or Ohio.

Within each Region, we have what we call Availability Zones, or AZs. There are three or more AZs within a Region, for redundancy. We don't build AZs right next to each other, because if something like a natural disaster were to occur, you could lose connectivity to everything in that AZ. And continuing with the theme of redundancy, within each AZ, there is one or more discrete data centers with redundant power, networking, and connectivity.

So, if a Region is where all the pieces and parts of your application live, some of you might be thinking that we never actually solved the problem that we presented earlier. If my business needs to be disaster proof, then it can't run in just one location. Well, you're absolutely correct. That's why it's common for businesses to operate across multiple Regions. That way, if one Region is experiencing outages for any reason, the operations can failover to another Region...but we'll cover that in more depth in a later lesson.

In the meantime, I'm gonna sit back here and relax, because I know that my business is highly available regardless of any disasters...or spilled lattes.

### The AWS Shared Responsibility Model - [AWS Shared Responsibility Model - SRM](../Concepts/AWS%20Shared%20Responsibility%20Model%20-%20SRM.md)

When it comes to securing your business on AWS, it's important to ask the question: Who is ultimately responsible for the security? Is it A: You, the customer? or B: AWS? And the correct answer is: Yes. Both. Both are ultimately responsible for making sure that your workloads are secure.

This is what's known as the AWS Shared Responsibility Model. And it's similar to securing a house. The builder constructed the house with four walls and a door. It's their responsibility to make sure the walls are strong and the doors are solid. It's your responsibility as the homeowner to close and lock those doors. And it really is that straightforward on AWS as well.

One helpful way to think about it is that AWS is responsible for security of the cloud. The customer is responsible for security in the cloud. AWS is responsible for the physical, network, and hypervisor layers. The physical layer is just that: the physical realities of a computer. Access to the hardware has to be secured with locks on doors, access control lists, privilege separation, and a lot more. Similarly, the network layer and the hypervisor virtualization layer have their own protections to ensure isolation of the different AWS customer workloads.

Now let’s talk about customer responsibilities. You're 100 percent in charge of your operating system. AWS does not have a back door into your system here. You and you alone have the only encryption key to log in to this OS or to create any user accounts there. I mean, no more than a construction company would keep copies of your front door key, AWS cannot enter your operating system. That means your operations team is responsible for keeping the OS patched. If AWS discovers there are some new vulnerabilities in your version of the operating system, we can certainly notify your account owner, but we cannot deploy a patch. The construction company can install high quality locks to secure your home, but they aren’t going to come lock the door for you every time you leave.

Same goes for the applications you're running: You own them and you secure them. Which takes us to the next part of the stack: data. This is your domain to control. And sometimes you might want to have your data open for everyone to see, like pictures on a retail website. Other times, like banking or healthcare, yeah, not so much.

AWS provides everyone with the controls to open it up to some authorized individuals, to everyone, to just a single person under specific conditions, or even to lock it down so no one can access it. Plus, you have the ability to encrypt your data. That way even if you accidentally left your front door open, all anyone would see is unreadable encrypted content.

The AWS Shared Responsibility Model is about making sure both sides understand exactly which tasks are ours and which tasks are the customer’s. Depending on the service used, responsibility can shift, and we'll talk more about specifics as we come across different services.

Again, at a basic level, it's important to remember that AWS is responsible for the security of the cloud, and you are responsible for the security in the cloud. Together, you have an environment you can trust.

![image](../Images/Media/image%20(1).png)
[image](../Images/image%20(1).md)

![image](../Images/Media/image%20(2).png)
[image](../Images/image%20(2).md)

### Cloud in Real Life: Applying Cloud Concepts to Real Life Use Cases

**Morgan**: Hey everyone. Welcome to a segment of this training that we call Cloud in Real Life. Every once in a while, the three of us will come together, and take the concepts you've learned, and explore how they work in real-world, real-life scenarios.

**Rudy**: Exactly, so instead of just talking about features and definitions, we're going to think through how businesses or individuals might approach real-world problems.

**Alan**: And this is super important because this course is for anyone trying to learn about AWS, including beginners. So, we've purposefully simplified a lot of the AWS concepts to make them digestible for someone just getting started. With these Cloud in Real Life segments, we'll talk about how these basic concepts turn into real-world solutions for businesses.

**Rudy**: Oh, wait, shall we kick things off with an example? Yeah, yeah.

**Morgan**: Yeah, let's do it.

**Rudy**: OK. Let's take two concepts we've discussed in this section: AWS Global Infrastructure and the AWS Shared Responsibility Model. In the real world, these concepts certainly work together and aren't separate ideas.

**Alan**: So true. Let's use an example of something like...um...about an e-commerce company. One that wants to expand operations globally.

**Morgan**: Yeah, I like that example. There are tons of e-commerce companies that use AWS. In general, how would using AWS Global Infrastructure benefit a company like that?

**Alan**: Well, one thing to keep in mind is that the further your infrastructure is from your customers, the longer the latency will be for those customer requests. So, they could choose AWS Regions to host their application closer to their customer base. For example, if they have a significant customer base in Europe and Asia, they might choose to deploy their applications in Regions like eu-west-1 in Ireland and ap-southeast-1 in Singapore.

**Morgan**: It's so much easier to reach a global audience when you're leveraging existing resources like AWS Regions. The groundwork has already been laid. And even though all businesses benefit from this, I also can't help but think about startup companies, and how much you can achieve with a small team by leveraging the cloud. You don't need to have a large upfront capital investment to reach a global audience, which can really help to level the playing field a little bit for startups and small companies.

**Rudy**: Oh, that's so true. And also, it's a lot more straightforward to build resiliency into applications. For the e-commerce company, they could start by using at least two Availability Zones, or AZs. They deploy the same configuration in each, and if one fails, they can failover to the other. This is called designing for high availability and fault tolerance.

**Morgan**: Now we haven't talked about the importance of multiple Availability Zones too much yet, but we'll get there soon. Now, we also learned about the AWS Shared Responsibility Model. So, how does this come into play here?

**Alan**: Yeah, the shared responsibility model is super important for understanding security and compliance. Our e-commerce company can focus on the higher order issues of securing their data and managing access to their AWS resources. Plus, they'll be able to give attention to things like making sure their applications are configured securely to comply with regulations about credit card information rather than having to decide what locks to put on the doors at the datacenter.

**Morgan**: Right, there's the whole "in the cloud" and "of the cloud" situation. AWS is responsible for security of the cloud, and customers are responsible for security in the cloud. AWS services are used together like building blocks to form solutions. So this concept of the shared responsibility model will become clearer as we see how different services are used separately and together.

**Rudy**: Yeah, and there's so much to learn, and we will have more meaningful discussions as we go along. And as you learn new concepts, think about how they might apply to your own work or projects.



## Module 2 - Compute in the Cloud EC2

If you remember from our coffee shop, the employees are a metaphor for the client/server model where a client sends a request to the server, the server does some work, and then sends a response.

### Introduction to Amazon EC2

---

In this video, we are going to talk at a high level about a service called Amazon **Elastic Compute Cloud,** or Amazon **EC2**.

That example is for the coffee shop, but the same idea applies to other businesses. These businesses, whether they are in healthcare, manufacturing, insurance, or delivering video content, are also using this model to deliver products, resources, or data to end users.


---

![EC2](../Images/Media/EC2.png)
[EC2](../Images/EC2.md)

---

You need raw compute capacity to host your applications and provide the compute power that your business needs. When you're working with AWS, those **servers** are called **EC2 instances.** Using EC2 for compute is **highly flexible**, **cost effective**, and **quick** when you compare it to running your own servers on premises in a data center that you own. The **time** and **money** it takes to get up and running with **on-premises** resources is fairly **high**, but with EC2, it's much more convenient to get started.

AWS took care of the hard part for you, and AWS is constantly operating a massive amount of compute capacity ready to be used. And you can use whatever portion of that capacity when you need it. All you have to do is request the EC2 instances you want, and they will launch and boot up, ready to be used within a **few minutes**. After you're done, you can stop or terminate the EC2 instances. You're not locked in or stuck with servers that you don't need or want.

Your usage of EC2 instances can vary greatly over time. And **you only pay for what you use**. Because with EC2, you only pay for running instances, not stopped or terminated ones.

You **STOP PAYING for the compute time (CPU/RAM).** You **continue to PAY** for the attached **EBS volumes** (the hard drive).

**Stopped Instance Use Case**

You stop an instance when you know you will need to use it again soon, or when you need to **change its underlying hardware (instance type)** without losing the **application data** on the attached hard drive.

EC2 instances are **virtual machines**, or VMs. VMs share an underlying physical host machine with multiple other instances, which is a concept called **multi-tenancy**. In a multi-tenant environment, you need to make sure that each VM is isolated from **each other but is still able to share resources provided by the host.**

This job of resource sharing and isolation is being done by a piece of software called a #**hypervisor**, which is running on the host machine. For EC2, AWS manages the underlying host, the hypervisor, and the isolation from instance to instance. So, even though you won't be managing this piece, it's important to have a basic grasp of the concept of multi-tenancy.

When you provision an EC2 instance, you can choose the operating system, or OS, based on either Windows or Linux. You can provision thousands of EC2 instances on demand, with a blend of operating systems and configurations to power your business' different applications.

You also can configure what software you want running on the instance. Whether it's your own internal business applications, simple or complex web apps, databases, or third-party software like enterprise software packages, you have complete control over what happens on that instance. You'll see us launch an EC2 instance in an upcoming demo.

EC2 instances are also **resizable**. You might start with a small instance and realize the application you are running is starting to max out that server. You can then give that instance **more memory and more CPU**.  This is what we call **vertically scaling an instance**. In essence, you can **make instances bigger** or **smaller** whenever you need to.

You also control the **networking** aspect of EC2. So, you decide what type of requests make it to your server and if they are publicly or privately accessible. We'll talk more about this later in the networking section.

Now, it's important to note that the concept of VMs isn’t a new thing. AWS has just made it much more convenient and more cost effective for you to acquire servers through this **Compute as a Service model.**

When launching an EC2 instance, you start by selecting an **Amazon Machine Image (AMI)**, which defines the **operating system** and might include **additional software**. You also choose an instance type, which determines the underlying hardware resources, such as CPU, memory, and network performance.

You need to choose EC2 instance type (**how powerful** you want it) and the Amazon Machine Image (AMI), which determines the operating system and software for your instance.

You can connect to an EC2 instance in various ways. Applications can interact with services running on the instance over the network.

Users or administrators can connect using SSH for Linux instances or Remote Desktop Protocol (RDP) for Windows instances. Alternatively, AWS services like **AWS Systems Manager** offer a secure and simplified method for **accessing instances.**

After you are connected to the instance, you can begin using it to run commands, install software, add storage, organize files, and perform other tasks.

### A little more about Amazon EC2

Now that we've learned about EC2, let's peel the onion back and discuss types of instances.

Visualize EC2 instances as different types of coffee machines in our coffee shop. Customers like variety. Not all of them drink the same thing, so we need more than just one type of coffee machine.

For example, we’ll need a high-powered espresso machine for those who want espresso shots or lattes. We’ll also need a classic-drip coffee machine for customers who just want the sauce, and maybe a cold-brew machine for those who want their caffeine chilled. Therefore, if we want our business to operate as efficiently as possible, it’s important to use the right coffee machine for each order.

This is similar to deploying EC2 instances. There are **different types** of **instances** that serve **different purposes** in your AWS environment. **Instance types are grouped under instance families,** which offer **varying combinations** of **CPU, memory, storage, and networking capacity**. This gives you the flexibility to **optimize** for certain types of tasks by choosing instances specific to your **particular workload.**

The different instance families are **general purpose**, **compute optimized**, **memory optimized**, **accelerated computing**, and **storage optimized**.

1. **General purpose** instances provide a good **balance** of compute, memory, and networking resources. They can be used for lots of **diverse workloads**, like **web services** or **code repositories**. They’re also a good **starting point** if you **don’t know how your workload** will perform **ahead of time.**

2. **Compute-optimized** instances are ideal for **compute-intensive tasks**, like **gaming** servers, **high-performance computing**, **machine learning** tasks--even **scientific modeling**.

3. **Memory-optimized** instances are good for **memory-intensive tasks**. They deliver fast performance for workloads that **process large data sets** in memory. The best choice for real-time analytics.

4. **Accelerated-computing** instances are good for **floating point number calculations**, **graphics processing**, or **data pattern matching**. This is because they use **hardware accelerators**. These are **co-processors** that perform functions **more efficiently** than is possible in software running on CPUs.

5. And, finally, **storage-optimized** instances are ideal for workloads that require high performance for **locally stored data**.

After you’ve decided on an instance type, the next part is to choose the **right instance size**. I urge you to keep not just performance in mind but also **cost**. Sure, bigger instances give you more CPU, memory, and storage, but they also cost more. So, it’s important to find a balance that fits your needs and budget. This ensures that you choose the right instance size to get the best performance, but without paying for resources you don’t really need.

The best part is that you don’t have to use a specific instance type or size forever. You might find that one you initially chose doesn’t offer the performance you need. That’s perfectly fine. You can change it! The cloud gives you that ability to pivot very quickly, so take advantage of it!

| Series                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Options                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| *   **C** – Compute optimized      *   **D** – Dense storage      *   **F** – FPGA      *   **G** – Graphics intensive      *   **Hpc** – High performance computing      *   **I** – Storage optimized      *   **Im** – Storage optimized (1 to 4 ratio of vCPU to memory)      *   **Is** – Storage optimized (1 to 6 ratio of vCPU to memory)      *   **Inf** – AWS Inferentia      *   **M** – General purpose      *   **Mac** – macOS      *   **P** – GPU accelerated      *   **R** – Memory optimized      *   **T** – Burstable performance      *   **Trn** – AWS Trainium      *   **U** – High memory      *   **VT** – Video transcoding      *   **X** – Memory intensive      *   **Z** – High memory | *   **a** – AMD processors      *   **b200** – Accelerated by NVIDIA Blackwell GPUs      *   **g** – AWS Graviton processors      *   **i** – Intel processors      *   **m1ultra** – Apple M1 Ultra chip      *   **m2** – Apple M2 chip      *   **m2pro** – Apple M2 Pro chip      *   **b** – Block storage optimization      *   **d** – Instance store volumes      *   **e** – Extra storage (for storage optimized instance types), extra memory (for memory optimized instance types), or extra GPU memory (for accelerated computing instance types).      *   **flex** – Flex instance      *   **n** – Network and EBS optimized      *   **q** – Qualcomm inference accelerators      *   `*`**tb** – Amount of memory for high-memory instances (3 TiB to 32 TiB)      *   **z** – High CPU frequency |

![image](../Images/Media/image%20(3).png)
[image](../Images/image%20(3).md)

### How to provision AWS Resources 

We've been talking about a few different AWS services, as well as the Global Infrastructure. You might be wondering, “How do I actually interact with these services?” And the answer is **APIs**. In AWS, everything is an API call. An API is an **application programming interface** that defines predetermined ways for you to interact with AWS services. And you can invoke or call these APIs to provision, configure, and manage your resources.

There are three main ways you could call AWS APIs: using the **AWS Management Console**, the **AWS Command Line Interface, or CLI**, or the **AWS Software Development Kit, or SDK**. First, let's talk about the console, which is browser based.

Using the **console**, you can manage your resources **visually** and in a way that is **easy** to digest. This is great for getting started and building out your knowledge of the services. It’s also helpful for setting up test environments, viewing **AWS bills**, **monitoring resources**, and managing **non-technical tasks**. The console is most likely the first place you will go when you’re learning about AWS.

However, after you are up and running in a **production-type environment**, you don't want to rely on the point-and-click style of the console. For example, to create an EC2 instance, you need to navigate through various screens, set all the configurations you want, and then launch your instance. If you wanted to launch another EC2 instance later, you would need to go back into the console and navigate through those screens again to get it up and running.

By having humans do this sort of manual provisioning, you're opening yourself up to potential errors. It's very possible to forget to select a checkbox or misspell something when you are doing everything manually.

Next up, you can use the **AWS CLI** to invoke AWS APIs using a **terminal**. This is different than the visual navigation style of the console, because it allows you to interact with AWS services through text-based input called commands. This makes **automation through scripting** possible.

Let's look at two examples of invoking AWS APIs using the command-line interface. We can run commands using AWS **CloudShell**, which is a cloud-based terminal that has the AWS CLI already installed in a managed environment.

In this example, we're going to create an EC2 instance programmatically with the command,` aws ec2 run-instances`. Let's run the command, and the instance is now initializing. And if you want to do something else, like list all of the AZs in the current Region, you could use the command, `aws ec2 describe-availability-zones`.

These are two basic examples, but as you explore more AWS services and the resources you can create, you'll discover additional AWS CLI commands to interact with those services as well.

I also want to call out that these commands in this example were run manually, but they could also be included in **scripts and other automation processes**. Automation is an important aspect to having a successful and **predictable cloud deployment over time**. So, with that being said, another way to interact with AWS is through the AWS SDK.

**The AWS SDK** makes it possible for you to interact with AWS resources through various programming languages, like Python for example. Let's run a Python script using the integrated development environment-IDE, Visual Studio Code, that uses the SDK to list the EC2 instances in the current region.

So, as you begin to see more examples of AWS using AWS resources, remember that AWS hosts APIs that you use to create, interact with, and manage AWS resources. Whether you are using the AWS Management Console, the AWS CLI, or the AWS SDK, these APIs are being called behind the scenes.

---

An ***unmanaged***service like Amazon EC2 requires you to perform all of the necessary security configuration and management tasks. When you deploy an EC2 instance, you are responsible for configuring security, managing the guest operating system (OS), applying updates, and setting up firewalls (security groups). You will learn more about managed and unmanaged services later.


---

![image](../Images/Media/image%20(4).png)
[image](../Images/image%20(4).md)

---

#### AWS Resources Access Manager - AWS RAM

---

AWS Resource Access Manager (RAM) is a **free** service that helps you **securely share your AWS resources** with other AWS **accounts**, organizational units (**OUs**), or specific **IAM roles/users.**

In a **multi-account environment**, AWS RAM prevents you from having to **duplicate foundational resources** across every account, which saves time and **cost**.


---

![Resource-Access-Manager](../Images/Media/Resource-Access-Manager.png)
[Resource-Access-Manager](../Images/Resource-Access-Manager.md)

---

Think of AWS RAM as a **digital key-sharing service** for your shared infrastructure. Instead of making a copy of a large, expensive asset (like a whole fence or building) for every team, you just give them a key to the original.

**How it Works**

1. **Resource Owner Account:** Creates the central resource (e.g., a **VPC Subnet** or a **Transit Gateway**).

2. **Resource Share:** The owner uses RAM to create a "Resource Share," defining:

    - Which resource(s) to share.

    - Which accounts/OUs/IAM principals (the "consumers") to share with.

3. **Resource Consumer Accounts:**

    - If within the same AWS Organization, access is usually accepted automatically.

    - If **outside the Organization**, the recipient must **manually accept the invitation.**

4. **Usage:** The consumer accounts can then use the shared resource **as if it were native** in their own account, subject to the permissions defined by the owner.

**Key Benefits**

- **Cost Efficiency:** Avoids duplicating expensive resources like NAT Gateways or Transit Gateways.

- **Simplified Management:** You only provision and manage the resource once in the owner account.

- **Consistent Networking:** Essential for creating shared VPC architectures where multiple teams deploy applications into the same, centrally managed network.



### Configure and Launch an Amazon EC2 Instance

[https://aws.amazon.com/ec2/instance-types/](https://aws.amazon.com/ec2/instance-types/)

You've been learning a lot about EC2, and by now, you're probably thinking, "How do I create an EC2 instance myself?" In this video, we’re going to walk through the process of creating an EC2 instance for a web server using the AWS Management Console. We’ll go over some key configurations along the way, so let’s get started! First thing we want to do is go to the EC2 console.

Now, I happen to have it here in my "Recently visited" and in my shortcuts bar, but I can just as easily search for EC2 and go to that service. There are tons of options in here, but we're gonna go and zero in, specifically, on the launch instance option.

First thing we have to choose is a **name**. We have to choose our instance name, so we can find it later. Next thing we're gonna do is choose the Amazon Machine Image, or **AMI**. An AMI is a **template** of the **operating system and the built-in applications** that it's going to come with. We can customize this but for right now, we're going to go with a **default**, the ***Amazon Linux AMI***. Now this Amazon Linux AMI is perfect for a **general-use web server**.

An **AMI** is a **pre-configured virtual machine image** that contains the operating system, application server, and applications. This helps to launch EC2 instances quickly with the desired software and settings.

An **AMI** includes the **operating system**, **storage setup**, **architecture type**, **permissions** for **launching**, and any **extra software** that is already installed. You can use one AMI to launch several EC2 instances that all have the same setup.

AMIs can be used in three ways. First, you can create your own by building a **custom AMI** with specific configurations and software tailored to your needs. Second, you can use **pre-configured AWS AMIs**, which are set up for common operating systems and software. Lastly, you can purchase AMIs from the **AWS Marketplace**, where third-party vendors offer specialized software designed for specific use cases.

AMIs provide **repeatability** through a consistent environment for every new instance. Because configurations are identical and deployments **automated**, development and testing environments are consistent. This helps when scaling, reduces errors, and streamlines managing large-scale environments.

The next thing we have to decide on is the **instance type**. This refers to how much **computing power** our web server is going to have. In this case, we're gonna choose just the basic, ***t2.micro***. We'll go over some of the details that makes up this **t2.micro** a little bit later, but for right now, this is going to be fine. One virtual CPU, one gigabyte of memory, and it's in the **Free Tier**. Sounds good to me.

The next thing we choose is the **key pair**. And this is related to how we are **logging into this EC2** instance. A key pair refers to a pair of keys. Specifically, a **public key**, which is going to be injected into the EC2 instance, and a **private key**, which we will keep. We can create that key pair right here, but I'm gonna go ahead and choose a key that we've already established.

The next section is choosing the network settings. We're going to have a lot of fun going through all these details a little bit later. But for right now, suffice it to say, we're going to allow **HTTP traffic** from the **internet**. It is going to be a **web server**, after all, so that's all we have to do.

The next option we have to choose is the **storage options** for our EC2 instance. In this case, we're going to give it eight gigabytes of disk space using the ***gp3*** **EBS volume**, or elastic block store volume. We'll go over what that means a little bit later, but this means it's going to have plenty of space for web serving.

And speaking of web serving, we do have to make one more change, so it actually is a web server. When we picked the AMI, we picked a very generic AMI. This doesn't have the web server activated at launch. In order to that, we're going to go into the Advanced Details, specifically down to the ***User Data*** section. What the User Data allows us to do is paste in a **script**, such as this one, which will go ahead and install and activate the ***Nginx*** **web server**, which is what we're going to be using to **server content to the internet**.

All this looks fine, so I'm gonna go ahead and hit launch instance, and we'll see what we get. As soon as the instance launches, we can go to its console and see some of the details about that EC2 instance.

Now that our EC2 instance is running, I'm going to copy its public IP address. I'm going to open a new browser, and let's go to it. And there you have it! Your very own EC2 instance running a basic web server.

Congratulations! That’s the basic thing for setting up EC2 instances, and we’re gonna get into more details about the nuances later in the course. So stay tuned.

### Amazon EC2 pricing 

We talked about Amazon EC2 instance types, but you're all probably wondering, “How much is this gonna cost me?” Well, don't fret. For EC2, we have multiple billing options available.

The most widely known option is called **On-Demand**. This means you only pay for the **duration** that your **instance runs**. This can be **per hour** or **per second**, depending on the **instance type** and the **OS you choose**. Even better, **no long-term commitments or upfront payments** are needed. Most customers typically use this option when they get started. This makes it possible to spin up servers, play around, test out workloads. It’s all **self-service**. This helps you figure out a **baseline** for your **average usage**. Using that average, you can start to explore other pricing options, like the next one, Savings Plans.

**Savings Plans** offers **lower EC2 prices** for a **commitment** to a **consistent amount of usage**. This is measured in **dollars per hour** for a **one-year** or **three-year term**. This can provide **savings** of up to **72 percent**, which is pretty significant. In fact, it can lower prices on your EC2 usage, regardless of instance family, size, OS, tenancy, or AWS Region. Additionally, it applies to AWS **Fargate** and AWS **Lambda** usage. Those are **serverless compute** options that we’ll cover later. Best for **Dynamic or changing workloads** where instance **types** or generations are likely to **change over time**, or for a broad usage commitment across **multiple compute services**. **Example:** You commit to spend **$5 per hour** on **EC2 M-family instances** in the **US-East** region. If you are running an m5.large, the discount applies. If you **switch** to an m5.xlarge, the **discount still applies** until the **$5/hour** is **used** up. If you **switch** from Linux to Windows, the **discount still applies.**

Another option is **Reserved Instances**. These are well-suited for **steady-state workloads** or ones with **predictable usage**. They offer you up to a **75 percent discount** compared to On-Demand pricing. You qualify for a discount after you **commit** to a **one-year or three-year term**. There are also three payment options: all **upfront**, where you pay for them in full when you commit; **partial upfront**, where you pay for a portion when you commit; and **no upfront**, where you don't pay anything at the beginning. Best for **Highly predictable, stable workloads** where you know you will run the exact same instance type, size, and OS 24/7. Reserved Instances are older and more rigid. They require you to **commit** to **specific hardware configurations**. **Example (Standard RI):** You buy a reservation for **one** m5.large **Linux instance** in **us-east-1**. The discount **only** applies to that **specific configuration**. If you change it to a c5.large (different family), the RI goes **unused**, and the new instance is **charged On-Demand**.

The next option is **Spot Instances**. These make it possible to **request spare EC2 capacity** for up to **90 percent off** of the On-Demand price. The catch here is that **AWS can reclaim the instance at any time**. However, you do receive a **two-minute warning**, so you can **save** your **progress**. And you can always **resume later** if needed. So, make sure your **workloads** can **tolerate being interrupted** if you choose Spot Instances.

And, finally, we have **Dedicated Hosts**. These are **actual physical servers** that customers can reserve for **exclusive use**. No other customer’s workloads can share the server. This **isolation** use-case is ideal for **security-sensitive** or **licensing-specific workloads**, like **Windows** or **SQL Server**. This is because you have control over instance placement and resource allocation. This helps with meeting certain **compliance** and **regulatory** needs.

**Dedicated Instances**: Pay for instances running on hardware dedicated solely to your account. This option provides isolation from other AWS customers. 

- **Dedicated Instances:** You get a guarantee that your instance will run on hardware used **only by your AWS account**. AWS manages *which* physical server it is on.

- **Dedicated Hosts:** You get a guarantee that an **entire physical server** is exclusively yours, and you have **control** over *where* your instances are placed on that server.

With the variety of EC2 pricing options available, you can choose the most cost-effective solution based on your usage patterns. This helps you to balance flexibility, cost savings, and specific workload needs.

*add a comparison table later - See the Summary note

### Scaling Amazon EC2 

#### **Part 1**

So, we have a good idea now on the basics of Amazon EC2 and how it can help with any compute needs, like making coffee. Well, like, metaphorically making coffee. The coffee represents the...whatever your instance is producing. In reality, the instances could be fielding web requests, processing and analyzing data, or hosting other types of applications.

So now, the next thing we want to talk about is another major benefit of AWS, **scalability** and **elasticity**. This is how capacity can grow and shrink, based on business needs.

If we're running a business and we are planning for growth, we might know on average what's needed capacity-wise. Except the average can include cyclical traffic with busy and quiet seasons. We want happy customers, so we always want enough capacity, but should we plan for the peak usage? What if that peak is only an hour long? Or what if we don't know when the peaks are because it's a new business? Should we buy a lot of extra capacity? That sounds expensive. What's the alternative? Plan for a smaller amount and hope for the best?

What if you could **provision** your workload to the **exact demand**, every hour, every day? Well, now you have happy customers because they can always get the services they want. And you have a happy financial officer because they get the cost savings your company needs.

And here's how it works.

Morgan is behind the counter. She's taking orders, but she isn't doing all the work here, so we need somebody making the drinks. It looks like Rudy's up. Let's ask ourselves what would happen if we lost our order-taking instance. Well, we'd be out of business until we get another person to work the line, or another instance up and running.

So, here is where AWS makes it really straightforward. Using the same programmatic method that we used to create the original Morgan, we can create a second copy of Morgan.

So, if one fails, we have another one already on the frontline taking orders. The customers never lose service, and in the meantime, we can always spin up another instance of Morgan to replace the one that failed. And let's not forget about the backend. Let's make our processing instances redundant, as well.

That solves for our regular operating capacity. We now have a **highly available system** with **no single point of failure**. This is why it's a best practice to set up redundant EC2 instances, and to deploy them across multiple AZs in a Region. That way, if there are issues in one place, the instances deployed in the other AZ can pick up the slack.

And as long as the number of customers in line stays the same, we're good. But you know that will change, right? So, let’s take a look at what's going to happen when we have a rush of customers—or an increase in demand.

**Scalability** refers to the ability of a system to **handle** an **increased load** by **adding resources**. You can **scale up** by adding **more power** to **existing machines,** or you can **scale out** by **adding more machines**. Scalability focuses on long-term capacity planning to make sure that the system can grow and accommodate more users or workloads as needed.

![image](../Images/Media/image%20(5).png)
[image](../Images/image%20(5).md)

**Elasticity** is the ability to **automatically scale** resources **up or down** in response to **real-time demand**. A system can then rapidly adjust its resources, scaling out during periods of high demand and scaling in when the demand decreases. **Elasticity** provides **cost efficiency** and **optimal resource usage** at **any given moment**.

![image](../Images/Media/image%20(6).png)
[image](../Images/image%20(6).md)

The question of downtime depends on how you set up your redundancy, specifically the load balancing and failover mechanism.

1. Active/Active (Zero Downtime)

2. Active/Passive (Minimal Downtime)

- **Failover:** If Server A fails, an automated system (like **Auto Scaling** or a custom script) is triggered to **start** Server B and reroute the traffic to it.

- **Downtime:** There will be a brief period of downtime (anywhere from seconds to a few minutes) while Server B boots up and initializes the application.

**In summary, for a true high-availability setup, both EC2 instances are kept Active/Active to ensure seamless, instantaneous failover with essentially no downtime for the end-user.**

#### Failover Time Calculation

The failover time is the time it takes the **load balancer** to recognize an instance is unhealthy and stop sending it new traffic. This is controlled by three main parameters you define:

1. **Interval:** The time (in seconds) between health checks.

    - *Default for ALB/NLB:* **30 seconds** (can often be set as low as 5 seconds).

2. **Timeout:** The time (in seconds) the load balancer waits for a response from the instance before considering that check a failure.

    - *Default for ALB:* **5 seconds**.

3. **Unhealthy Threshold:** The number of **consecutive failed checks** required before the load balancer marks the instance as officially unhealthy and removes it from the rotation.

    - *Default for ALB:* **2 checks**.

$$
\text{Failover Time} \approx \text{Interval} \times \text{Unhealthy Threshold}$$$$\text{Failover Time} \approx 30 \text{ seconds} \times 2 = 60 \text{ seconds}

$$

#### What Happens During Failover

The key to **zero service interruption** (for a new request) is that the traffic is only routed to the **healthy** servers (Server B in the example). The delay only affects how quickly the ELB recognizes Server A is dead, but it does not stop Server B from serving traffic.

- **New Connections:** As soon as the ELB marks Server A as unhealthy, all new incoming user connections are routed instantly to the healthy Server B. The user experiences no delay beyond their initial connection request.

- **Existing Connections:** Any user who had an *active, in-progress* connection to Server A when it failed will have that specific request fail. They will need to retry their operation, which will then be directed to Server B.

#### Part 2

Now there are two ways to handle growing demands. You can scale out or scale up. Scaling out, otherwise known as **horizontal scaling**, is when you **add more resources to the pool**, so you can get more work done in parallel. Scaling up, otherwise known as **vertical scaling**, means adding **more power** to the machines that are running. This is so that the **individual machine** itself has more power to do the work. Scaling up can give you more power per instance, but that isn't always what you need.

Let's take this idea of scaling into our coffee shop.

Here, when we have an increase in customers, a bigger instance of me really can't take a customer's order any faster. That depends on the customer more than me. I'll take an espresso. Oh, wait, is that organic? Mmmm…make it a soy latte. Actually, I don't know. Do you just have tea? What we need are, well, more instances of me to handle more customers in **parallel**.

Let's get more customers in here. Well, now, that's not good. It looks like the processing instances are about to get overloaded because the orders are coming in faster. The orders are processed quicker, but the drinks aren't getting done and customers are waiting. Let's go ahead and scale the processing instances, as well.

Here comes a maybe obvious question. How come there are more order-taking instances than order-making instances?

Well, in this case, the amount of work getting done is still more than the order-taking instances can send to the back of the house. There isn't currently any backlog of orders, so there's no reason to add more worker instances. This way, you can end up with exactly the right amount of power for each part of your process, rather than **over provisioning** to solve a **separate problem**. You can scale each piece up and down independently as needed.

Okay, looks like we just cleared that rush. Now here is where AWS really makes a difference to your business. We have extra workers that are sitting around idle. If we don't need them, we can send them home or stop the instances. This is how **Amazon EC2 Auto Scaling** works.

EC2 Auto Scaling adds instances based on demand and **key scaling metrics** and then **decommissions** instances when that **demand goes down**. This means that every minute of the day, you always have the desired number of instances.

The way this works technically involves some other AWS services to make it all happen. You need to be **collecting data** about the **performance of the instances**, or potentially **data** around **latency** and **other application metrics**. You would use the **Amazon CloudWatch** service to **collect** and **monitor** these **metrics**. This data is then used to determine when scaling needs to happen. And, it happens **automatically**, right when you need it.

Amazon EC2 Auto Scaling automatically adjusts the number of EC2 instances based on changes in application demand, providing better availability. It offers two approaches. ***Dynamic*** *scaling* adjusts in **real time** to fluctuations in demand. ***Predictive*** *scaling* **preemptively** schedules the right number of instances based on anticipated demand.

![image](../Images/Media/image%20(7).png)
[image](../Images/image%20(7).md)

[Scaling Out vs. Scaling Up Comparison](../Concepts/Scaling%20Out%20vs%20Scaling%20Up%20Comparison.md)

### Directing traffic with Elastic Load Balancing

We solved the scaling problem with Amazon EC2 Auto Scaling. But now we've got a bit of a traffic problem, don't we? Let's take a look at the situation.

Customers have three cashier options, but it seems like they are gravitating towards me, cause I’m just so darn adorable. Look, although I am flattered they noticed my new haircut, this is causing an uneven distribution of customers per line.

Look over there. Morgan and Alan have no customers and are just taking selfies. Pfft, they should have gotten new haircuts, too. Anyway, in place of that, it would help a lot if we added a host to our coffee shop.

The host stands at the entrance and directs customers to a specific line when they walk in. They also keep an eye on the cashiers and count the number of people in each line. Using this real-time information, they direct customers to the shortest line. This helps with evenly distributing customers and ensures they are served efficiently and quickly.

The same idea applies to your AWS environment when trying to balance traffic across a group of EC2 instances. We don’t want **idle** EC2 instances, nor do we want overloaded ones. This is where we introduce the concept of a load balancer.

A **load balancer** takes in requests and routes them to instances. There are many off-the-shelf load balancers that work great on AWS. So, if you have a favorite flavor that already does exactly what you want, feel free to keep using it. Just remember that you will have to **manage, patch, upgrade, handle failover, and perform maintenance** on it.

However, if you would like AWS to handle all of that, and you just configure it once, check out **Elastic Load Balancing**, or **ELB**. ELB is designed to **distribute network traffic** to improve application **scalability**. The word *elastic* refers to its ability to scale up or down based on traffic, without adding to your hourly costs.

ELB can manage both internal and external traffic to AWS. It offers different routing strategies to ensure efficient traffic management and thusly optimal application performance.

Let’s dive into an example. For our coffee shop, we have a website for customers to order drinks. This website has various tiers for functionality, like the ordering tier, production tier, storage tier, and so forth.

Let's look at the ordering tier and how it communicates with the production tier. Right now, every frontend instance is aware of every backend instance. If a new backend instance spins up, then it needs to let every frontend instance know that it can now accept traffic.

This is complicated enough with half a dozen instances. Imagine if we have hundreds or thousands of instances in every tier. Keeping them in sync would be a huge undertaking.

That’s why ELB is here to help. We can use it to manage the linking of the backend instances and the frontend instances. And because it’s Regional, it's a **single URL** that each frontend instance uses to direct to the backend instances. The ELB will then direct traffic to the backend instance that has the least outstanding requests.

If the back-end needs to scale, it spins up a new instance. After that new instance is ready, it tells the ELB that it’s ready for traffic. And just like that, it gets to work.

The frontend doesn’t even need to know what’s happening. It’s all done **automatically**, and it **decouples** the architecture so that each tier is considered its own entity that scales as it sees fit.

![image](../Images/Media/image%20(8).png)
[image](../Images/image%20(8).md)

#### **Routing methods**

To optimize traffic distribution, ELB uses several routing methods: **Round Robin, Least Connections, IP Hash**, and **Least Response Time.** These routing strategies work together for efficient traffic management and optimal application performance.

![image](../Images/Media/image%20(9).png)
[image](../Images/image%20(9).md)

See the diffrences 

**ELB** is responsible for **distributing incoming traffic** evenly across multiple EC2 instances.

Together, ELB and Auto Scaling help maintain application reliability and cost efficiency.



### Messaging and Queuing

**Alan**: Oh, sorry. I was just ordering a cup of coffee. Let's talk about messaging and queuing. In the coffee shop, there are cashiers taking orders from the customers and baristas making the orders.

Currently, the cashier takes the order, writes it down with a pen and paper, and delivers this order to the barista. The barista then takes the paper and makes the order. When the next order comes in, the process repeats. This works great, as long as both the cashier and the barista are in sync.

But what happens if the cashier took the order, turned to pass it to the barista, and the barista was on break or busy with another order? Well, that cashier is stuck until the barista is ready to take the order. And, at a certain point, the order will probably be dropped so the cashier can go serve the next customer.

You can see how this is a flawed process, because as soon as either the cashier or barista is out of sync, the process will degrade. This will cause slowdowns in receiving orders—and failures to complete orders at all. A much better process would be to introduce some sort of **buffer** or **queue** into the system. Instead of handing the order directly to the barista, the cashier would post the order to an order board.

This idea of placing messages into a buffer is called messaging and **queuing**. Just as our cashier sends orders to the barista, applications send messages to each other to communicate. If applications communicate directly, like our cashier and barista previously, that is called being **tightly coupled**. A hallmark trait of a tightly coupled architecture is this: If a **single component fails** or changes, it causes issues for the other components or even the **whole system.**

For example, Application A is sending messages directly to Application B. If Application B has a failure and cannot accept those messages, Application A will begin to see errors, as well. This is an architecture where if one component fails, it is isolated and therefore won't cause cascading failures throughout the whole system. If we designed the application to use a more loosely coupled architecture, it could look like this.

Just like our cashier and barista, we introduced a buffer between the two. In this case, we introduced a **message queue**. Messages are sent into the queue by Application A and are processed by Application B. If Application B fails, Application A doesn't experience any disruption. Messages being sent can still be sent into the queue and will remain there until they are eventually processed.

This is **loosely coupled**. This is what we strive to achieve with architectures on AWS. And this brings me to two AWS services: Amazon **Simple Queue Service**, or Amazon **SQS**, and Amazon **Simple Notification Service**, or Amazon **SNS**.

---

**Simple Queue Service - SQS** 

**SQS** makes it possible for you to **send**, **store**, and **receive messages** between software components at any volume. This is done without losing messages or requiring other message consumers to be available.


---



---

Think of messages as our coffee orders and the order board as an SQS queue. Messages have the person's name, coffee order, and the time they ordered. The **data within a message** is called a **payload**. SQS queues are where the messages are placed until they are processed. These **scale automatically**, are **reliable**, and are **simple** to configure and use.

---

**Simple Notification Service - SNS**


---



---

SNS is similar as it also sends messages to services, but it has a big distinction: Sent SNS messages aren't held for pickup until the processing service has a moment to get to them. Instead, SNS messages **need a response right now**. If SQS is the coffee orders board, SNS is the barista yelling out, "One Rudy's Refresher, to go!"

**Alan**: Additionally, SNS can be used to fan out notifications to end users using mobile push, SMS, and email. Taking this back to our coffee shop, we could send out a notification when a customer's order is ready. This could be a simple text message.

Monolithic applications (coupled) vs Microservices architecture (loosely coupled)

Amazon **EventBridge**, Amazon **SNS**, and Amazon **SQS** are AWS services that help different parts of an application communicate effectively in the cloud.

#### **EventBridge**

---

**EventBridge** is a **serverless service** that helps **connect different parts** of an application using **events**, helping to build scalable, **event-driven systems**. With EventBridge, you route events from **sources** like **custom apps**, **AWS services**, and **third-party software** to other applications. EventBridge simplifies the process of **receiving, filtering, transforming, and delivering events**, so you can quickly build reliable applications.


---

![EventBridge](../Images/Media/EventBridge.png)
[EventBridge](../Images/EventBridge.md)

---

**How EventBridge helps:** EventBridge can route events, like *order placed* or *payment completed*, to the relevant services (payment, restaurant, inventory, and delivery). It can handle **high volumes** of events during peak times, making sure **each service** works **independently**. Even if one service fails, EventBridge will store the event and process it as soon as the service is available again. EventBridge helps provide a smooth and reliable operation across the entire system.



#### **Amazon SQS**

---

Amazon SQS is a message queuing service that facilitates reliable communication between software components. It can send, store, and receive messages at any scale, making sure messages are not lost and that other services don't need to be available for processing. In Amazon SQS, an application places messages into a queue, and a user or service **retrieves** the message, **processes** it, and then **removes** it from the queue


---

![Simple-Queue-Service](../Images/Media/Simple-Queue-Service.png)
[Simple-Queue-Service](../Images/Simple-Queue-Service.md)

---

---

#### **Amazon SNS** 

Amazon SNS is a publish-subscribe service that publishers use to send messages to subscribers through SNS topics. In Amazon SNS, subscribers can include web servers, email addresses, Lambda functions, and various other endpoints. You will learn about Lambda in more detail later.


---

![Simple-Notification-Service](../Images/Media/Simple-Notification-Service.png)
[Simple-Notification-Service](../Images/Simple-Notification-Service.md)

---

| **Feature**             | **Amazon SQS (Simple Queue Service)**                                                                                      | **Amazon SNS (Simple Notification Service)**                                                                                                | **Amazon EventBridge (Event Bus)**                                                                                                                                          |
| :---------------------- | :------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------ | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Communication Model** | **Queue-Based (1:1/Pull)**                                                                                                 | **Publish/Subscribe (1:Many/Push)**                                                                                                         | **Event Bus (1:Many/Rule-Based Push)**                                                                                                                                      |
| **Message Flow**        | Producer sends a message to a queue. **One** consumer *pulls* it out for processing.                                       | Publisher sends a message to a topic. **All** subscribed endpoints are *pushed* the message.                                                | Event Source sends an event to a bus. **Rules** match the event and *push* it to targets.                                                                                   |
| **Message Persistence** | **Durable.** Messages are stored in the queue for up to 14 days until they are successfully processed and deleted.         | **Not Durable.** Messages are instantly pushed; if a subscriber is unavailable, the message is lost (unless delivered to an SQS queue).     | **Not Durable.** Events are processed and routed in real-time.                                                                                                              |
| **Primary Use Case**    | **Decoupling and Asynchronous Task Processing.** Best for background jobs, rate limiting, and ensuring message durability. | **Broadcasting and Real-Time Notifications.** Best for sending one message to multiple recipients (microservices, email, SMS, mobile push). | **Event-Driven Architectures and Integration.** Best for complex routing, advanced filtering, and connecting AWS services with **SaaS providers** (e.g., Zendesk, Datadog). |
| **Ordering**            | **Yes, with FIFO Queues** (First-In, First-Out)                                                                            | Yes, with **FIFO Topics** (only when subscribing to FIFO SQS queues).                                                                       | **No** (best-effort delivery, order not guaranteed).                                                                                                                        |
| **Filtering**           | Basic, based on message attributes.                                                                                        | Yes, subscribers can use **Subscription Filter Policies** to receive only messages they care about.                                         | **Advanced.** Rules can match complex patterns and content within the event payload itself.                                                                                 |


[Comparison Table for Amazon EC2 Instance Types](../Pages/Comparison%20Table%20for%20Amazon%20EC2%20Instance%20Types.md)


## Module 3 - Exploring Compute Services 

### Exploring AWS compute options 

Welcome back! At this point, you've learned how to use Amazon EC2 to provision compute resources in the AWS Cloud, and that’s great! EC2 is one of the foundational services in AWS and understanding how to use it is key.

To quickly recap, EC2 instances are virtual machines that you can provision on AWS. EC2 is great for all sorts of use cases, from running basic web servers to high performance computing workloads, and everything in between. EC2 offers a high degree of control when it comes to your instances, but it also requires that you manage that fleet of instances over time.

**EC2 is an unmanaged service**, meaning that you have control over tasks like **patching**, **scaling**, and **managing** the **operating system**, while AWS manages the underlying infrastructure. Think back to the Shared Responsibility Model, where AWS is responsible for the security of the cloud, and you are responsible for security in the cloud.

On the other hand, AWS also offers **managed services**. Managed services shift more operational responsibilities to AWS—so you can focus on building your application and less on managing infrastructure. To help illustrate this, let’s relate it back to the coffee shop.

**Unmanaged** services are like those high-end, **fully customizable** espresso machines. You get to choose the beans, grind them up to your desired consistency, tinker with every knob and lever to your liking, so you get that perfect cup of coffee. It’s all about control. And it’s a coffee enthusiast’s dream! But it’s also more work because you’re on the hook for all the upkeep and maintenance for the machine as well.

**Managed services**, on the other hand, are more about **convenience**. Think of them like a coffee maker that uses pods. You just pop in a pod, choose your settings, press a button, and within moments, you’ve got a cup of coffee—no fuss, no hassle. Sure, it might not be as customizable as the espresso machine, but it saves you a lot of time and effort. What you choose really depends on what you’re looking for.

AWS services span a range from unmanaged to managed, offering you varying degrees of control and convenience. Some services, like EC2, allow you to fine-tune everything. You’re in charge of all configurations and management.

Then, there are **managed services**. Some examples of managed services that you've already learned about are **ELB**, **SNS**, and **SQS**. For managed services, you configure the service to meet your requirements, and then AWS makes sure it runs smoothly over time, with no server management required on your part. This idea of not managing any underlying infrastructure led to the rise of **serverless computing.**

**Serverless** means that you can’t actually see or access the underlying infrastructure or instances that are hosting your application. Instead, all the management of the underlying environment from a **provisioning, scaling, high availability**, and **maintenance perspective are handled** for you. All you need to do is focus on your application.

With a new understanding of terms like unmanaged, managed, and serverless, we’re going to explore some of the other compute services that AWS has to offer. There are many services available, built for different use cases, and we will be covering some of these in the upcoming lessons.

AWS offers all these different compute services to give you options that cater to various workloads, requirements, and **levels of management**. The key is to recognize what your specific application needs are and choose a service that provides the right balance of customization and ease of use.

#### **Decision Framework**

| Factor              | Serverless (Lambda/Fargate) | Traditional (EC2/ECS) |
| :------------------ | :-------------------------- | :-------------------- |
| **Traffic Pattern** | Sporadic, unpredictable     | Steady, predictable   |
| **Duration**        | < 15 min                    | Any duration          |
| **State**           | Stateless                   | Stateful OK           |
| **Cost at Scale**   | High volume = expensive     | High volume = cheaper |
| **Latency**         | Cold starts possible        | Consistent, low       |
| **Management**      | Zero ops                    | Requires maintenance  |
| **Startup Speed**   | Instant deploy              | Minutes to provision  |
| **Scaling**         | Automatic, instant          | Manual or slower      |

Sometimes you’ll want to be the barista, brewing everything from scratch, and other times you just need that quick cup of coffee without all the fuss.

![image](../Images/Media/image%20(10).png)
[image](../Images/image%20(10).md)


### AWS Lambda

---

Lambda is a **serverless compute** service that **runs code** in **response** to **events** without the need to provision or manage servers. It **automatically manages** the underlying infrastructure, scaling resources based on the volume of requests. You are **charged** only for the **compute time consumed**, down to the millisecond. Lambda handles execution, scaling, and resource allocation. You can optimize performance by configuring the appropriate **memory size** for your function.


---

![Lambda](../Images/Media/Lambda.png)
[Lambda](../Images/Lambda.md)

---

Ok, time to dive into my favorite managed service—AWS Lambda. Lambda is a serverless compute service. It’s also known as a **Function**as a **Service**.

Let’s say you’re building a crab classifier app where users upload a picture of a scuttling crustacean and then get notified when a classification has been made. After your app has been coded, you’ll then need to deploy it onto infrastructure. This means provisioning servers, scaling up and down, and making sure everything is always available. I see you scratching your head and thinking…this sounds like a lot of work, Rudy. But don’t get crabby!

You can use **Lambda** to**run code!** With Lambda, you don’t need to think about servers or crab clusters. You create a Lambda function, put your code in there, configure a **trigger**, and your function runs in response to that trigger.

Going back to the crab classifier app, a simple trigger could be when a user **uploads a new picture** of a crab or when the app has determined the classification of an uploaded image. Triggers can be more complex, though. Like processing data in real-time from a stream or resizing an image into different resolutions. And the claw-some part is that you don’t have to manage the environment. AWS handles it all for you!

This managed environment is **automatically scalable** and **highly available**. This means whether you get a single trigger or thousands, Lambda will scale up or down to meet the demand. Even better, AWS takes care of all the patching, updates, and **security**. You shrimpy focus on your code. And with that code, just be aware that the **maximum duration** of a Lambda function is **15 minutes**. Look, we’re not being shellfish, but if you cannot **split your code** into 15-minute segments, Lambda might not be the best fit.

Lambda is great for quick, **event-driven processes**. For example, **handling website requests**, **processing batches of data**, and **generating expense reports**. Oh, and did I mention that Lambda **supports any programming language**? ‘Cause it does! Lambda supports several languages by default through the use of **runtimes**. Languages like Java, Python, and Node.js. However, you can build your own custom runtime, too. A **runtime** provides a **language-specific environment** that relays **invocation events, context information**, and **responses** between Lambda and the function.

One last thing to mention is that Lambda integrates with other AWS services quite easily. This means you can build out your fully-fledged crab classifier app using a plethora of AWS services and still not have to worry about spinning servers up and down. You just have to worry about putting all those crab species into your database.

However, **Lambda** has **250MB** deployment packagelimit (10GB with container images). Also, AWS shuts down the execution environment after ~15 minutes of inactivity.

Thanks for watching.

[AWS Step Functions](../Concepts/AWS%20Step%20Functions.md)

## AWS Lambda Power Tuning

AWS Lambda Power Tuning is an [open-source tool](https://github.com/alexcasalboni/aws-lambda-power-tuning) that uses **AWS Step Functions** to help you optimize your Lambda functions for either cost savings or improved performance.

[https://medium.com/ssense-tech/rightsizing-your-lambdas-lambda-power-tuning-compute-optimizer-f70dab1830ee](https://medium.com/ssense-tech/rightsizing-your-lambdas-lambda-power-tuning-compute-optimizer-f70dab1830ee)

[https://youtu.be/rpL77KDN92Q](https://youtu.be/rpL77KDN92Q)

### Creating and AWS Lambda Function 

Here's our architecture. We've got an **SQS** queue that **automatically** **triggers** a **Lambda** function whenever a **new message** is added to it. Even for this simple-looking workflow, we must ensure the Lambda function has the right **permissions** to **access** the **SQS** queue.

All right, let's jump into the SQS console. I've already created a queue, so let's add two text messages. OK, we are sending a message. This is a test message. We are going to send message. This is a test message again, send, go back here.

Next, Lambda, Lambda, Lambda. Well, one at least. I'm gonna use a blueprint to save us some time when creating a Lambda function. We'll choose **blueprint** over here. Go down, scroll, and we're gonna find the one that is related to SQS. Here we go.

I think I'll name the function Lambert after that sheepish lion. Here we have the **runtime** and **architecture** for the blueprint already set. The run time is Node.js in this case, but if you create your own function from scratch, you'll get to decide on the runtime. Supported run times include Java and Python, but you can use a **custom runtime** as well.

Now we need to set up an **execution role** to **allow** Lambert to **read messages** from our SQS queue. We can use the **Amazon SQS poller policy template**, which will allow Lambert to pull messages from our queue. We'll call this role *Demo_Lambert_Role*. So, select it. There we go. Demo. If we examine the blueprint code, you can see Lambert will be able to grab the message, log the ID and text of each message, and it tells us how many messages have been processed.

The last step is to set up the **SQS trigger** for our Lambda function. This trigger is already selected, so we'll just pick our queue from the list. We'll leave other settings as default and clickity-click to create function. Schweet! Lambda has been created, and you can see the code along with the enabled trigger.

Let's head back to the SQS console to check the messages we added earlier. Yep, they've already been processed. There's nothing left in the queue. Not sheepish after all, Lambert.

Back in our Lambda console, we can see **function metrics** by going to the **monitor tab** and then clicking *View* ***CloudWatch logs***. We then click on the **log groups**. We click on the **function name.** We open up the **log stream**. And you can see, for the log stream, we have our two test **messages** that were **processed successfully** by Lambert, the Lambda function.

Time to do a quick manual test. Head back to the SQS console, select the queue, and then click the send and receive messages button. Let's type in test message. We then click send, and this will add the message to the queue. If we go back to the queue, you can see the messages are gone. Nowhere, *nada*. Why? Because Lambert, the Lambda function processed them that quickly.

OK, let's jump back to our Cloudwatch log streams. So, we're in the CloudWatch console here. We click on our Lambda function. We then scroll down to the log streams and just refresh to make sure. And you can see that all our messages were processed. These are the two messages from earlier, and this is the one that we just added.

There you go. All have been successfully processed by Lambert. And that's it, folks. That's a wrap.

### Containers and Orchestration in AWS

So far, we've talked about EC2 and Lambda, and there's another compute service we haven't talked about. Let's talk about **containers**!

Imagine you’re a developer trying to deploy an application that’s worked perfectly on your computer but fails everywhere else. That’s frustrating, right? You might even have heard developers trying to debug this issue and saying to each other, "It works on my machine."

Containers solve this **portability problem** by providing a **consistent environment** that can be replicated **anywhere**. That’s what containers do. They **package everything** your **application needs** to **run—code,** **runtime**, **dependencies**, **configuration**—into a **single, portable unit**. This creates a consistent environment, isolating your application from the underlying system and making it convenient to **deploy** and **scale** your **application anywhere**. **Containers** also provide benefits like **faster start times** and **improved resource efficiency**.

Now that you understand what containers are, let’s talk about **hosting** them on AWS. You can manage containers on your own, where you place containers on top of a cluster of EC2 instances, but it’s a lot of work. You’d have to deal with monitoring the health of the containers, starting and stopping them when needed, updating them, and managing the networking for them, and more. You can manage it, of course, but it would be complicated and easy to mess up. That’s where container orchestration services come in.

**Container orchestration services** manage the **lifecycle** of **containers**, including starting, stopping, and running them across a cluster. These orchestration services **automatically scale containers** out when traffic increases—and scale back in when things calm down. This way, your application can handle spikes in demand without breaking a sweat. They also handle **recovery from failure**, **monitoring**, and **updates**, saving you tons of time and effort.

On AWS, we have two main container orchestration options: Amazon **ECS** and Amazon **EKS**. Let’s break them down.

---

**Amazon ECS** 

Amazon ECS stands for Amazon **Elastic Container Service**. It’s ideal if you want something **streamlined** and **integrated**, but you can still **define** your **application’s container images** and **resources**, such as **EC2 instance types** and **load balancers**. ECS **automatically manages** the containers and their infrastructure based on the **parameters** you set.


---

![Elastic-Container-Service](../Images/Media/Elastic-Container-Service.png)
[Elastic-Container-Service](../Images/Elastic-Container-Service.md)

---

---

**Amazon EKS** 

On the other hand, you have Amazon EKS, or **Amazon Elastic Kubernetes Service**. **Kubernetes** is an **open source platform** that **automates containerized application deployment**, **scaling**, and **management**. EKS makes it convenient to run **Kubernetes clusters** on AWS. It offers a lot of **control** and **flexibility**, especially for **large-scale** or **hybrid deployments**.


---

![Elastic-Kubernetes-Service](../Images/Media/Elastic-Kubernetes-Service.png)
[Elastic-Kubernetes-Service](../Images/Elastic-Kubernetes-Service.md)

---

---

**Amazon ECR**

Amazon **Elastic Container Registry** (Amazon **ECR**) is where you can **store**, **manage**, and **deploy container images**. It supports container images that follow the Open Container Initiative (OCI) standards. You can push, pull, and manage images in your Amazon ECR repositories using standard container tooling and command line interfaces (CLIs).


---

![Elastic-Container-Registry](../Images/Media/Elastic-Container-Registry.png)
[Elastic-Container-Registry](../Images/Elastic-Container-Registry.md)

---

Now, orchestration services need somewhere to get their containers from. That’s where Amazon **Elastic Container Registry**, or Amazon **ECR**, comes in. ECR is a **fully managed container registry** that **stores** your **container images**. You build your containers that have your application and all of its dependencies bundled together. From there, a **container orchestration tool can pull the container image and deploy it**.

So, you’ve got your container image, and you've chosen an orchestration service. Now, let’s focus on where your containers will actually run. AWS offers two main options for this: **Amazon EC2** and **AWS Fargate**.

With **EC2**, you **manage** the **virtual machines** that run your containers. With this option, you have **full control**, but you need to **manage the underlying infrastructure.**

On the other hand, **Fargate** is **serverless** and offers **efficiency** and **convenience**. With Fargate, AWS manages the servers, and you only need to worry about your containers. No need to manage a fleet for these containers to run on.

---

**AWS Fargate**

AWS Fargate is a **serverless compute engine** for **containers**. It works with both Amazon ECS and Amazon EKS. Fargate is a **container hosting platform**, unlike Amazon ECS and Amazon EKS, which are both container orchestration services.


---

![Fargate](../Images/Media/Fargate.png)
[Fargate](../Images/Fargate.md)

---

When using Fargate, you do not need to provision or manage servers. Fargate manages your server infrastructure for you. You can focus more on innovating and developing your applications, and you pay only for the resources that are required to run your containers.

#### Lambda vs Fargate comparison table 

| **Feature**           | **AWS Lambda (Function-as-a-Service, FaaS)**                                                                                       | **AWS Fargate (Container-as-a-Service, CaaS)**                                                                                      |
| :-------------------- | :--------------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------- |
| **Unit of Execution** | A **Function** (a single piece of code).                                                                                           | A **Container** (an entire application/process).                                                                                    |
| **Execution Model**   | **Event-Driven.** Runs only when triggered by an event.                                                                            | **Long-Running/Persistent.** Runs continuously or for long batch jobs.                                                              |
| **Execution Limit**   | **15 minutes maximum** per invocation.                                                                                             | **No hard limit.** Can run indefinitely (24/7).                                                                                     |
| **Compute Scaling**   | **Instantaneous/Massive.** Scales by creating a new execution environment for *every single event* (up to thousands concurrently). | **Measured/Predictable.** Scales by launching or stopping **whole containers** based on CPU/memory metrics.                         |
| **Resource Control**  | **Limited.** You only configure the **Memory size**, which indirectly controls the CPU.                                            | **Granular.** You explicitly define the needed **vCPU** and **Memory** for the container.                                           |
| **Pricing**           | Based on **Invocations** and **Execution Duration** (rounded to the nearest millisecond).                                          | Based on **Allocated vCPU and Memory** for the container's running time (rounded to the nearest second, with a one-minute minimum). |
| **Best For**          | **Short-lived, variable workloads** like responding to API requests, file uploads, or database changes.                            | **Long-running services** like web servers, APIs that need to stay "warm," or complex batch processing.                             |

Alright, let’s walk through an example of how all these pieces fit together. First, you’ll **upload** your **container images** to **ECR**, which is where your **images** get **stored** securely and are ready to be used. After that, you’ll pick an **orchestration service** based on what you need, either **ECS** or **EKS**. Lastly, you’ll choose your **compute option**, either **EC2** or **Fargate**.

With AWS, deploying and managing containers is convenient, efficient, and scalable—perfect for keeping your focus on where it matters most: on your application.

AWS has a set of tools for managing containers that fits into three categories: **orchestration**, **registry**, and **compute**.

**Amazon ECS launch types**:

- **Amazon ECS with Amazon EC2** is ideal for small-to-medium businesses that need full control over infrastructure. Suitable for custom applications requiring specific hardware or networking configurations, with the flexibility of Amazon EC2 and the simplicity of Amazon ECS.

- **Amazon ECS with AWS Fargate** is perfect for startups or small teams building web applications with variable traffic. It's a serverless option—no server management required—so teams can focus on development while Amazon ECS handles scaling and orchestration.

**Amazon** **EKS launch types**:

- A**mazon EKS with Amazon EC2**: This is best for enterprises needing full control over infrastructure. It offers deep customization of EC2 instances alongside Kubernetes scalability—ideal for complex, large-scale workloads.

- **Amazon EKS with AWS Fargate**: This is great for teams wanting Kubernetes flexibility without managing servers. It combines Kubernetes power with serverless simplicity, helping to scale applications quickly across various use cases.

### Containers and VMs

A container packages your application with everything it needs to run, so it works the same on any computer. This helps to move, update, and manage. Containers are faster and lighter than virtual machines (VMs) because they share the host computer’s operating system. VMs use a hypervisor to run full, separate operating systems, which makes them less resource-efficient and have longer startup times.

### Additional Compute Services 

So far, we've covered compute options like EC2, Lambda, and container services like ECS. But wait…there's more! There are many purpose-built services you can use for specific use cases that can help you achieve your goals. Let’s take a quick look at some of them!

**Elastic Beanstalk**

---

Elastic Beanstalk is a **fully managed** service that streamlines the **deployment**, **management**, and **scaling** of **web applications**. Developers can upload their code, and Elastic Beanstalk automatically handles the provisioning of infrastructure, scaling, load **balancing**, and application **health monitoring**. It supports various programming languages and frameworks, such as Java, .NET, Python, Node.js, Docker, and more. It provides **full control over the underlying AWS resources** while **automating** many **operational tasks.**


---

![Elastic-Beanstalk](../Images/Media/Elastic-Beanstalk.png)
[Elastic-Beanstalk](../Images/Elastic-Beanstalk.md)

---

First up is **AWS Elastic Beanstalk**. This is a service that makes it easier to **deploy** and **manage applications** in **EC2**. Instead of building out the needed infrastructure, like the network, EC2 instances, scaling, and elastic load balancers by yourself, you can provide your application code and desired configurations to the Elastic Beanstalk service. Elastic Beanstalk then takes that information and **builds** out your **environment** for you. Elastic Beanstalk also makes it easy to **save environment configurations,** so they can be deployed again. You won’t need to provision and manage all of these pieces separately, and you’ll still have visibility and control of the underlying resources.

**Good for**: Deploying and managing web applications, RESTful APIs, mobile backend services, and microservices architectures, with automated scaling and simplified infrastructure management

---

**AWS Batch**

AWS Batch is a **fully managed** service that you can use to run batch computing workloads on AWS. It automatically schedules, manages, and scales compute resources for batch jobs, optimizing resource allocation based on job requirements.


---

![Batch](../Images/Media/Batch.png)
[Batch](../Images/Batch.md)

---

Next up, let's talk about **AWS Batch**, a compute service designed for **heavy-duty tasks** like processing **massive datasets**, running **simulations**, or performing **complex calculations**. **AWS** Batch takes care of the **infrastructure management** for you. You won’t need to worry about provisioning servers, scaling resources, or managing infrastructure. AWS Batch handles all of that, allowing you to focus on the important tasks like building your application or running your analysis. The service also scales **automatically**, distributing tasks across a fleet of compute resources like EC2 instances.

G**ood for**: Processing large-scale, parallel workloads in areas like scientific computing, financial risk analysis, media transcoding, big data processing, machine learning training, and genomics research

**Lightsail**

---

Amazon **Lightsail** is a cloud service offering virtual private servers (VPSs), storage, databases, and networking at a **predictable monthly price**. It’s ideal for small businesses, basic workloads, and developers seeking a straightforward AWS experience without the complexity of the full AWS Management Console.


---

![Lightsail](../Images/Media/Lightsail.png)
[Lightsail](../Images/Lightsail.md)

---

Then there's **Amazon Lightsail,** which **simplifies web application hosting** by giving you a relatively easy, **cost-effective** solution for **running** specific types of **applications** and **websites**. It takes care of a lot of the complexity that comes with traditional web application hosting, and it's a great option if you want something **quick** and **easy** to manage!

G**ood for**: Basic web applications, low-traffic websites, development and testing environments, small business websites, blogs, and learning cloud services

---

**Outposts**

AWS Outposts is a **fully managed** **hybrid cloud** solution that extends AWS infrastructure and services to **on-premises data centers**. It provides a consistent experience between on premises and the AWS Cloud, offering compute, storage, and networking components.


---

![Outposts-family](../Images/Media/Outposts-family.png)
[Outposts-family](../Images/Outposts-family.md)

---

Finally, let’s talk about one more unique, purpose-built AWS service called **AWS Outposts**. This one is designed for organizations that need a **hybrid-cloud solution**. If you want to leverage the power of AWS while keeping **some** of your **infrastructure on premises**, Outposts is the answer. Outposts extends AWS services to your on-premises data center, giving you a consistent experience across both environments. You get to run **AWS services locally**, while still benefiting from **cloud computing**. This is perfect for meeting specific needs, like **low latency**, d**ata residency**, or integration for **hybrid deployments**.

G**ood for**: Low-latency applications, data processing in remote locations, migrating and modernizing legacy applications, and meeting regulatory compliance or data residency requirements

[Comparison Table - purpose build compute services](../Tables/Comparison%20Table%20-%20purpose%20build%20compute%20services.md)


## Module 4 - Going Global 

### Introduction to Going Global 

The coffee shop is thriving. In fact, the shop has gained quite a following, and now we’re thinking it’s time to expand. That’s right. Breaking news: the coffee shop is going international.

As the shop plans its expansion, there are a few considerations to keep in mind. First, we need to decide where to open new locations. We want to reach coffee lovers in different parts of the world, but we also need to consider factors like local demand, regulations, and costs. This is like how in AWS, when you are expanding globally, there are a number of factors to consider when selecting AWS Regions. In these upcoming lessons, you'll learn all about what goes into choosing a Region or set of Regions.

The next step of our coffee shop expansion plan is that we want to open some lightweight, smaller footprint versions of our shop called coffee carts. We'll set these up in places like farmers markets, airports, and event venues. They won't serve every drink or item on the menu, but they can provide the most popular items quickly and efficiently. These coffee carts are similar to how **AWS edge locations** work. Edge locations offer fast, localized delivery of the **most frequently accessed content**. They **cache** things like images, videos, and other **assets** and **resources**, allowing users to get the content they need **quickly**, without waiting for it to be retrieved from a central location. You'll learn more about these soon.

Finally, our shop wants to **standardize** and **automate processes** so we can keep our customer satisfaction consistent. No matter which shop or coffee cart the customer visits, we want them to get the same great experience. We’ll train staff on the same recipes and use smart coffee machines that can be programmed remotely and replicated to all the different locations, making sure that a cappuccino in Stockholm tastes just like one in Seattle. Similarly, AWS has infrastructure in place to help businesses **scale responsibly and consistently**. In this section, you'll explore how to achieve consistent deployments across environments and global deployments using **infrastructure as code**, or **IaC**, specifically focusing on **AWS CloudFormation**.

By the end of this section, you'll have a thorough understanding of the ins and outs of AWS Global Infrastructure, helping you to achieve robust, scalable, and globally available applications. So, grab your cup of coffee, and let's dive in.

### Choosing AWS Regions 

One of the best parts about the AWS Global Infrastructure is that you have lots of options when it comes to which AWS Region, or Regions, you deploy your resources in. Before we talk about what factors into this business decision, I want to touch on an important security aspect of AWS Regions. Each Region is isolated from every other Region, in the sense that no data goes in or out of your environment in that **Region** without you explicitly granting **permission** for that **data** to be **moved**.

This is a good thing! Depending on the type of business you are dealing with and where you operate, you might have to adhere to specific compliance **regulations** that require your **data** to remain in one **geographical area**. For example, if you're working with financial information in Frankfurt, local data governance laws state that this financial data cannot leave Germany. The data that is stored in an AWS Region is subject to the **local laws** and **statutes** of the country where the Region lives. Which is actually our first of four considerations when choosing a region: compliance.

#### **Compliance**

Before any of the other factors, you must first look at your **compliance requirements**. Do you have a requirement that your data must live in UK boundaries? Then you should choose the London Region. The choice is pretty straightforward. None of the other options really matter. Or, let's say you must run inside of Chinese borders. Well then, you should choose one of our Regions located in China. Most businesses are not governed by such strict regulations. So, if you don't have a compliance or regulatory control that dictates your Region, then you can look at the other factors.

#### Proximity

The second factor is **proximity**. How close you are to your **customer base** is a major factor. If most of your customers live in Singapore, consider running out of the Singapore Region. You can certainly run out of Virginia, but the time it takes for the information to be sent, or **latency**, between the US and Singapore is always going to be a factor.

#### Feature Availability 

For number three we have **feature availability**. Sometimes the closest Region might not have all of the AWS features you want. Here's one of the cool things about AWS. We're constantly innovating on behalf of our customers. Every year, AWS releases lots of **new features** and **products** specifically to answer customer requests and needs. These features are **rolled out to regions over time,** so that is also a consideration.

For example, AWS GovCloud Regions are specifically designed to meet the compliance and security requirements of US government agencies and their contractors.

#### Pricing

Finally factor number four is **pricing**. Even when the services and features are equal from one Region to the next, some locations are **more cost effective** to operate in than others. Things like **local tax** structure and **energy costs** factor into the equation. AWS has a very transparent, granular pricing that we'll continue to discuss in this training. But know that each Region has different numbers for pricing.

Some Regions have lower operational costs than others. These operational costs can impact the overall expenses for hosting applications and services. Some Regions might offer tax incentives or have lower tax rates, which can affect customer pricing.

So, to wrap up, you have a lot of options in terms of where to deploy your resources. Keep these four key factors in mind when choosing a Region: compliance, proximity, feature availability, and pricing.

![image](../Images/Media/image%20(11).png)
[image](../Images/image%20(11).md)

### Diving Deeper into AWS Global Infrastructure

At this point, you’ve seen how user proximity, regulatory compliance, service availability, and even pricing can play a factor in selecting an AWS Region. When it comes to infrastructure, you also want to plan for long-term stability and less or virtually no down time for your users. So, if your infrastructure has an interruption, you can switch to redundant or backup infrastructure seamlessly. This is called building **redundant architectures**.

One method for redundancy is an architecture that uses multiple Availability Zones, or **AZs**. In a multi-AZ architecture, if an AZ has an interruption, no worries. Your application will automatically switch over to the backup AZ you have configured. Even better, if you set it up correctly, your customers won’t even notice a difference. ‘Cause let’s be honest, nobody wants their favorite meme site or coffee shop app to go down! Additionally, **multi-AZ architectures** can assist with **quicker disaster recovery**, improved business **continuity**, **lower latency,** and **compliance**.

But as with anything in the world, there are multiple ways to peel an orange. In fact, you can go one step further and deploy your application in multiple AWS Regions. So, if a whole Region experiences an interruption, you can failover to another one. Orange you glad you chose AWS as your cloud provider?

Some of you might say, “Wait, wait, wait, Rudy, multi-Region and multi-AZ deployments? This sounds like some sort of pinball machine.” Well, yeah, it is exactly like a pinball machine but with a multi-ball bonus. It can be difficult to juggle multiple pinballs initially. They are moving in different directions, and you might stress about keeping track of all of them. However, once you come up with a strategy and you get some experience, it gets much easier.

So, don't worry too much about perfecting your AWS global infrastructure right off the bat. Just like pinball, planning and executing multi-AZ and multi-Region deployments gets easier after you’ve practiced a bit. Who knows, some day you might even get an AWS infrastructure high score! Just kidding, I don't think that's a thing. Is that a thing? Oh, it might be a thing. Oh wait..

Oh, looks like Rudy’s Rhubarb Refresher, trademark, is so popular that people are making memes of it! However, images are loading slowly for some people on the app. Let’s fix that by utilizing Amazon CloudFront. **CloudFront** is a **content delivery network**, and it’s designed to **serve conten**t **as close to users** as possible. This content can be images, data, videos, applications, APIs—and, in our case—memes.

CloudFront uses **Edge locations**, which are part of our worldwide **Amazon Global Edge Network**. These edge locations are actually **separate from Regions** and are specifically designed to **accelerate content delivery**. Edge locations host other AWS services, like **AWS Global Accelerator** and **Amazon Route 53**. Route 53 is a Domain Name System, or **DNS**, that **routes end users** to **internet applications**. Essentially, it converts human-readable URLs to machine-readable IP addresses. ‘Cause trust me, you don’t want to have to remember IP addresses by heart.

And don't forget about **AWS Outposts**. Say you have a need. And that need is for **speed**. More speed than even a **Region paired with CloudFront** can achieve. This is where Outposts comes in handy. As you might recall, Outposts essentially makes it possible for you to run AWS services on-premises. Look, keep these **multi-deployment concepts** and edge services in your brain as you continue to explore AWS global infrastructure.

AWS Regions are physical locations around the world where AWS has multiple Availability Zones. Edge locations are located outside of AWS Regions and cache frequently accessed content.

### Infrastructure and Automation  

By now, you know that in order to manage AWS resources, you have to interact with AWS APIs. You've learned how to do this using the Management Console, the CLI, and SDKs. But what happens when you need to create and manage multiple resources, possibly across multiple AWS Regions or multiple accounts, and you want to make sure everything is **consistent** and **repeatable**?

Say you have resources in Region A, and you want to launch them in Region B for high availability. You could set everything up manually by clicking through the console or running commands, remembering all of your configurations as you go along, but that’s slow, error-prone, and hard to reproduce. Or you can use **automation** and this is where the concept of **infrastructure as code**, or IaC, comes in.

You can use **IaC** to define your infrastructure in a file, almost like a **blueprint** for your **AWS architecture**. You can then use tools or services to automatically build and configure your resources based on your blueprint specifications. You can deploy the same setup multiple times without variation, and you can **track changes** to your infrastructure more effectively using **source control.**

**AWS CloudFormation** is an IaC service that you can use to define a wide variety of AWS resources in a **declarative way** by creating **text-based documents** called **CloudFormation templates**. You can define what resources you want to build without specifying the details of exactly how to build it. CloudFormation parses the template and then provisions all of the resources you defined, calling the needed AWS APIs in the background to make it all happen.

When you deploy the same template in multiple accounts or multiple Regions, identical environments are created across them. There’s less room for human error, because it's a totally automated process. So now, instead of manually setting up resources in Region B to match Region A, you can create a CloudFormation template that **defines everything your infrastructure needs**. With a **single command**, AWS provisions those resources exactly as defined.

And, hey, look at that, you've saved time, reduced the margin for error, and made your architecture more resilient. Nice work. You're really starting to catch on to all of this cloud practitioner stuff.



## Module 5 - Networking 

### introduction to Networking

Looks like things are really moving forward in our coffee shop. Though, we had a few eager customers go full steam ahead and yell their orders at the baristas! Tsk tsk.

They should be politely asking the cashiers instead. This does bring up an interesting point, however. It just doesn't make sense to allow every customer to be able to interact with the baristas in the back. After all, our baristas need to stay focused on crafting caffeinated beverages. So, what do we do?

Well, we need to limit access to the baristas, and let customers interact only with our cashiers. And wouldn’t you know it, we can use AWS networking to accomplish that. Specifically, a networking concept called **Amazon Virtual Private Cloud**, or **VPC**. VPCs help you provision a **logically isolated section** of the AWS Cloud.

In this virtual network, you can launch whatever resources you decide on. More importantly, these resources can be **public** or **private**. Public-facing resources have access to the internet, whereas private resources do not have **internet access.**

This is perfect for our coffee shop. We can make our cashiers publicly-accessible so they can interact with our customers to take their order and process payments. We can then prevent our customers from interacting directly with the baristas by making them private resources. This means, hey, I can focus on making drinks! Ahhhhh, refreshing.

Okay, time to dive into more networking concepts. Good luck!

#### Amazon Virtual Private Cloud (Amazon VPC)

An Amazon VPC lets you provision a logically isolated section of the AWS Cloud where you can launch AWS resources in a virtual network that you define.

#### Subnet

Subnets are used to organize your resources and can be made publicly or privately accessible. A private subnet is commonly used to contain resources like a database storing customer or transactional information. A public subnet is commonly used for resources like a customer-facing website.

| **Feature**         | **Virtual Private Cloud (VPC)**                                                                 | **Subnet**                                                                                                         |
| :------------------ | :---------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------- |
| **Scope/Size**      | The **entire virtual network** in a Region.                                                     | A **segment** of the VPC's IP address range.                                                                       |
| **IP Addresses**    | Defines the **total range of all private IP addresses** that can be used (e.g., `10.0.0.0/16`). | Defines a **smaller range of usable IP addresses** taken from the VPC's range (e.g., `10.0.1.0/24`).               |
| **Isolation Level** | **Logically isolates** your network from all other customers in the public cloud.               | Isolates resources **within the VPC** for organization and security (e.g., separating web servers from databases). |
| **Geographic Span** | **Spans an entire AWS Region**.                                                                 | **Restricted to a single Availability Zone (AZ)** within a Region. This is key for high availability.              |
| **Key Components**  | Contains Subnets, Route Tables, Internet Gateways, NAT Gateways, and Security Groups.           | Contains your actual resources (EC2 instances, RDS databases, etc.) and is linked to a Route Table.                |

#### Networking components: Understanding connections through diagrams

If you are new to IT or cloud computing, you might not have worked with architectural diagrams before. A diagram is, simply put, a schematic or map of your network in the AWS Cloud. It can provide a visual of how users or applications access services, resources, or data. With a quick glance, you can see if the network was built for redundancy, security, and even scalability. It can also serve as a blueprint so you don't forget important connections when building your solutions.

![image](../Images/Media/image%20(12).png)
[image](../Images/image%20(12).md)

**Amazon VPC** is a solid box, and it represents your isolated, logically segmented network within AWS. A VPC helps you to control your network resources and security.

**Subnets** are essentially segments of your VPC, allowing you to divide your VPC into smaller, manageable sections. A subnet is a range of IP addresses in your VPC.

**Private subnets** are designed to isolate resources that shouldn't be directly exposed to the public internet. In diagrams, they are illustrated with solid boxes.

**Public subnets** are designed to provide direct internet access to resources placed inside them. To allow access, they are connected with an internet gateway.

### Organizing AWS Cloud Resources 

To reiterate, a VPC, or virtual private cloud, is essentially **your own private network** in **AWS**. When you use a VPC, you can define your **private IP range** for your AWS resources and place things, like EC2 instances and elastic load balancers, inside of your VPC.

Now, you don't just go throwing your resources into one big VPC network space and then move on. Instead, you place them into different **specific subnets**. Subnets are chunks of **IP addresses** in your VPC that you can use to **group resources together**. Subnets, along with **networking rules** that we will cover later, control whether resources are either **publicly** or **privately** available.

This idea of public compared to private access to resources is super important. For some VPCs, you might have **internet-facing resources** that the public should be able to reach, like a **public website** or a **load balancer**, for example.

However, in other scenarios, you might have resources that you only want to be reachable if someone is logged into your private network. This might be internal services, like an HR application or a **backend database**.

First let’s talk about public-facing resources. To allow traffic from the public internet to flow into and out of your VPC, you must attach what is called an **internet gateway** to your VPC. An internet gateway is like a doorway that is open to the public.

![image](../Images/Media/image%20(13).png)
[image](../Images/image%20(13).md)

Think of the coffee shop. Without a front door, the customers couldn't get in and order their coffee. So, you install an entrance, and the people can enter and exit when coming and going from the shop. The front door in this example is like an internet gateway. Without it, no one can reach the resources placed inside of your VPC.

Next, let's talk about a VPC with all internal private resources, when you don't want an internet gateway attached to your VPC. Instead, you want a private gateway that only allows people in if they are coming from an approved network, not the public internet. This private doorway is called a **virtual private gateway**, and it allows you to create a **VPN connection** between a private network, like your on-premises data center or internal corporate network to your VPC.

![image](../Images/Media/image%20(14).png)
[image](../Images/image%20(14).md)

To relate this back to the coffee shop, this would be like if the coffee shop was located inside of a private corporate office building. If I want to go get coffee, I have to badge in to verify my identity. Then I can access the internal coffee shop that only people with access to the building can use. So, if you want to establish an encrypted **VPN connection** to your private internal AWS resources, you need to attach a **virtual private gateway** to your VPC.

Now, something to note about the coffee shop in the private corporate office building is that this office building is shared by multiple companies, and there are a lot of people who work here. Even though I have special access to the coffee shop, I still might have to wait for the elevator, navigate crowded hallways, or stand in line.

This is similar to how a VPN works. While it provides a **secure connection**, it still **routes your traffic** through a **shared network**, which can sometimes lead to **slowdowns**, especially when many people are using it at the same time. It’s not that the VPN itself is slow or a bad option, but rather you may need **higher bandwidth** or a **dedicated line** in certain scenarios.

Now, if I had a direct, super-secret magic doorway that led from the studio straight into the coffee shop, I'd bypass any congestion and have a **reliable**, **high throughput**, coffee **connection** at any time. That sounds pretty nice. This is a similar idea behind wanting **dedicated private connection** to AWS.

### More Ways to Connect to the AWS Cloud 

#### Connecting to the AWS Cloud

With so many different types of networks, on-premises datacenters, and remote workers, companies need a wide range of ways to connect to the AWS Cloud. In the following section, you will learn four ways to connect to the AWS Cloud:

---



- AWS Client VPN

- AWS Site-to-Site VPN

- AWS PrivateLink

- AWS Direct Connect


---

![image](../Images/Media/image%20(15).png)
[image](../Images/image%20(15).md)

---

#### Securely connect a remote workforce to AWS Cloud resources -**AWS Client VPN**

---

**AWS Client VPN**

Imagine a company with a recent acquisition needing to securely connect their new remote workforce to their AWS Cloud resources. Even the largest companies with worldwide remote workers can quickly scale up and connect to the AWS Cloud. That's where **AWS Client VPN** can help.


---

![Client-VPN](../Images/Media/Client-VPN.png)
[Client-VPN](../Images/Client-VPN.md)

---

AWS Client VPN connects your remote workforce to AWS or on-premises with a VPN.

AWS Client VPN is a networking service you can use to connect your remote workers and on-premises networks to the cloud. It is a **fully managed,** **elastic** VPN service that **automatically scales** up or down based on user demand. Because it is a **cloud VPN solution**, you don’t need to install and manage hardware or try to estimate how many remote users to support at one time.

**Benefits:** AWS Client VPN provides advanced authentication, remote access. It is elastic and fully managed.

**Use case:** It can be used to quickly scale remote-worker access.

Client VPN, a managed VPN service, provides secure access to AWS resources and on-premises networks from anywhere. It uses an **OpenVPN-based client**, and it works with global Regions by using the AWS global network.

#### Securely connect sites to other sites - **AWS Site-to-Site VPN**

---

**AWS Site-to-Site VPN**

Some companies might want to establish secure, encrypted connections between their on-premises networks like data centers or branch offices and their resources in their Amazon VPC. That's where Site-to-Site VPN can help.


---

![Site-to-Site-VPN](../Images/Media/Site-to-Site-VPN.png)
[Site-to-Site-VPN](../Images/Site-to-Site-VPN.md)

---

AWS Site-to-Site VPN is an encrypted network connection to your Amazon VPCs.

Site-to-Site VPN creates a secure connection between your data center or branch offices and your AWS Cloud resources.

**Benefits:** Site-to-Site VPN provides high availability, secure and private sessions, and accelerates applications. AWS Site-to-Site VPN accelerates applications primarily by routing traffic through the highly optimized **AWS global network backbone by using AWS Global Accelerator** instead of relying solely on the public internet.

**Use cases:** It can be used for application migration and secure communication between remote locations.

#### Securely connect resources, even in other VPCs - **AWS PrivateLink**

---

**AWS PrivateLink**

Other companies sometimes need the flexibility to privately connect to resources in other cloud providers as though they were in their own VPC. They need a way to **communicate** with these resources and don't want the hassle of setting up gateways or site-to-site VPNs. That's where AWS PrivateLink can help.


---

![PrivateLink](../Images/Media/PrivateLink.png)
[PrivateLink](../Images/PrivateLink.md)

---

AWS PrivateLink connects your VPC privately to services and resources as though they were in your VPC.

AWS PrivateLink is a highly **available**, **scalable** technology that you can use to **privately connect** your **VPC** to **services** and **resources** as if they were in your VPC. You do not need to use an internet gateway, NAT device, public IP address, Direct Connect connection, or AWS Site-to-Site VPN connection to allow communication with AWS services or resources from your private subnets. Instead, you **control** the **specific API endpoints, sites, services, and resources** that are reachable from your VPC. It achieves this by making the external service appear as if it is **hosted directly within your own private VPC. (never leaves the AWS network)**

**Benefits:** AWS PrivateLink helps you secure your traffic and connect with simplified management rules.

**Use case:** It is used for connecting your clients in your VPC to resources, other VPCs, and endpoints.

Even though the preceding connections are highly available and scalable, traffic jams are possible because you’re using the **same connection** as **other clients.** That's why for some use cases, you might need a dedicated private connection with a lot of bandwidth.

| **Feature**            | **Simple Explanation**                                                                                  | **Benefit**                                                                                                                                                                                  |
| :--------------------- | :------------------------------------------------------------------------------------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **No Public Internet** | Traffic stays entirely within Amazon's private, high-speed network.                                     | **Enhanced Security:** Dramatically reduces exposure to threats like DDoS or data interception.                                                                                              |
| **VPC Endpoint**       | You place a small network interface (called a VPC Endpoint) in your private Subnet.                     | **Simplified Access:** Your application uses a **private IP address** on that endpoint to talk to the external service. You don't need to manage complex routing, NAT, or Internet Gateways. |
| **Service-Specific**   | The connection is only to a single, specific service (e.g., an API), not the provider's entire network. | **Tighter Control:** Provides a smaller attack surface and simplified security group management.                                                                                             |

#### AWS Direct Connect 

---

With AWS, you can achieve that using a service called **AWS Direct Connect**. Direct Connect lets you establish a completely private, dedicated **fiber connection** from **your data center to AWS**. It ensures both **security** and **consistent high performance.** You work with a **Direct Connect partner** in your **area** to establish this connection because, like my magic doorway, Direct Connect provides a **physical line** that connects your network to your Amazon VPC. This can help you meet **regulatory** and **compliance needs**, as well as sidestep any potential **bandwidth issues.**


---

![Direct-Connect](../Images/Media/Direct-Connect.png)
[Direct-Connect](../Images/Direct-Connect.md)

---

Thanks for listening. I'm gonna hang out here and keep ordering magic drinks from my magic door. See ya.

With a virtual private gateway, you can establish a VPN connection between your VPC and a private network, such as an on-premises data center or internal corporate network. A virtual private gateway allows traffic into the VPC only if it is coming from an **approved network.**

![image](../Images/Media/image%20(16).png)
[image](../Images/image%20(16).md)

**Latency-sensitive applications**

Direct Connect **bypasses** the **internet** and provides a **consistent, low-latency** **network** experience. This makes it ideal for applications like video streaming and other real-time applications that require high performance.

**Large-scale data migration or transfer**

Direct Connect helps ensure smooth and **reliable** data transfers at **massive scale** for **real-time analysis**, **rapid data backup**, or **broadcast media** processing.

**Hybrid cloud architectures**

You can use Direct Connect to link your AWS and on-premises networks to build applications that span environments without compromising performance.

#### PrivateLink vs Direct Connect 

| **Feature**             | **AWS PrivateLink**                                                                                                                                    | **AWS Direct Connect (DX)**                                                                                                                      |
| :---------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------- |
| **What it is**          | A **logical** connection (a virtual endpoint) to an **AWS-hosted service** or resource.                                                                | A **physical** connection (a dedicated fiber optic line) from your **on-premises data center** to an AWS location.                               |
| **Scope of Connection** | **VPC-to-Service** (or VPC-to-VPC).                                                                                                                    | **On-Premises-to-AWS Network**.                                                                                                                  |
| **Traffic Flow**        | Traffic **never leaves the AWS private network backbone**; it stays entirely in the cloud.                                                             | Traffic **leaves your physical premises** and enters the AWS network over a dedicated, private line.                                             |
| **Goal**                | **Security & Simplification.** To make a remote service (like S3, a SaaS API, or another company's VPC) look like it is **local** to your private VPC. | **Performance & Reliability.** To get high-bandwidth, stable, and low-latency access to your AWS resources by **bypassing the public internet**. |
| **Use Case Example**    | Accessing a public AWS service (like S3) or a vendor's API using a **private IP address** from your EC2 instance.                                      | Accessing your VPC or Transit Gateway from your **corporate data center** for hybrid cloud operations.                                           |

---

[Site-to-Site VPN vs. PrivateLink vs. Direct Connect](../Tables/Site-to-Site%20VPN%20vs%20PrivateLink%20vs%20Direct%20Connect.md)


#### Additional gateway services 

**AWS Transit Gateway**

---

AWS **Transit Gateway** is used to connect your Amazon **VPCs** and on-**premises networks** through a **central hub.** As your cloud infrastructure expands globally, inter-Region peering connects transit gateways together using the AWS Global Infrastructure. To learn more, refer to [AWS Transit Gateways(opens in a new tab)](https://aws.amazon.com/transit-gateway/).


---

![Transit-Gateway](../Images/Media/Transit-Gateway.png)
[Transit-Gateway](../Images/Transit-Gateway.md)

---

**Network Address Translation (NAT) Gateway**

A NAT gateway is a NAT service. You can use a NAT gateway so that instances in a private subnet can connect to services outside your VPC but external services can't initiate a connection with those instances. To learn more, refer to [NAT gateway(opens in a new tab)](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-nat-gateway.html).

**Amazon API Gateway**

---

You learned about Application Programming Interface (API)s earlier. Quick refresher, an API defines how different software systems can interact and communicate with each other. The Amazon API Gateway is an AWS service for creating, publishing, maintaining, monitoring, and **securing API**s at any scale. To learn more, refer to [Amazon API Gateway(opens in a new tab)](https://aws.amazon.com/api-gateway/).


---

![API-Gateway](../Images/Media/API-Gateway.png)
[API-Gateway](../Images/API-Gateway.md)

---

### Subnet, Security Groups. and Network Access Control Lists

Welcome to your virtual private cloud, or VPC. You can think of it as a hardened fortress, where nothing goes in or out without explicit permission via the appropriate gateways. But that only covers perimeter, and that's only one part of network security that you should be focusing on as part of your IT strategy. AWS has a wide range of tools that cover every layer of security: **Firewalls**, distributed denial-of-service, or **DDoS prevention**, **encryption**, and much more. We're gonna talk about these a bit later in the security section.

Today, I wanna talk about a few aspects of network hardening looking at what happens inside the VPC. One of the main reasons to use subnets in a VPC is to control access to the gateways. The public subnets have access to the internet gateway, the private subnets do not. But **subnets** can also **control traffic permissions**. **Packets** are **messages** from the internet, and every packet that crosses the subnet boundaries gets checked against something called a **network access control list**, or **network ACL**. This check is to see if the packet has **permissions** to either leave or enter the subnet, based on wh**o it was sent from** and **how** it's trying to **communicate**.

You can think of network ACLs as passport control officers. If you're on the approved list, you get through. If you're not on the list, or if you're explicitly on the do-not-enter list, then you get blocked. **Network ACLs check traffic going into and leaving a subnet**. The list gets checked on your way in and on the way out. And just because traffic is let in doesn't necessarily mean they're gonna let responses back out. Only **explicitly approved traffic** can be sent on its way.

Now, this sounds like great security, but it doesn't answer all of the network control issues. A network ACL only gets to evaluate a packet if it crosses a subnet boundary, in or out. It doesn't evaluate if a packet can reach a specific EC2 instance or not. Sometimes, you will have multiple **EC2 instances** in the same subnet, but they might have different rules around who can send them messages and what **port** those **messages** are **allowed** to be **sent to**. So, you need **instance-level network security,** as well.

To solve instance-level access questions, we introduce **security groups**. Every EC2 instance, when it's launched, **automatically** comes with a **security group**. And by **default**, the **security group does not allow any traffic into the instance** at all. All **ports** are **blocked**. All **IP addresses** sending packets are **blocked**. That's very secure, but perhaps not very useful if you want an instance to actually **accept traffic** from the **outside**, like, say, a message from a frontend instance or a message from the Internet. So, obviously, you can modify the security group to accept a specific type of traffic.

In the case of a **website**, you want web-based traffic like **HTTPS** to be **accepted** but not other types of traffic. If network ACLs are a passport control, a security group is like the doorman at your building, the building being the EC2 instance, in this case. The doorman will check a list to ensure that someone is **allowed** to **enter** the building but **won't** bother to **check** the list on the way **out**. With security groups, you **allow specific traffic in**, and by **default**, **all traffic is allowed out**.

I just described two different things letting good packets in and keeping bad packets out. The key difference between a security group and a network ACL is the **security group** is **stateful**. That means, as we talked about, it has some kind of a **memory** when it comes to **who to allow in or out**. And the network **ACL** is **stateless**, which remembers nothing and **checks every single packet** that crosses its border regardless of any circumstances. You know, this metaphor is important to understand. So, I wanna illustrate the round trip of a packet, as it goes from one instance to another instance in a different subnet. Now, this traffic management, it doesn't care about the contents of the packet itself. In fact, it doesn't even open the envelope. It can't. All it can do is check to see if the **sender** is on the **approved list.**

Alright, let's start with a couple instances, and we wanna send a packet from instance A to instance B in a different subnet, same VPC, different subnets. So, instance A sends the packet. Now, the first thing that happens is that packet meets the boundary of the security group of instance A. By default, all outbound traffic is allowed from a security group. So, you can walk right by the doorman and leave. Cool. Right. The **packet** made it **past the security group** of instance A.

![image](../Images/Media/image%20(17).png)
[image](../Images/image%20(17).md)

Now, it has to leave the **subnet boundary**. At the boundary, the packet must now make it through passport control, the **network ACL**. The network ACL doesn't care about what the security group allowed. It has its own list of who can pass and who can't. If the **traffic address** is **allowed**, you can keep going on your journey, which it is. It's **left Instance A** and **Subnet 1** entirely, so now it must go through to **Subnet 2**, where it's **checked** by **Subnet 2's incoming Network ACL** ***AND*** through the **security group** of Instance B. Once through those, Instance B can receive and process the request.

![image](../Images/Media/image%20(18).png)
[image](../Images/image%20(18).md)

After the transaction's complete, now it's time to come home. It's the **return traffic pattern**. It's the most interesting because this is where the stateful compared to stateless nature of the different engines comes into play—because the packet still has to be **evaluated** at **each checkpoint. Security groups**, by default, allow all return traffic. So, they don't have to check a list to see if they're allowed out. Instead, they **automatically allow the return traffic to pass by**, no matter what.

At the **subnet boundary**, these network ACLs do **not remember state**. Every entrance and exit is checked with the appropriate list.  Stateless controls mean it **always checks its list**. Instance B's security group is first to evaluate, and since it's return traffic—and this security group saw the original request packet—the return traffic is allowed. The Network ACL of Subnet 2 goes to evaluate, and being stateless, it has to check the list again.

By the way, this is a **different list than on the way in.** Network ACLs have **rules** for both **incoming** and **outgoing** and they can be **different**. Now on the Instance A side, our packet is inspected as the stateless Network ACL of Subnet 1 checks the list every time. And the last check is the **security group of Instance A**. Again, because this is **return traffic**, it **doesn't check the list** on the **way back in**. So, the packet is **allowed**, and on it goes to complete the flow at Instance A.

It might seem like we spent a lot of effort just getting a packet from one instance to another and back. You might be concerned about all the network overhead this might generate. The reality is all of these exchanges happen instantly as part of how AWS networking actually works. That's why it's important to learn all of this.

You want to ensure your **IT strategy** and design includes defining the **rules** for your **security groups** and **Network ACLs**. That way, your network design will meet your specific needs while also ensuring good network security. After all, security is a critical consideration in all networking for modern architectures.

#### Network traffic in a VPC

**The movement of data packets traveling across a network**

When a customer requests data from an application hosted in the AWS Cloud, this request is sent as a packet. A packet is a unit of data sent over the internet or a network.

It enters into a VPC through an internet gateway. Before a packet can enter into a subnet or exit from a subnet, it will run into several checks for permissions, one being a network ACL associated with the subnet the packet is being routed to. The permissions defined by the network ACLs indicate what is allowed or denied. It is based on who sent the packet and how the packet is trying to communicate with the resources in a subnet.

![image](../Images/Media/image%20(19).png)
[image](../Images/image%20(19).md)

#### Network ACLs

**Virtual firewall controlling traffic**

A network ACL is a virtual firewall that controls inbound and outbound traffic at the subnet level.

For example, imagine that you are at the airport. Travelers are trying to enter into a different country. You can think of the travelers as packets and the passport control officer as a network ACL. The passport control officer checks travelers’ credentials when they are both entering and exiting the country. This is similar to how a network ACL checks permissions every time a packet travels across a subnet boundary.

Each AWS account includes a default network ACL. When configuring your VPC, you can use your account’s default network ACL or create custom network ACLs. By default, your account’s default network ACL allows all inbound and outbound traffic, but you can modify it by adding your own rules.

![image](../Images/Media/image%20(20).png)
[image](../Images/image%20(20).md)

For **custom** network **ACLs**, all **inbound** and **outbound** traffic is **denied** until you **add rules** to specify which traffic to allow. Additionally, all network ACLs have an **explicit deny rule**. This rule makes sure that if a packet doesn’t match any of the other rules on the list, the packet is denied.

 When it comes to securing the subnets and resources in your VPC with network ACLs and security groups, that is your responsibility.

[AWS Security Groups](../Concepts/AWS%20Security%20Groups.md)

#### Security Groups vs Network ACLs

| Feature            | Security Groups                                                       | Network ACLs                                                 |
| :----------------- | :-------------------------------------------------------------------- | :----------------------------------------------------------- |
| **Scope**          | Instance level (attached to EC2 instances)                            | Subnet level (associated with subnets)                       |
| **State**          | Stateful (remembers state)                                            | Stateless (doesn't remember state)                           |
| **Rule types**     | Only allow type rules                                                 | Both allow and deny type rules                               |
| **Return traffic** | Return traffic is automatically allowed if inbound traffic is allowed | Return traffic must be implicitly allowed in both directions |
| **Uses**           | Fine-grained control of traffic for individual EC2 instances          | Broad control of traffic in and out of subnets               |

### Amazon Networking Demo

It's time to see how all this networking stuff really works in action. In this demo, I'm going to walk you through how to set up the network components you've just learned about.

Although this might not be something you personally would be required to do when working with AWS, I still want to show you how it works with a practical example using the AWS Management Console so you can wrap your head around it.

Let's start with the big picture of what we'll be building. We 'll go through how to create a VPC, public and private subnets, an internet gateway, and a route table for our public subnets.

![image](../Images/Media/image%20(21).png)
[image](../Images/image%20(21).md)

Let’s jump into the first task, which is creating the **VPC**. In the search bar, I'll type  in VPC, then choose VPC. This brings us to the **VPC dashboard**, and I’ll now choose **create VPC**. On the Create VPC page, for Resource to create, I will choose **VPC Only**. For Name tag, I'll give it a name, like My VPC. And now it asks for something called a **classless inter-domain routing address,** or **CIDR** range. This address is used to define the **block of private IP addresses** available to assign to any resources launched into the VPC. We are going to use IPv4 addresses. So we can enter a value like this: four numbers divided by periods like 10.0.0.0/16. Then, scroll down and select Create VPC. With this, every resource in my VPC will get a **private IP address** that starts with 10.0, then the second two numbers will **vary from resource to resource**, each one having a **unique address** in the **VPC**.

The next task is to create the subnets. We are going to create both public and private subnets across two different Availability Zones, or AZs. This is a best practice to achieve high availability for your applications. It allows your instances to remain accessible, even if one AZ experiences an outage, by distributing them across separate physical locations within the same AWS Region.

Let's start by creating the private subnets first. Quick refresher, a **subnet** is a **range of IP addresses** in your VPC. You can launch AWS resources into a specified subnet. Use a public subnet for resources that must be connected to the internet, and a private subnet for resources that won’t be connected to the internet.

I'll start with the private subnet. To create your private subnet, in the **left navigation pane**, under Virtual private cloud, **choose Subnets**. Then select **Create subnet**. On the Create subnet page, for VPC ID, I’ll choose My VPC from the drop-down and then scroll down. Here under Subnet settings for **subnet name**, I'll type in Private-subnet-1. And then for Availability Zone, I will select us-east-1a.  For IPv4 VPC CIDR block, that reflects the VPC CIDR block 10.0.0.0/16, and then we need to find the CIDR block for this subnet. Which will be **10.0.1.0/24**.  Then we can select, Create subnet. Now our private subnet has been created, I will select it and then **select Actions**, and then select **Edit subnet settings**. On this page, there is this setting for **Auto-assign IP settings**, I want to make sure this is **not set**, because enabling this setting would give every resource in the subnet a public IP. This is a **private subnet**, so we don’t want that. I’ll go ahead and select cancel.

I won't demo the steps for time sake, but I would repeat these steps to create the **second private** subnet, placing it in a different Availability Zone and choosing a **different CIDR range,** like **10.0.2.0/24**. Alright, and our second subnet has been created.

Next, I'll create the **public subnets**. To do that I will select Create subnet. On the Create subnet page, for VPC ID, I will select My VPC from the drop-down. For Subnet name, I will enter Public-subnet-1. And then for the Availability Zone, I will us-east-1a. And for IPv4 subnet CIDR block, I will enter **10.0.3.0/24**. And then I will select Create subnet. Now our **public** subnet has been created. In the Actions menu, I will select Edit subnet settings.  And then I will **check** the check box for **enabling auto-assign public IPv4 address**. This setting, provides a **public IPv4 address** for all instances or resources launched into this public subnet. Then, I will choose Save.

Now I would need to repeat those steps to create the second public subnet, placing it in a different Availability Zone and choosing a different CIDR range like **10.0.4.0/24.**

Now all four subnets have been created, two public and two private, spread across two different availability zones for this one VPC. It's important to note that even though your subnets are labeled Public 1 and Public 2, they are **not yet public subnets**. First, the **VPC** needs an attached **internet gateway,** which we will attach in the next step. Then, we need to create the **appropriate routes** in the **route tables**. Again, don't worry too much about remembering all of this.

So now let's go ahead and get that **internet gateway** created so that the public subnets can actually **connect** to the **internet**. In the **navigation pane, under Virtual private cloud**, I will choose **Internet gateways**. Then I will choose **Create** internet gateway. On the Create internet gateway page, for Name tag, I will enter in **my-ig**, and then select Create internet gateway. Then I will select **Actions**, and then **Attach to VPC**.  In the search box, I will select My VPC, and then choose Attach internet gateway.

So now the internet gateway is attached to your VPC. Even though we now have created an internet gateway and it is attached, we still have to **tell instances** with**in the public subnet** **how to get to the internet**. That’s where the **route table** comes in.

A **route table** contains a **set of rules**, called **routes**, that are used to determine **where network traffic is directed**.  **Each subnet** in your VPC must be **associated with a route table**. The table controls the routing for that subnet. So, to set up a route table in the console, we will go to the **navigation pane**, and then we will select **Route tables.**

We need to create a route table to **route public traffic** to the **internet gateway**. I will choose **Create route table**. And then on this page, for Name I will enter **public-route-table**. And then for the VPC, from the drop-down I will select My VPC and then choose Create route table.

Now that a route table is created, under the Routes tab there is one route in your route table that allows traffic within the VPC to flow **within** the network, but it does **not route traffic outside of the network.** So, we need to add a **new route** to enable **public traffic.**

I will choose Edit routes. And then I will choose Add route. And for this route, under the **Destination**, I will enter **0.0.0.0/0**. And then for **Target**, I will select the **internet gateway** that we just **created and attach to this VPC**, and then I will select Save changes.

Now we need to associate this route table with our public subnets.

I will choose the **Subnet associations tab**. And in the **Explicit subnet associations section**, I will select **Edit subnet associations**. And then I will select **Public-subnet-1 and Public-subnet-2**. Then I will choose Save associations. The subnet is now **public** because it is **connected to the internet** through the **internet gateway**. But the private subnets do not have that route so they remain private.

Now that we've created a VPC, four subnets, an internet gateway, and route tables, how could you filter the traffic coming in and out of this VPC? That's right, with **security groups** and **network access control lists**, or network **ACLS**. Remember those **CIDR blocks** you created earlier? Well **security groups** also use **CIDR blocks** to define sources or destinations for **network traffic**. This way, everything is secure and you decide who can access what resources based on your needs.

![image](../Images/Media/image%20(22).png)
[image](../Images/image%20(22).md)

[Flowchart Maker & Online Diagram Software](https://viewer.diagrams.net/?tags=%7B%7D&lightbox=1&highlight=0000ff&edit=_blank&layers=1&nav=1&transparent=1&dark=auto#G11E7IrGEF6Mh3sWYOoQOC7nTuedvKsAUk)

### Global Networking 

Folks, we've been talking a lot about how you interact with your AWS account, the services you deploy, and the applications you build. But how do your customers interact with your apps?

Say you are hosting a website. Your customers would typically type that website’s address into their browser, press the Enter key, and before you know it, some magic happens—and the site lights up! If you’re wondering where the magic comes in, it’s like this coin that I have here right. I take a bite, ptooie! And it's back.

Well, not quite like that, but I'm going to take you through two services, which will help the website example make cents. Get it. The first is **Amazon Route 53**. Route 53 is a **domain name service**, or **DNS**. DNS acts as a translation service. However, instead of translating between languages, DNS translates website names into Internet Protocol, or IP addresses.

---

#### **Amazon Route 53**

Route 53 is a highly available and scalable cloud DNS service.


---

![Route-53](../Images/Media/Route-53.png)
[Route-53](../Images/Route-53.md)

---

Humans can read website names and computers can read IP addresses. This acts as the bridge between the two. As an example of how it works, we type a website address into our browser and press the Enter key. The browser contacts Route 53 and asks it for the corresponding IP address of the site. Let’s say, 192.2.0.2. The browser then knows where to go and gets routed to the website using that IP address. Additionally, Route 53 can route traffic to **different endpoints** using several different routing policies. These include **latency-based routing**, **geolocation**, **geoproximity**, and **weighted round robin**.

If we take **geolocation**, for example, this policy directs traffic based on where the **customer** is **located**. So, if a customer is located in North America, they are routed to one of the North American Regions. Likewise, if they are located in Ireland, they are routed to the Dublin Region. You can even use Route 53 to **register domain names**. Pick a domain name, check if it’s available, and buy it using Route 53.

---

#### **Amazon CloudFront**

CloudFront is a CDN service that delivers your content with low latency and high speeds.


---

![CloudFront](../Images/Media/CloudFront.png)
[CloudFront](../Images/CloudFront.md)

---

The other service that comes to the rescue is **Amazon CloudFront**. If you remember, we talked about **edge locations** earlier in the course. These locations serve content as close to customers as possible, and one part of that is a content delivery network, or **CDN**.

Let’s go back to our Regions example. Say we have a user in Seattle, and they want to access a website. To speed this up, we host the site in Oregon and deploy our static web assets, like images and GIFs (or GIFs) in CloudFront's Seattle location. Shorter distance equals quicker delivery times.

![image](../Images/Media/image%20(23).png)
[image](../Images/image%20(23).md)

I hope you are content after learning about these two services. So, thanks for following along, and I'm going to disappear just like this red cloth. So let's do this. Just pack it in. Abracadabra! Wow. Magic!

---

#### **AWS Global Accelerator**

Global Accelerator is a service that uses the **AWS global network** to improve application availability, performance, and security.


---

![Global-Accelerator](../Images/Media/Global-Accelerator.png)
[Global-Accelerator](../Images/Global-Accelerator.md)

---

It uses **intelligent traffic routing** and **fast failover** if something goes wrong in one of your application locations.

Global Accelerator is a networking service that helps your applications run faster and more reliably across the globe. Think of it like creating express lanes on the internet highway specifically for your application's traffic. Instead of your users' requests taking the regular, sometimes congested internet routes, Global Accelerator directs traffic through the AWS private global network—getting your users to your application faster and more reliably.

- **IP Addresses:**

    - If your application requires a **fixed, static IP address** for whitelisting or consistency (common in enterprise applications), you must use **Global Accelerator**. CloudFront uses dynamic IP addresses.

- **Protocols:**

    - If you need to accelerate non-HTTP/HTTPS traffic (like **UDP** for online gaming or **TCP** for secure batch transfers), **Global Accelerator** is the necessary choice as CloudFront is built primarily for web protocols.

| **Feature**                | **Amazon CloudFront (CDN)**                                                                         | **AWS Global Accelerator (Network Service)**                                                                         |
| :------------------------- | :-------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------- |
| **Primary Goal**           | **Speed up content delivery** by caching.                                                           | **Improve application availability and performance** by optimizing network path.                                     |
| **Optimization Technique** | **Content Caching** at edge locations.                                                              | **Optimal Routing** over the AWS global network backbone.                                                            |
| **Layer of Operation**     | **Application Layer (Layer 7)**—Understands HTTP semantics.                                         | **Network Layer (Layer 4)**—Focuses on IP and transport layer.                                                       |
| **Protocols**              | **HTTP/HTTPS** (Optimized for web traffic).                                                         | **TCP, UDP, and HTTP/HTTPS** (Handles a wider range of application traffic, like gaming or VoIP).                    |
| **IP Addressing**          | Uses **dynamic, DNS-based** names (CNAME) that resolve to changing edge IP addresses.               | Provides **two static Anycast IP addresses** as a fixed entry point to the application.                              |
| **Failover**               | Distributes content from a primary origin; less focused on **instantaneous** multi-Region failover. | Provides **instantaneous regional failover** (within 60 seconds) by routing traffic away from an unhealthy endpoint. |
| **Best Use Cases**         | Static websites, video streaming, API acceleration, software distribution.                          | Gaming, IoT, real-time communication, multi-Region applications requiring consistent performance/static IPs.         |

### Cloud in Real Life: Global Architecture

**Morgan:** Welcome back to Cloud in Real Life! We're going to go over some relatively complex network diagrams and use cases to reinforce the learning that you've done, but not to worry, you don’t need to understand it all perfectly yet.

**Rudy:** And up until this point, you've been learning about a single VPC in a single region. However, in the real world, companies often need much more complex networks to support global customers. This can mean multiple AWS accounts, multiple AWS Regions, multiple VPCs...even hybrid cloud deployments. But let's start with a very common setup - a VPC with a VPN connection.

A virtual private gateway is the virtual private network (VPN) endpoint on the AWS side. It provides a way for you to establish a secure, encrypted connection between your on-premises network and your virtual private cloud (VPC).

**Alan:** This setup allows a company to securely **connect** their **on-premises network** to their cloud-based resources on **AWS**. This essentially creates a **private**, **encrypted** tunnel to **access data** and **applications** in the cloud **from their physical office location**, while maintaining **data security** and **privacy** over the **public internet**. Companies often use this for **remote employees** who need to access **sensitive information** that is **stored** in the **AWS cloud**.

**Morgan:** And while there are definitely benefits to using a VPN to connect to a VPC, and it works great for many customers, it does also have a few potential **limitations** to be aware of. One thing is that VPN connections do share the **bandwidth** of the local internet, so the connection can be prone to **slowdowns** if you have heavy payloads of data being sent over the internet to AWS. Another consideration might be your company requirements to meet certain **compliance** or **regulatory** standards. If you're worried about those types of things, then you might consider using **Direct Connect**.

**Rudy:** Exactly! Direct Connect is also awesome when lots of data needs to flow between corporate data centers and AWS. These **huge data transfers** can take a long time over the public Internet so some companies opt for Direct Connect instead. **Traffic** will be **routed** from their **corporate data center** to a **Direct Connect location**. It is then **routed** to a **VPC through** a **virtual private gateway.** All network traffic flows through this **dedicated private connection**. This helps to **speed** up data transfers, address application **performance** and increase a company's data transfer security.

**Alan:** So, when I have taught AWS networking, I get a lot of questions around when to use VPN or Direct Connect. Rudy, can you expand on that a little bit to clear it up?

**Rudy:** Dude, of course! Yes, yes, you should use **VPN** when you need a **secure**, **flexible connection** for **remote** **access** to your resources. This is especially true for **small-scale data** transfers or when a dedicated connection isn't necessary.

**Morgan:** And then it's a good bet to use **Direct Connect** when you need much higher bandwidth with a **dedicated line** like with **large data** transfers between your on-premises network and AWS.

**Alan:** And there are cases when you need to use both VPN and Direct Connect, right?

**Rudy:** Oh yeah, of course, a common use case for using a VPN alongside AWS Direct Connect is where you use **VPN as a failover for Direct Connect.**

**Morgan:** Right, because we have to remember that with **Direct Connect** these are **physical hard-wired connections**. So, if there is some situation where a line gets cut accidentally or if something were to happen, you can **VPN** as a **backup connection** for failover. But there are even cases where you may want to failover to a secondary direct connect line.

**Alan:** Sure! In addition to **fault tolerance**, if a customer wants **Increased bandwidth**, they can **combine multiple connections** to achieve **higher aggregate bandwidth.**

**Morgan:** Okay great, so that makes sense! Now, what about a real-world example of a company that needs to deliver content to several different regions globally? What would that look like?

**Rudy:** Well, for companies with customers around the globe or even offices in different Regions where they need to deliver content, they could use Amazon CloudFront and Route 53. CloudFront distributes content from edge locations globally, while Route 53 uses its **latency-based routing** capabilities to **direct users to the closest AWS region** (based on their location). This ensures they access the application with the **lowest latency**, which effectively provides a seamless experience across multiple Regions.

**Alan:** Yeah, let's take a look at how that works. Starting with a user, they access the company's **website** using a **custom domain**, the **request** is then **sent** to a **Route 53 DNS** record. Route 53 uses a **routing policy** to determine **which Region is closest to the use**r and then directs them to the appropriate **CloudFront edge location**.  The edge location then fetches the content from the designated origin server in the chosen Region. Notice how we're showing an architecture with multiple AWS Regions, and multiple VPCs!

**Morgan:** Right, this is a much more mature architecture than a single VPC in a single region. Again, you don't need to worry too much about getting all of this right for now, but it's good to have context for how customers are using this stuff in the real world.

![M05_L5 CIRL Direct Connect](../Images/Media/M05_L5%20CIRL%20Direct%20Connect.png)
[M05_L5 CIRL Direct Connect](../Images/M05_L5%20CIRL%20Direct%20Connect.md)


## Module 6 - Storage - [AWS Storage Services](../Concepts/AWS%20Storage%20Services.md)

### Introduction to Storage 

Things are really brewing in our coffee shop. Get it? Hah! And as things brew, we need to store and keep track of lots of records to make sure operations run smoothly. For example, we need a rolling inventory of our different varieties of coffee beans, sales transactions, marketing materials - oh, even our secret recipes.

No, no. These are for my eyes only. As for storage, you wouldn’t just toss everything into an unorganized cupboard. You would use appropriate **storage solutions** to **organize** it accordingly. Maybe you would use airtight containers for coffee beans, a filing cabinet for paperwork, and a locked safe for those confidential recipes.

The same idea applies to the **different types of data stored** on AWS. Not everything fits neatly into one type of storage. Take files for example. They need to be stored and retrieved as complete objects. Think of an image or marketing PDF. Nobody wants half an image or three quarters of a PDF. They want the whole thing.

**Logs** are another type of data. They need **fast reads and writes** in a consistent manner. This requires a **different type** of **storage**. And sometimes, you have folders that everyone in your shop needs access to. These might include shared training manuals and internal documents. This is why AWS offers different options for **block**, **object**, and **file storage**.

#### Block storage

Block storage provides **persistent**, **low-latency** block-level storage **volumes** that **attach** to **EC2** instances like physical hard drives. Block storage volumes can be encrypted, backed up via **snapshots**, and modified while in use without disrupting the instance. AWS offers two primary block storage services:

**Block storage** breaks data into manageable pieces called blocks, which makes it fast and more efficient to access. With **block storag**e, data can be **updated**, **block by block**, meaning the whole file doesn't need to be changed every time you make an update.  

This makes it ideal for developers who work with **applications** or **databases** that need **quick and frequent updates.**

- *Amazon* ***EC2*** *instance store*

    An unmanaged **non-persistent**, high-performance block storage directly attached to EC2 instances for **temporary data.**

---

- ***Amazon Elastic Block Store (EBS)***

    A **managed** service that provides **persistent block storage volumes** for **EC2** instances, offering various types for different workloads


---

![Elastic-Block-Store](../Images/Media/Elastic-Block-Store.png)
[Elastic-Block-Store](../Images/Elastic-Block-Store.md)

---

#### Object storage

Object storage is a data storage architecture that manages data as objects in a **flat address** space. It offers **unlimited scalability** so you can store vast amounts of **unstructured data** without worrying about capacity constraints. Object storage provides enhanced **metadata** capabilities to provide more efficient data management, search, and analytics across massive datasets.

**Object storage** saves data in **self-contained units**, as, you guessed it...objects. Each of these **objects** includes the **data**, a **unique ID**, and information about the object called **metadata** that makes it easy to **organize** and **retrieve**. Unlike block storage, where you can update small parts of a file as needed, this type of storage requires **rewriting** the **entire object** for every change.

**Objects** are **organized** in **flat structures** called **buckets**, which are different from traditional hierarchical systems like folders. Object storage is best for files that don't change constantly, like **videos**, **backups**, or **logs**.

---

- ***Amazon Simple Storage Service (S3)***

    A **fully managed scalable** object storage service for storing and retrieving any amount of data from anywhere.


---

![Simple-Storage-Service](../Images/Media/Simple-Storage-Service.png)
[Simple-Storage-Service](../Images/Simple-Storage-Service.md)

---

#### File storage

AWS file storage services provide s**hared file systems** accessible over networks, so multiple users and applications can access the same data simultaneously. They offer **scalability** and flexibility so you can expand storage capacity as needs grow without managing physical infrastructure. AWS offers two primary file storage services:

Finally, **file storage** uses a **hierarchical file system** that can be **shared by applications**.

It’s **compatible** with most systems, which means little or **no code modification** in most cases. File storage is ideal for applications that require **shared access**, like **content management systems**.

---

- ***Amazon Elastic File System (EFS)***

    A fully managed, scalable **NFS** file system for use with AWS Cloud services and on-premises resources.


---

![EFS](../Images/Media/EFS.png)
[EFS](../Images/EFS.md)

---

---

- ***Amazon FSx***

    A fully managed file storage services for popular file systems like Windows, Lustre, and NetApp ONTAP.


---

![FSx](../Images/Media/FSx.png)
[FSx](../Images/FSx.md)

---

Beyond these categories, we need to mention **databases**. They allow storage of **organized information** that usually needs to be **queried**, **updated**, and **analyzed constantly**. We provide various database services, too. We’ll get to those soon, but for now, let’s explore the different storage services on AWS in more detail!

These services don't fit cleanly into the categories we've defined so far, but they're important AWS storage offerings that you should be familiar with.

#### Additional storage services 

---

- ***AWS Storage Gateway***

    A fully managed, **hybrid-cloud storage** service that provides **on-premises** access to virtually unlimited cloud storage.


---

![Storage-Gateway](../Images/Media/Storage-Gateway.png)
[Storage-Gateway](../Images/Storage-Gateway.md)

---

---

- ***AWS Elastic Disaster Recovery***

    A fully managed service that streamlines the recovery of your physical, virtual, and cloud-based servers into AWS.


---

![Elastic-Disaster-Recovery](../Images/Media/Elastic-Disaster-Recovery.png)
[Elastic-Disaster-Recovery](../Images/Elastic-Disaster-Recovery.md)

---

![image](../Images/Media/image%20(24).png)
[image](../Images/image%20(24).md)

![image](../Images/Media/image%20(25).png)
[image](../Images/image%20(25).md)

[AWS Shared Responsibility Model - SRM](../Concepts/AWS%20Shared%20Responsibility%20Model%20-%20SRM.md)

---

![infographic_servicesFullyManaged-crop](../Images/Media/infographic_servicesFullyManaged-crop%20(1).png)
[infographic_servicesFullyManaged-crop](../Images/infographic_servicesFullyManaged-crop%20(1).md)

---

![infographic_servicesManaged-crop](../Images/Media/infographic_servicesManaged-crop%20(1).png)
[infographic_servicesManaged-crop](../Images/infographic_servicesManaged-crop%20(1).md)

---

![infographic_servicesUnmanaged-crop](../Images/Media/infographic_servicesUnmanaged-crop%20(1).png)
[infographic_servicesUnmanaged-crop](../Images/infographic_servicesUnmanaged-crop%20(1).md)

---

| **Management Category** | **AWS Storage Service**                                                | **Customer Responsibilities**                                                                                                                                            | **AWS Responsibilities**                                                                                                       |
| :---------------------- | :--------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------- |
| **Fully Managed**       | **Amazon S3** (Simple Storage Service)                                 | Data management, access controls (IAM/Bucket Policy), service configuration, and security of data *in transit*.                                                          | **All infrastructure, hardware, data durability (11 9s), availability, encryption at rest, and replication.**                  |
|                         | **Amazon EFS** (Elastic File System)                                   | Data management, access controls, network configuration (Mount Targets), and security of data *in transit*.                                                              | **All infrastructure, hardware, capacity scaling (elastic), durability, and replication across AZs.**                          |
|                         | **Amazon FSx Family** (e.g., FSx for Lustre/Windows File Server/ONTAP) | Data management, access controls, security of data *in transit*, and connecting the file system to compute instances.                                                    | **All infrastructure, patching, software updates, durability, replication, and file system administration.**                   |
|                         | **AWS Backup**                                                         | Defining backup policies, setting retention and compliance rules, and managing the backup vault access.                                                                  | **The entire backup infrastructure, scheduling, orchestration, and monitoring of the backup process.**                         |
| **Managed Services**    | **Amazon EBS** (Elastic Block Store)                                   | Data backup strategies (snapshots), **encryption configuration** (KMS key), **volume performance optimization** (IOPS/Throughput), and **capacity planning** (resizing). | **Underlying storage infrastructure, hardware redundancy, volume replication** within an Availability Zone, and volume health. |
| **Unmanaged Services**  | **EC2 Instance Store**                                                 | **Full responsibility** for data management, **backup/recovery**, encryption, performance optimization, and **data durability** (since data is lost on stop/terminate).  | **Maintains the underlying physical hardware** and network infrastructure of the EC2 host.                                     |

### EC2 Instances Store and Amazon Elastic Block Store - EBS

When you're using Amazon EC2 to run your business applications, those applications need access to CPU, memory, network, and storage. EC2 instances give you access to all of those components, but for right now, let's focus on the storage access.

As **applications run**, they will oftentimes need access to **block-level storage**. You can think of block-level storage as a place to **store files.** A file being a **series of bytes** that are stored in **blocks** on **disk**. When a file is updated, the whole series of blocks aren't all overwritten.

Instead, it updates just the pieces that need changed.

This makes it an efficient storage type when working with applications like **databases**, **enterprise software**, or **file systems**. When you use your laptop, you are accessing block-level storage. In this case, I'm talking about the hard drive for your laptop. **EC2** instances have **hard drives**, too, and there are a few different types.

#### Amazon EC2 instance store

Amazon EC2 instance store isn't a stand-alone AWS block storage service. Rather, it refers to the block-level storage that is physically attached to the EC2 instance host computer. Depending on the type of instance, EC2 instance store might come attached as the default storage. Since its data is lost when an instance is stopped or terminated, EC2 instance store is best for temporary memory-based storage needs like buffers, caches, and scratch data. It is not recommended for applications that require data retention. An Amazon EC2 instance store provides temporary block-level storage for an Amazon EC2 instance. This means that if you stop or terminate an Amazon EC2 instance, all the data written to the attached instance store is deleted.

Depending on the type of the EC2 instance you launch, it can provide you with **physically attached local storage** called **instance store volumes**.  The **catch** here is that because this volume is attached to the underlying physical host, if you stop or **terminate** your EC2 instance, all of **data** written to the instance **store volume will be deleted**.

The reason for this is that if you start your instance from a stopped state, it's likely that that EC2 instance will start up on another host. A host where that volume does not exist.

Because of the **ephemeral** or **temporary** nature of i**nstance store volumes**, they are useful in situations where you can afford to **lose the dat**a being written to the drive.

**Benefits:**

- **Automatically available storage**

    Instance store volumes come automatically attached to many EC2 instance types, providing temporary block-level storage at no additional cost. It's physically connected to the host computer, offering high I/O performance for data that disappears when the instance stops.

- **Cost effective**

    Because EC2 instance store is included in the EC2 instance price, you don't have to pay any additional fees for storage. It's ideal for temporary storage needs like buffers, caches, or scratch data, potentially reducing expenses for applications that don't require persistent storage.

- **High performance**

    EC2 instance store offers extremely low-latency storage directly attached to the host server of your EC2 instance. This proximity means exceptionally high I/O performance, making it ideal for temporary storage of data requiring fast processing.

Like if you need scratch space for heavy calculations or data processing. However, there are many use cases where you need **persistent data volumes.** You don't want your entire database getting deleted every time you stop an EC2 instance. Don't worry, this is where a service called **Amazon Elastic Block Store**, or Amazon **EBS**, comes into play.

---

#### Amazon Elastic Block Store (EBS)

Amazon EBS provides *persistent block-level storage* volumes for use with Amazon EC2 instances. EBS volumes act like external hard drives, offering consistent and low-latency performance for workloads like databases and file systems.


---

![Elastic-Block-Store](../Images/Media/Elastic-Block-Store.png)
[Elastic-Block-Store](../Images/Elastic-Block-Store.md)

---

EBS volumes can be conveniently backed up, resized, and attached to different EC2 instances. To create an EBS volume, you **define** the configuration for things like volume **size** and **type**. After the volume has been created, it can be **attached** to an Amazon **EC2** instance. Because EBS volumes are for data that needs to persist, it’s important to back up the data. It's recommended that you take **incremental backups** of EBS volumes by creating Amazon **EBS snapshots**. Amazon EBS provides block-level storage volumes that you can use with Amazon EC2 instances. If you stop or terminate an Amazon EC2 instance, all the data on the attached EBS volume remains available.

With Amazon EBS, you can create **virtual hard drives**, which we call **EBS volumes**, that you can **attach** to your **EC2 instances**. These are **separate drive**s from the local **instance** store volumes, and they aren't tied directly to the host that your EC2 instance is running on.

This means, that the data that you write to an EBS volume can **persist** between **stops** and **starts** of an EC2 instance. Amazon EBS ensures data protection through **automatic replication** within the **same Availability Zone**. This provides the **high availability** and **durability** needed for financial applications with critical data.

EBS volumes come in all different **sizes** and **types**. How this works is you define the **size**, **type**, and **configurations** of the volume you need. Provision the volume, and then **attach** it to your **EC2 instance**. From there, you can configure your application to write to the volume, and you're good to go.

**Use cases**

Some practical use cases of Amazon EBS include database hosting, backup storage for applications, and **rapid deployment of development environments using volume snapshots.**

**Benefits**

- **Data migration**

EBS volumes can be easily migrated between Availability Zones using snapshots. The snapshots provide a simple way to move data across regions or create copies.

- **Instance type changes**

Since EBS volumes remain independent of EC2 instances, it's not complicated to attach them to different instance types. This flexibility lets you **upgrade** or **downgrade instances without losing data.**

- **Disaster recovery**

EBS snapshots provide reliable backup solutions that can be restored in different regions during emergencies. Regular automated snapshots ensure your data remains protected and quickly recoverable.

- **Cost optimization**

EBS volumes can be modified to different types and sizes to match actual usage patterns. You can switch between storage types or adjust capacity **without downtime.**

- **Performance tuning**

Amazon EBS offers various volume types to match different workload requirements and IOPS needs. You can **adjust volume performance characteristics on the fly** to meet changing application demands.

Now that we've covered the main features of block storage, it’s also good to know that EBS offers different volume types that give you different levels of performance and offer **different pricing**. Performance for EBS volumes is measured in **IOPs**, or **input/output per second.**

Alright, we're not done with EBS just yet. Stay tuned to learn about EBS snapshots.

### Amazon Elastic Block Store Data Lifecycle

Let's dive a little deeper into the **data lifecycle** for Amazon **Elastic Block Store.**

If you recall from the shared responsibility model, you are responsible for managing your own data. This means you need to manage your **EBS volumes lifecycle**, which includes provisioning, moving, deprovisioning, and backups.

#### EBS Snapshot 

EBS snapshots are **point-in-time backups** of EBS **volume**. They can be used for disaster **recovery**, **data migration,** volume **resizing**, and for creating consistent backups of production workloads. EBS snapshots are **incremental**, so they only save the blocks on the volume that have **changed** after your most recent snapshot.

EBS snapshots can be used to create multiple **new volumes**, and new volumes created from a snapshot are an **exact copy** of the original volume at the time the snapshot was taken. Snapshots of EBS volumes are stored **redundantly** in **multiple Availability Zones** using Amazon **S3**.

Amazon **EBS snapshots** are **point-in-time copies** of your EBS volumes. Point-in-time means that the backup is done at a specific moment—in time. This can be daily, weekly or even monthly depending on your organization’s needs. Even better, this means you can make **incremental backups** and restore them as needed.

But what does incremental backup mean? Well, let's say you take the first snapshot of your data on Monday. All of your data is **copied** in its **entirety**. Then, on Tuesday, you take another snapshot, but this time, it only **copies what has changed** since the **previous snapshot** was taken. That’s the incremental part.

This approach makes subsequent snapshots **faster** and more **storage-efficient**, which translates to a significant reduction in **cost** compared to running a full backup every time.

But that only solves half of the problem.

You’re taking these snapshots, but how do you manage them? The last thing you want is to log into the AWS Management Console every week and create a snapshot. It’s time consuming and prone to human error. Imagine if you needed to do this for thousands of volumes. You’d be spending an hour just selecting all the buttons.

You want more automation? Use a **fully-managed** service like **Amazon Data Lifecycle Manager**. With Amazon Data Lifecycle Manager, you can define policies to help **automate** snapshot lifecycle management. You can schedule snapshot creation, set retention policies, manage lifecycles, and apply consistent backup policies across your organization.

This means nobody needs to log in to the console every Monday and click all of those buttons.

**Working with EBS snapshots**

In keeping with the AWS shared responsibility model, as the customer, you are responsible for scheduling and managing regular EBS snapshots as part of your backup strategy. This includes monitoring snapshot costs and deleting unnecessary snapshots to avoid excessive charges. You also need to make sure sensitive data within snapshots is encrypted, verify snapshot integrity, and test restoration procedures regularly.

**Benefits**

- **Data protection and recovery**

Snapshots enable **fast data recovery** from corruption, accidental deletion, or system failures using point-in-time backups.

- **Operational flexibility**

Snapshots enable operations like **cross-Region data migration**, volume **resizing**, volume **cloning**, and **sharing data across AWS accounts.**

- **Cost effective**

Snapshots use incremental backup technology, storing only changed blocks after the initial backup, reducing storage costs and backup time.

#### **Amazon Data Lifecycle Manager**

You can **automate** the **creation**, **retention**, and **deletion** of **EBS snapshots** using Amazon Data Lifecycle Manager. Amazon Data Lifecycle Manager can **schedule** snapshots during **off-peak hours** to minimize performance impact and **automatically delete outdated backups** to **control storage costs**. It's particularly valuable for **large-scale deployments** where manual snapshot management would be time-consuming and error-prone.

### Amazon Simple Storage Service - S3

It's time to cover a very popular storage service called Amazon Simple Storage Service, or Amazon S3. From the name, you've probably guessed that it’s a storage service and it's, well, simple. Most businesses have data that needs to be stored somewhere.

For the coffee shop, this could be receipts, images, spreadsheets, employee training videos, text files, or other types of files.

#### Amazon Simple Storage Service (S3)

---

Amazon S3 is a **fully managed**, highly-available object storage service for storing and retrieving any amount of data as objects. It offers 99.999999999 percent durability, meaning your data is highly protected against loss, and offers features like versioning, lifecycle management, and various storage classes to optimize costs.


---

![Simple-Storage-Service](../Images/Media/Simple-Storage-Service.png)
[Simple-Storage-Service](../Images/Simple-Storage-Service.md)

---

Each object typically includes the ***data***itself, ***metadata***, and a unique identifier, or ***key***. Objects can be of any file type, such as images, videos, documents, or application data, and can range in size from a few bytes to several terabytes.

Each Amazon S3 object is uniquely identified within a bucket by its key, which is essentially its file name. Objects also have properties like version ID, access control information, and **user-defined** metadata.

Amazon S3 stores files as objects in containers known as buckets, and each object can range in size from a few bytes to several terabytes. It integrates seamlessly with other AWS services and supports a wide range of use cases, from basic backups to complex data lakes.

Storing these files is where S3 comes in handy because it's a data store that makes it possible to store and retrieve a **virtually unlimited amount of data at any scale**. Here are some of the basic concepts you need to know for object storage with S3.

**Single data files**, regardless of the type of file, are stored as **objects**. But instead of storing them in a file directory, you store them in what we call **buckets**. Think of a file sitting on your hard drive. That’s like an object. And think of a **file directory**. That’s like a **bucket**.

Now, the **maximum individual object size** that you can upload is **5 terabytes**, but there is no maximum on the total bucket size. So, you can have many objects in many buckets, and it's virtually unlimited storage. You can also turn on **versioning** for these objects to protect them from accidental deletion. With this feature you can always **restore** the previous versions.

Data stored in S3 for most storage classes is **automatically redundant.** Multiple object copies reside in the cloud simultaneously, and that is all managed by AWS. Now this means that all S3 objects have 11 nines of data durability. So, an object stored in S3 has a 99.999999999 percent probability that it will remain intact after a period of 1 year. That's a lot of nines!

S3 is commonly used for situations like: **hosting websites, storing backups**, **archiving data,** and managing media files like **videos** or **images**. It's a really versatile service that scales up and down as needed with your business, whether you're a small startup or a large enterprise.

For example, let's say you're running an online store. You might store your **product images** in S3. Then, when a **customer browses your website,** these **images** are quickly **retrieved** from **S3** to display. And if your website gets a sudden **spike** in **traffic**, S3 can handle the increased demand without a problem and without you needing to set up **scaling**.

That is because **S3** is a **managed service**, so all of the underlying mechanisms for scaling and running the service are handled by AWS. S3 is also great for **data backups** because it ensures your data is safely stored and convenient to retrieve when needed. And because it's **durable**, remember those 11 9's?, this means you don’t have to worry about data loss, even if something unexpected happens. Speaking of business critical, now let's talk about **securing** your **data** in **S3**.

S3 has multiple security features that make it possible for you to control **who** has **access** to **what**, creating a layer of protection for your data. By **default**, everything is completely **private** and only the person who created the object can access it. Then you have to configure any **additional access** you need through features like **bucket policies.**

Or, in some cases, you want to only grant **temporary access**, and you don't want to set up long-term access policies. For this use case, you can create **time-limited** **pre-signed URLs** for secure sharing without having to update your bucket policy. There are also features like Amazon **S3 Access Points,** which simplify the process of **creating unique access control policies for shared datasets**, where managing different band their respective access might be complicated.

And, finally, if you want to track who is accessing what, you can use **Amazon S3 Audit Logs** to **track** every **request** made to your resources. This provides complete **visibility** into whois **accessing** your data and **when**. That wraps up our introduction to S3, but there's more to come on this service, so stay tuned.

**Benefits**

- **Virtually unlimited storage**

Amazon S3 has no fixed storage limit, scaling automatically to accommodate any amount of data you need to store. Since you only pay for the storage you use, it's a cost-effective solution for growing data needs.

- **Object lifecycle management**

Amazon S3 lifecycle policies automatically move objects between storage classes based on your defined rules, optimizing costs over time. You can set up automatic transitions and expirations to manage data throughout its entire **lifecycle**.

- **Broad range of use cases**

Amazon S3 supports a wide range of use cases for both cloud-based applications and traditional on-premises workloads. Amazon S3 is commonly used for *content distribution*, *hosting static websites*, and delivering *media files*. It's also a popular choice for things like *application data storage*, *archiving*, *data lakes*, and compliance-driven *data retention*.

- **Bucket Policies** ​Amazon S3 bucket policies are *resource-based policies* that can only be attached to S3 buckets. An S3 bucket policy specifies which actions are allowed or denied on the bucket, in addition to every object in that bucket.

- **Identity based Policies** ​Permissions that control what actions users, groups, or roles can perform on S3 resources are configured using *identity-based policies*. These policies attach directly to identities rather than to the S3 resources themselves. You can use these policies to specify which S3 buckets and objects users can access and what actions they can perform.

- **Encryption**
​Amazon S3 provides encryption capabilities to protect data both at rest and in transit.

### Amazon S3 Storage Classes and S3 Lifecycle 

When you start working with Amazon S3, you’ll notice that AWS offers different storage tiers, or “storage classes,” to store your data. Each one is designed for different needs, and by understanding them, you can optimize for costs while making sure your data is stored in the most appropriate way. Let’s start with the basics.

Some storage classes are meant for data that’s **accessed frequently**, while others are better for data that’s rarely used or needs to be **archived**. And the best part? You don’t have to stick to just one storage class for all your objects. Within a single S3 bucket, you can **mix** and **match classes** based on **data access patterns**.

#### S3 Standard 

---

The first storage class we’ll talk about is S3 Standard. This one’s great for data that you **access regularly**, like **files for a dynamic website.** It’s a **general-purpose storage class** and gives you **fast retrieval** speeds and **affordable** storage **costs**.


---

![Simple-Storage-Service](../Images/Media/Simple-Storage-Service.png)
[Simple-Storage-Service](../Images/Simple-Storage-Service.md)

---

#### S3 Standard Infrequent Access - IA

Now, if you don’t need to access your data as often, the storage class S3 Standard-IA, or **Infrequent Access**, is a more **cost-effective** choice. You still get that quick retrieval when you need it, but at a lower storage cost. It’s perfect for things like **backups**.

#### S3 Glacier Instant Retrieval

---

For even **lower-cost** options, we have the **Glacier storage classes**, which are designed for **long-term archiving**. There is S3 Glacier I**nstant Retrieval,** which is for data that might require quick access on occasion but you still want to optimize for cost as much as possible. S3 Glacier Instant Retrieval provides the same **quick access** **speeds** as S3 Standard but has a lower storage cost and can be used for use cases like **medical images** or **media files.**


---

![Simple-Storage-Service-Glacier](../Images/Media/Simple-Storage-Service-Glacier.png)
[Simple-Storage-Service-Glacier](../Images/Simple-Storage-Service-Glacier.md)

---

#### S3 Glacier Flexible Retrieval

However, if you don’t need the quick access piece of this, and you are able to tolerate a bit of a wait for the data retrieval, then S3 **Glacier Flexible Retrieval** is a better choice. It can save you even more on cost, though it does take a little bit **longer** to **retrieve** — ranging from minutes to hours.

#### S3 Glacier Deep Archive

Moving on now to S3 **Glacier Deep Archive,** which is the **most cost-effective** option. This is the best option for storing **data you hardly ever need**, making it ideal for things like **compliance archives** or **digital preservation.** Data in this tier can be restored within **12 hours**.

#### S3 One Zone Infrequent Access - IA 

However, we aren’t done yet. S3 has a few other storage tiers for specific use cases you that should be aware of as well. Let’s start with the **one-zone options**. S3 Express One Zone and S3 **One Zone-IA**, are **lower cost**, but might be susceptible to **data loss** in the unlikely case of the loss or **damage** to all or part of an **AWS Availability Zone.**

#### S3 Express One Zone 

S3 Express One Zone stores data in a single Availability Zone. It was purpose-built to deliver consistent single-digit millisecond data access for your most frequently accessed data and latency-sensitive applications. S3 Express One Zone delivers data access speed up to 10x faster and request costs up to 80% lower than S3 Standard.

If you don’t need the **extra resilience**, these can help **cut costs** or **improve access speeds.**

#### S3 Intelligent-Tiering

Now, your data might start off as frequently accessed, but then **over time** might become **less** frequently **accessed**. For example, when you make a new post on social media, it gets a lot of attention for a few days. But a month or a few months out, there are likely very few people looking at and interacting with those posts.

Well, that’s where S3 Intelligent-Tiering comes in. This storage class **automatically** moves data between **four different tiers** based on **how often it’s accessed**, helping you **optimize** for **cost** without doing any of the work yourself. It’s perfect for things like **data lakes** or **large datasets** that might **change their usage patterns.**

By understanding these options and using tools like Intelligent-Tiering and Lifecycle management, you can store your data more efficiently and optimize for cost.

#### S3 Outposts

---

Amazon S3 Outposts delivers object storage to your on-premises AWS Outposts environment using **Amazon** S3 **APIs** and **features**, and serves workloads with **local data residency requirements.** It also helps maintain optimal performance when data must remain in close **proximity** to **on-premises applications.**


---

![S3-on-Outposts](../Images/Media/S3-on-Outposts.png)
[S3-on-Outposts](../Images/S3-on-Outposts.md)

---

You can **optimize your storage classes** in AWS for these types of situations using **S3 Lifecycle policies**. These are **rules** you set up to help you **automatically move data between classes or delete old data** when you no longer need it. For **example**, you can set up a Lifecycle policy to move old data into Glacier after a year, and then automatically delete it when it’s no longer necessary for compliance.

To help you figure out the best way to move your data, you can use **S3 Storage Class Analysis.** This feature looks at your **data access patterns** and helps you decide when to move data to a more cost-effective storage class. But what if you want to take advantage of Amazon S3 storage tiers without managing the lifecycle policies yourself?

#### Amazon S3 storage classes and use cases

Amazon S3 offers various storage classes to suit a variety of **workloads** with specific **performance**, **access**, **resiliency**, and **cost** requirements. They're also designed to address **data residency** requirements, **unpredictable access patterns**, **archival storage** needs, and offer the most **cost-effective** options for different access patterns.

[S3 Classes Table](../Tables/S3%20Classes%20Table.md)

#### S3 Lifecycle

To avoid manually managing your object storage tier configurations, you can use **S3 Lifecycle configurations** to automate the process. When you define a lifecycle configuration for an object or group of objects, you can choose to automate between two types of actions, as follows:

- *Transition actions:* define when objects should transition to another storage class.

- *Expiration actions:* define when objects expire and should be permanently deleted.

For example, you might transition objects to S3 Standard-IA storage class 30 days after you create them. Or you might archive objects to the S3 Glacier Deep Archive storage class 1 year after creating them.

30 days without access request --> 60 days --> 365 days --> Delete/Expire

![image](../Images/Media/image%20(26).png)
[image](../Images/image%20(26).md)


### Amazon S3 Demonstration 

In this demo we're going to walk through some of the basic features and functionalities of Amazon Simple Storage Service, or Amazon S3. We will start by accessing S3 using the AWS management console. In the search bar I will type *S3* and then select the Amazon S3 service. Let's create an S3 bucket to get things going.

Choose *create bucket* to start the process. For this you'll need to enter a **globally unique bucket name** meaning it should be unique across all AWS accounts worldwide. I'm gonna enter *Morgan bucket 2025*. Then we need to choose our preferred AWS **region** from the menu. I'm going to go ahead and leave the region to be *North Virginia*.

Scrolling down, notice how the***block all public access*** **settings are enabled** which prevents any external access to this bucket or its contents. For now keep these settings as is and then we can scroll down and choose ***create bucket*** **at the bottom of the page.**

To access your newly created bucket choose the link for the bucket from the list of buckets here. You'll notice that this bucket is currently empty which is expected But where's the fun in an empty bucket. Let's go ahead and create an organized structure for our bucket content by creating a **folder**. Choose *create folder* and then give the folder a name I will call this folder.

Then we can scroll down and notice we're presented with some folder encryption options in case you want to configure any security at this point in the process. We're going to go ahead and keep the default encryption settings and then we will select *Create folder*. Now a new folder has been created within our bucket.

Let's get some objects into our folder by uploading a file from local storage. First, select the newly created folder to open it and then choose upload and then add files. Browse your local system and select a file you would like to add I'm going to select this demo file and then select open.

Let's now take a moment to explore the object **metadata**. Choose ***properties***to expand this section navigate to the *metadata* subsection of this page, and then you can **add metadata**. There are 2 types of object metadata in Amazon S3. ***System-defined metadata*** includes basic object details like **creation date size and storage class** and ***user-defined metadata*** can be used to include your own **custom metadata like tags.**

All right, now I'm going to go ahead and remove this and from here we can go ahead and upload the object. This file should now be listed in our bucket inside of our folder. Let me go ahead and check. We can see the file has now been uploaded.

Now let's say you want to **upload a folder and all of its contents** to your bucket. Although it's not possible using the add files method we just covered you can accomplish this using the drag and drop upload method. Identify the local folder on your computer that you want to upload and then choose the upload button. But this time, simply **drag** the **folder** from your local storage directly to your Amazon S3 folder. This is also something you can do using the **command line interface** or the AWS SDK.

I will scroll down and choose *upload,* and as the progress bar indicates that the upload is complete, we can then choose the name of the folder and we can drill down into the folder that we just uploaded. You'll notice that Amazon S3 has **maintained the original file hierarchy** during the upload process. To return to the bucket we created earlier, locate in the breadcrumb navigation and choose the bucket name.

Now let's explore some **bucket level configurations**, choose the **properties tab**, and here you can **review** and **modify** important **features** including ***bucket versioning****,* ***tags****,* ***default encryption****,* ***intelligent tiering, archive configurations, static website hosting***, and more.

Next we will scroll back up and select the **permissions tab**. On this tab are sections that allow you to configure a variety of **access** settings for the bucket. This includes the ***block public access*** **setting, the** ***bucket policy, object ownership, cross-origin resource sharing***, and more.

Scrolling back up let's take a second to talk about bucket policies. An S3 **bucket policy** is a **JSON** statement that provides **access** to objects stored in a bucket. Let's add a bucket policy by choosing *edit* and then you can paste in your bucket policy.

Let's paste in a pre-created bucket policy that will grant cross account permissions to upload objects while ensuring that the bucket owner has full control. This bucket policy has one **statement** that **defines** the **effect** as **allow**.  

The ***principal***is the **AWS account number** that you want to allow to upload objects. The *action* is the S3 **API** call this effect is taken on and in this case that is the **put object call.**

Then there is the ***resource***which **defines** what resources in this **bucket this policy impacts**.

Finally, a ***condition***definition states the **upload** is only **allowed cross account** if the **metadata** around the **object ownership** is present and configured **correctly**. Then I can scroll down and select *save changes*.

Now scrolling up let's select the ***management tab*** where you have the option to set up several advanced features. You can change the **life cycle configuration replication, configuration and inventory configurations** from here.

Now that you have a solid understanding of the available bucket level configurations let's look at what you can configure at the **object level.** Scrolling up and selecting our *objects tab* I can then select one of the objects that we uploaded to view its properties. The *object overview* section shows basic information about the object including the *object URL*. If *block public access* is disabled and the bucket permissions allow anyone can **access** the **object through the URL.**

However, for our example here, *block public access* is turned on. So you would use the **bucket policy** to define **specifically** who has **access** to this **object**. Further down on the properties tab are sections for the ***object management overview****, storage class, server side encryption, checksums, tags, metadata, and object lock*.

You **absolutely can** use a bucket policy to grant access to specific users, **provided those users are authenticated** using AWS credentials (IAM Users, IAM Roles, or AWS Accounts).

Block Public Access **does not** prevent authenticated, private access.

Finally, I will scroll back up and select the ***versions*** **tab,** and here you could display a list of all previously created versions of the object if they existed. You can also **restore previous versions** **delete specific versions** and **manage the complete version history of your objects.**

All right, we are just getting started with S3 but for now you have a solid understanding of the fundamentals.

### Amazon Elastic File System - EFS

Next up on the list of storage services is a managed file system called Amazon Elastic File System, or Amazon EFS. It's extremely common for businesses to have shared file systems across their applications.

For example, you might have multiple servers running analytics on large amounts of data being stored in a **shared file system.** If this were hosted traditionally, it would require planning for the storage capacity, deciding on data redundancy levels, backup strategies, and maintenance as the dataset grows.

With EFS, you can keep existing file systems in place while AWS does all the heavy lifting of the **scaling** and the **replication**. EFS makes it possible for you to have **multiple instances accessing the data in EFS at the same time**. It scales up and down as needed without you having to do anything to make that scaling happen.

![image](../Images/Media/image%20(27).png)
[image](../Images/image%20(27).md)

When you create an **EFS filesystem,** it comes with **pre-configured lifecycle policies** that help keep your cloud data **cost-optimized**. EFS **automatically moves data** between **storage classes** based on access patterns, but you have the option to **customize** the **lifecycle policies** to fit your storage needs. Super nice, right?

EBS and EFS might seem similar, so let's take a moment to distinguish the two. **EBS volumes attach** to **EC2 instances** and are an **Availability Zone level resource.** In order to attach EC2 to EBS, you need to be in the **same Availability Zone.**

An **EBS volume is effectively a hard driv**e. You can save files on it, run a database on top of it, or store applications on it. If you provision a 2 TB EBS volume and fill it up, it **doesn't automatically scale** to give you more storage. So, that's EBS.

#### Amazon Elastic File System (EFS)

---

Amazon EFS is a **fully managed, scalable** file storage service for use with AWS cloud services and on-premises resources. It operates using the *Linux Network File System (NFS) protocol*, and *automatically scales* to petabytes as you add or remove files without disrupting applications. EFS is designed to support a wide variety of workloads and can be accessed by *multiple EC2 instances simultaneously*.


---

![EFS](../Images/Media/EFS.png)
[EFS](../Images/EFS.md)

---

**EFS** can have **multiple instances** reading from and writing to it at the **same time**. But it isn't just a blank hard drive for 1s and 0s — it's a true **file system** for **Linux**. EFS is **not AZ-limited**, you can connect storage to EC2 instances throughout the region or even from other regions. As you write more data to EFS, it **scales automatically** - no need to provision any more volumes.

**Benefits**

- **Multi-AZ redundancy**

    Amazon EFS automatically replicates data across multiple Availability Zones in a region for high availability. This built-in redundancy protects against AZ failures and provides continuous access to your file systems.

- **Shared access**

    Amazon EFS supports thousands of concurrent NFS connections, so multiple EC2 instances can access the same file system simultaneously. This shared access model makes EFS ideal for **collaborative workloads** and distributed applications.

- **Elastic storage**

    Amazon EFS automatically grows and shrinks as you add and remove files, with no need to provision or manage storage capacity. And since you only **pay for the storage you use**, it's cost-effective for varying workload demands.

**Amazon EFS storage classes**

With Amazon EFS, you can create and configure file systems quickly without any minimum fee or setup cost. You pay only for the storage used and you can choose from a range of storage classes designed to fit your use case.

1. **Standard Classes** ​The *EFS Standard* and *EFS Standard-Infrequent Access (Standard-IA)* storage classes offer Multi-AZ resilience and the highest levels of durability and availability. They have a higher cost associated with them due to higher availability and durability.

2. **One Zone Classes** ​The *EFS One Zone* and *EFS One Zone-Infrequent Access (EFS One Zone-IA)* provide additional savings by saving your data in a single Availability Zone. By using just one Availability Zone, you can reduce your storage costs when compared to the Standard EFS storage classes.

3. **Archive Class** ​The *EFS Archive* storage class is cost-optimized for data that is accessed only a few times a year or less and that does not need the sub-millisecond latencies of EFS Standard. EFS Archive offers a storage price up to 50% lower compared to EFS Infrequent Access, providing a more cost-optimized experience for cold, rarely-accessed data.



[EBS vs EFS comparison table](../Tables/EBS%20vs%20EFS%20comparison%20table.md)


### Amazon FSx

---

Amazon FSx makes it convenient and cost effective to launch, run, and scale feature-rich, high-performance file systems in the cloud. Amazon FSx supports multiple filesystem protocols, including Windows File Server and etc. As a fully managed service, it handles hardware provisioning, patching, and backups, and lower total cost of ownership (TCO).


---

![FSx](../Images/Media/FSx.png)
[FSx](../Images/FSx.md)

---

- **File system integration** ​Amazon FSx supports industry-standard file system protocols, allowing convenient integration with your existing applicatins, workflows, and development tools.

- **Managed infrastructure** ​Amazon FSx reduces the complexity of managing infrastructure while delivering the feature and capabilities of traditional file systems.

- **Scalable Storage** ​Amazon FSx adjusts resources dynamically, eliminating the need for complex capacity planning and manual infrastructure management.

- **Cost effective** ​Amazon FSx has a pricing model and automated tiering options that optimize costs by charging only for used storage and moving infrequently accessed data to lower-cost tiers.

**Amazon FSx for Windows File Server**

Amazon FSx for Windows File Server provides fully managed shared storage built on Windows Server. It delivers a wide range of data access, data management, and administrative capabilities.

Use cases include the following:

- Migrate Windows file servers to AWS.

- Accelerate hybrid workloads.

- Reduce SQL Server deployment cost.

- Streamline virtual desktops and streaming.

**Amazon FSx for NetApp ONTAP**

Amazon FSx for NetApp ONTAP provides fully managed shared storage in the AWS Cloud with the popular data access and management capabilities of ONTAP.

Use cases include the following:

- Migrate workloads to AWS seamlessly.

- Build modern applications.

- Modernize your data management.

- Streamline business continuity.

**Amazon FSx for OpenZFS**

Amazon FSx for OpenZFS provides fully managed shared file storage built on the OpenZFS file system and accessible through the NFS protocol (v3, v4, v4.1, and v4.2).

Use cases include the following:

- Migrate workloads to AWS seamlessly.

- Deliver insights faster for data analytics workloads.

- Accelerate content management.

- Increase dev/test velocity.

**Amazon FSx for Lustre**

Amazon FSx for Lustre provides fully managed shared storage with the scalability and performance of the popular Lustre file system.

Use cases include the following:

- Accelerate machine learning (ML).

- Enable high performance computing (HPC).

- Unlock big data analytics.

- Increase media workload agility.

| **Feature**            | **Amazon Elastic Block Store (EBS)**                                                | **Amazon Elastic File System (EFS)**                                         | **Amazon FSx Family**                                                                                                                                       |
| :--------------------- | :---------------------------------------------------------------------------------- | :--------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Storage Type**       | **Block Storage** (raw volume)                                                      | **File Storage** (NFS-based)                                                 | **File Storage** (Specialized/Commercial)                                                                                                                   |
| **Concurrent Access**  | **No** (Single Instance)                                                            | **Yes** (Thousands of instances)                                             | **Yes** (Protocol-dependent, typically thousands)                                                                                                           |
| **Geographic Scope**   | **Zonal** (Single AZ)                                                               | **Regional** (Spans All AZs)                                                 | **Regional** (Typically Multi-AZ options)                                                                                                                   |
| **Capacity & Scaling** | **Fixed Capacity** (Must be resized manually).                                      | **Elastic/Automatic** (Grows/shrinks automatically).                         | **Fixed/Scalable** (Varies by type; some scale automatically, others provisioned).                                                                          |
| **Ideal Use Case**     | Boot volumes, **Databases** (single-instance), high-performance transactional data. | **Linux Shared Storage**, general-purpose file sharing, web serving content. | **Windows File Server:** Lift-and-shift Windows apps. **Lustre:** HPC, ML, Big Data. **ONTAP:** Hybrid cloud, advanced data management (snapshots, dedupe). |

### AWS Storage Gateway

---

AWS Storage Gateway bridges the gap between your traditional infrastructure and the cloud. It's a **hybrid cloud storage service** that gives you **on-premises access** to virtually unlimited **cloud storage**. You can use it to **extend your local storage** to the cloud while **maintaining low-latency access** to frequently used data.


---

![Storage-Gateway](../Images/Media/Storage-Gateway.png)
[Storage-Gateway](../Images/Storage-Gateway.md)

---

Although the cloud offers lots of options, some organizations still run much of their business using an on-premises environment. Look, if it works, don’t break it. But, if those organizations still want to take advantage of the cloud, to say, perform backups that’s a very valid use case.

This is where AWS Storage Gateway comes in handy. It is a hybrid cloud storage service that is like the bridge, giving you access to virtually unlimited cloud storage. There is minimal or no rework needed, and everything is **seamlessly backed** up to AWS. Storage Gateway comes in three types: **S3 File Gateway**, **Volume Gateway**, and **Tape Gateway**.

#### Amazon S3 File Gateway

Amazon S3 File Gateway bridges your local environment with Amazon S3. It provides **on-premises applications** with access to virtually unlimited cloud storage through **familiar file protocols**. S3 File Gateway makes it possible to store and retrieve cloud objects using **familiar file operations.**
​When you deploy an S3 File Gateway, it appears to your local systems as a **standard file server**. Files written to this server are **automatically uploaded to Amazon S3** while **maintaining local access to recently used data** through **intelligent caching**. This means your applications can continue working with files as they always have while the actual data is securely stored in the AWS Cloud.

**S3 File Gateway** is ideal for storing **files directly in Amazon S3**. Even better, you can access these files from any AWS application or service.

#### Volume Gateway

With Volume Gateway, you create **virtual storage volumes** while maintaining local access to your data. It essentially functions as a bridge between your on-premises infrastructure and AWS Cloud storage by **presenting your cloud data as iSCSI volumes** that can be mounted by your existing applications.

Volume Gateway operates in **two main configurations:**

- ***Cached volume mode -*** stores primary data in the cloud while **frequently accessed** data is **cached locally** for **low-latency** access.

- ***Stored volume mode*** - locally keeps your complete dataset while asynchronously **backing** it up to the cloud as **EBS snapshots**.

**Volume Gateway** is a bit different in that it **creates block storage volumes locally.**

**On-premises applications** can then use these volumes. The key benefit is that files are **automatically backed up to AWS as Amazon EBS snapshots**.

#### Tape Gateway

Tape Gateway makes it possible to replace physical tape infrastructure with **virtual tape capabilities** while benefitting from the **durability** and **scalability** of **AWS Cloud storage**. Tape Gateway provides an interface that works with existing tape backup software, making the transition from physical tapes to cloud storage **seamless**.

When you deploy a Tape Gateway, it presents itself to your **backup applications as standard tape hardware**. Your backup software writes data to these virtual tapes just as it would to physical tapes and stored in Amazon S3. You can also configure Tape Gateway to **automatically transition less frequently accessed data** to a more **cost-effective storage class** for long-term retention.

The final type, **Tape Gateway**, is super useful for businesses still using **physical tape backups**. It provides that **seamless migration** of **tape data into the cloud.**

As for some example use cases along with benefits, Storage Gateway is a lifesaver for **disaster recovery**. Why? Because you can keep a **backup** of your critical **data** in the **cloud without changing your existing backup workflows**. It’s like a safety net for your current **safety net**. Like a safety-safety net.

It's also ideal for **data archiving**. You can move your **infrequently accessed data** to the cloud for **long-term storage**. Whether you want to **backup**, **archive**, or just start your **cloud journey**, AWS Storage Gateway has you covered.

And if you like it, cool. If you don’t, that’s cool, too. We want the best solution for our customers, even if it means using their existing one. So, don’t stress. Just keep learning.

**Benefits**

- **Seamless integration**

Storage Gateway enables smooth connectivity between on-premises applications and AWS Cloud storage, preserving existing workflows and minimizing disruption.

- **Improved data management**

Storage Gateway provides **centralized management** of hybrid storage environments, enhancing accessibility, security, and compliance.

- **Local caching**

Storage Gateway **locally keeps frequently accessed data** for quick access while managing less-used data in the cloud.

- **Cost optimization**

Storage Gateway reduces on-premises storage costs by using cloud storage for data archiving, backup, and disaster recovery purposes.

| **Feature**          | **Amazon FSx (Fully Managed Cloud File System)**                                                                                                   | **AWS Storage Gateway (Hybrid Cloud Bridge)**                                                                                                   |
| :------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------- |
| **Primary Location** | **In the AWS Cloud** (within a specific Region/VPC).                                                                                               | **On-Premises** (You deploy a VM appliance in your data center).                                                                                |
| **Core Purpose**     | To provide **feature-rich, high-performance file systems** for applications running in AWS.                                                        | To provide **on-premises applications** with low-latency access to **cloud storage** (S3, EBS, Glacier).                                        |
| **Data Residency**   | All primary data resides **in the cloud** (managed by FSx).                                                                                        | Primary data resides **in the cloud** (S3, EBS, or FSx), with a **locally cached copy** on your on-premises hardware.                           |
| **Storage Type**     | Provides managed instances of specialized file systems: **Windows File Server (SMB), Lustre, OpenZFS, NetApp ONTAP**.                              | Provides a local interface to different cloud storage types: **File (S3/FSx), Volume (EBS), and Tape (Glacier)**.                               |
| **Management Focus** | Managing the complexity of the file system (patching, backups, redundancy, performance scaling).                                                   | Managing the **data transfer and caching** between your local network and the AWS cloud.                                                        |
| **Key Use Case**     | Running **Windows applications** that require SMB shares, high-performance computing (HPC) workloads, or seamless integration with ONTAP features. | **Backup and disaster recovery** (moving local tape backups to Glacier), offloading file shares to S3, or providing local access to cloud data. |

#### Note on Amazon FSx File Gateway

It's important to know that there is a specific type of Storage Gateway called **Amazon FSx File Gateway**. This gateway connects your on-premises machines to an **FSx for Windows File Server** instance running in the cloud. In this case, the Storage Gateway is acting as the **local cache for the FSx file system**, allowing remote users to access the cloud-based FSx share quickly without having to route all their traffic over the full WAN distance.

### AWS Elastic Disaster Recovery 

---

Elastic Disaster Recovery replicates critical workloads to AWS with minimal downtime. Your servers' block-level data is continuously replicated to AWS, making it ideal for uses that require robust disaster recovery solutions. It supports both physical and virtual servers to enable rapid recovery during disruptions, which is particularly valuable for industries like healthcare where system availability is crucial.


---

![Elastic-Disaster-Recovery](../Images/Media/Elastic-Disaster-Recovery.png)
[Elastic-Disaster-Recovery](../Images/Elastic-Disaster-Recovery.md)

---

You can use Elastic Disaster Recovery to reduce downtimes and data loss while eliminating the costs associated with maintaining secondary data centers. It also offers non-disruptive disaster recovery testing, meaning it's capable of quickly launching recovery instances when needed.

**Benefits**

- **Business resilience** ​Maintain business operation with continues block-level data replication and the ability to **recover workloads within minutes** during disruption .

- **Streamlined disaster recovery 
​Automate disaster recovery processes** through an intuitive console, reducing complex manual configurations and minimizing the risk of human error.

- **Cost optimization** ​Eliminates expensive secondary data centers and pay only for what you use, with minimal upfront investment no standby infrastructure costs.

**Use cases** 

- **Healthcare and data protection** ​Hospital systems could use Elastic Disaster Recovery to maintain **compliance** while protecting patient records by **replicating on-premises** servers to AWS. This ensures that critical medical data remains **accessible during system outages**. Regular disaster recovery testing helps validate their recovery procedures and meet strict healthcare regulations.

- **Financial services continuity** ​A regional bank could implement Elastic Disaster Recovery to protect their core banking applications by continuously replicating their transaction processing systems. This facilitates quick recovery if their primary data center fails and helps **maintain customer trust** and regulatory compliance.

- **Manufacturing operation recovery** ​A global manufacturer could employ Elastic Disaster Recovery to protect their production planning systems. By replicating factory management servers to AWS, they can ensure **minimal disruption** to **supply chain operations** during **disasters**. **Regular failover testing** validates the recovery strategy.

### Cloud in Real Life: Comparing Storage Services 

Welcome back everyone to Cloud in Real Life. We've covered a lot of different AWS storage services so this time we're going to explore a few scenarios to help you understand when you should use them. Let's think back to the coffee shop this time. We have a **website** and it's currently being hosted using Amazon S3**.** Let's talk a little bit more about how that works.

Websites have a bunch of static assets and those are stored in an S3 bucket.

Exactly. We are using the **static website** feature of S3 to simplify the process.

S3 has a lot of different features and static website hosting is a really cool one for our learners to know about. Can you talk tome a little bit more about exactly how it works?

Oh yeah, sure sure. It's really straightforward All you need to do is upload your website's files like HTML, CSS, JavaScript, and media files to an S3 bucket, enable static web hosting, and - booyah! You've got a website.

Nice, that does sound pretty simple, but as we expand our business we also have to consider **scalability**. As more people visit the website, we need to not only ensure we're

using a performance solution, but also a **cost effective** one. And S3 has actually been great for this.

It has, you're right. And one of the best things about S3 is that it **automatically scales** to handle any amount of traffic without you lifting a finger. And you only **pay** for the **storage you use** and the **data transferred out of the bucket.**

So this is just one example of how the coffee shop can use S3. It's a really versatile service.

Oh yeah. So you know what, let's talk about another scenario. This time, let's say we are working on a solution for a **growing** fitness center The owners launched a **mobile app** to help members book classes. Unfortunately the app isn't able to handle a recent ramp up in traffic, and customers are complaining. The business suspects the database is the bottleneck. Any thoughts on how to optimize this, folks?

Yeah so, well in this case the app is using a database that's running on Amazon **EC2 instances** and the app itself is pretty performance critical from what I understand.

Yeah, the most popular classes fill up fast so **low latency** is key here.

Yeah, exactly. Look, we need to be consistent with this **high performance** especially for the **database read and write** operations.

Yeah that's definitely the goal, and a **relational database** uses something like **EBS volumes** for data storage when running on **EC2 EBS** is designed exactly for this kind of use case.

Look that makes sense to me, but the app is still experiencing some latency when trying to read and write to that database. Alan, can you tell our learners about how to optimize for performance with EBS?

Oh sure. Basically, **EBS volumes** are **optimized** for **transactional workloads** but some volume types are more performant than others depending on your use case. So we can look at the type of EBS volumes currently being used and migrate to a more performant volume type.

Yeah exactly, and I would suggest they provisioned **IOPs SSD volume type** for this workload. It offers the highest performance for mission critical applications like this mobile app. Now, I know it's not always clear when to use S3 or EBS. So Rudy, can you explain why S3 isn't being used here?

Well something like **S3** is ideal for **object storage**, but it's not designed for the kind of **rapid continuous rewrite operations** that a database requires.

Exactly, **EBS** gives you that **block level access** which is essential for databases.

Okay, so now let's talk about one more scenario before we wrap up. This time let's think of a chain of automotive repair shops. The owners want to create an **internal tool** to improve the knowledge and efficiency of their mechanics. They've decided to

build a **collaborative platform** to **share** repair techniques and diagnostic procedures across **multiple locations**. It needs to store and provide **real-time access** to high resolution images videos and technical diagrams from **various devices and locations**.

And because we are talking about multiple devices and various locations, accessing the same data we really need a **file system**. So I am definitely thinking **EFS** is the right choice for this use case.

And EFS can **scale** to petabytes without disrupting applications. It **automatically** grows and shrinks as you add or remove files so it is good for working with large media files like these images and videos. **EFS** provides **low latency** performance and can handle **high levels** of aggregate **throughput** and **IOPs**, so it's really perfect for **media processing workflows** like this.

Nice, EFS seems like the perfect fit for this project.

I agree, it's **real-time access** **shared file systems** and **scalability** are exactly what we need here.

All right so to recap, Amazon **S3** excels at **scalable object storage** for **web assets backups** and more. Amazon **EBS** provides **block level storage** needed for **EC2 instances** and **databases**. And Amazon **EFS** offers **managed shared file systems** from workloads that require **rapid simultaneous access to files**. Understanding these key differences will help you architect more efficient cost effective storage solutions in AWS. Until next time!



## Module 7 - Databases 

### Introduction to Databases

Well, we have quite a coffee operation going now.

We've got customers, lots of happy customers.

What we need now is some way to show our appreciation to our repeat customers.

How about a **loyalty program**?

Although we could just hand out punch cards, we can't track those well or use them to get to know our customers better.

We can use digital cards instead, but first, we need to be able to keep track of our customers, what they order, and how much they purchased.

This will help customers get the best rewards they've earned and help us to know our customer base better.

This means we need **databases**. And not just any database.

So, let's learn about the different services AWS offers to help you build the perfect database solution.

### Relational Databases 

So we’re storing data about our coffee shop in various systems. Now we need to store data for our loyalty program along with our transactional data to capture the relationships between the customers and their orders. And by relationships, I mean if a customer orders the same drink multiple times, maybe we send them a discount for their next order.

To do this, we need a way to keep track of this relationship somewhere. **Transactional data** is commonly kept in a **relational database management system**. This type of system stores data in a way such that it relates to other pieces of data.

For example, if we have a customer record, we store it in a customer table. We might also have an order record, which we store in a **corresponding** order table. We then **relate the tables** through a **common attribute**, and we can **query** data across both tables simultaneously.

The most common way to **interact** with a **database** is by **using Structured Query Language** or **SQL**. SQL runs on a variety of databases like MySQL, PostgreSQL, Microsoft SQL Server, and many more. If you have an **on-premises environmen**t, you're probably already running one of those databases, and they're most likely housed in your data center.

In fact, some companies are so fond of their database deployments that they want to keep them, but they still want to move to the cloud.  So, can they do both? Of course they can! These companies can perform a **lift-and-shift**. This means taking their **existing database deployment**, lifting it up from their **on-premises environmen**t, and shifting it onto an **Amazon EC2 instance**.

They still have **control** over the same variables they did in their on-premises environment, such as operating system, memory, CPU, storage capacity, and so forth. All they’ve done is moved from one location to another, with the other being the AWS Cloud in this case. Cool stuff, right? Even cooler is that they can use a service called **AWS Database Migration Service** to help make the process smoother.

But as companies - and you - become more comfortable with the cloud, you might think, "Doesn’t AWS have an option that makes database management even more seamless?"

The answer again is, of course! This option is called **Amazon Relational Database Service,** or Amazon **RDS**, and it offers **several database engines** you can use.

However, the key part here is that Amazon RDS comes with added benefits. These benefits include **automated patching, backups, redundancy, failover, and disaster recovery**, all of which you normally need to manage yourself. Amazon **RDS** is a popular option to AWS customers because it makes it possible for you to focus on business problems instead of maintaining databases.

After you deploy one RDS instance, you usually get a feel for it, sit down, relax, and your database administrators rejoice! Oh, and by using Amazon RDS, you also benefit from the **AWS shared responsibility** model **(**[SRM](../Concepts/AWS%20Shared%20Responsibility%20Model%20-%20SRM.md)).  This means you can take advantage of our **expertise** in **infrastructure management** while maintaining the **security** posture of your database.

We manage the underlying infrastructure, operating system, database software patching, and backup automation. In tandem, **you're responsible** for implementing **security** measures and configuring **encryption** for your **data at rest** and in **transit**. Teamwork makes the dream work, folks!

But we’re not done yet. We can actually go one step further and **migrate** or **deploy** to **Amazon Aurora.** This is a **fully-managed relational database** option. It supports Postgre, MySQL, and distributed SQL databases, or DSQLs.

And, get this, an **Aurora DB cluster** can include up to **15 Aurora Replicas located across Availability Zones** in the cluster’s AWS Region. That’s a lot of replicas! Additionally, **AWS Backup** supports **continuous backup** for **Amazon Aurora**. This allows specific **point-in-time restoration** within your retention period of **up to 35 days.**

Isn’t it cool how everything at AWS integrates into each other and can remove that heavy lifting from your hands? Look I think it’s cool. OK, my producer thinks it’s cool too. Thank you, producer. And to you, our learners, that’s relational databases in a nutshell.

#### **Relational databases**

Relational databases store data in a way that relates it to other pieces of data, and they use structured query language, or SQL, to manage and query data. This approach stores data in an easily understandable, consistent, and scalable way that works great for applications requiring structured data management.

AWS offers fully managed relational database solutions that remove the burden of database administration while maintaining high availability and security. AWS relational databases support popular database engines like MySQL, PostgreSQL, and Oracle, making it easier to migrate existing databases to AWS.



**Amazon Relational Database Service (Amazon RDS)**

---

Amazon RDS is a ***managed*** **relational database** service that handles routine database tasks such as backups, patching, and hardware provisioning. Amazon RDS **supports multiple database instance class** types that optimize for memory, performance, or input/output (I/O).


---

![RDS](../Images/Media/RDS.png)
[RDS](../Images/RDS.md)

---

To improve data resilience, Amazon RDS offers Multi-AZ deployment and automated backups, but you can also manually create backups using DB snapshots. These are full backups of your entire database instance, which can be useful for specific point-in-time recovery or long-term data archiving purposes. Amazon RDS offers security features including network isolation, encryption in transit, and encryption at rest. You can readily scale database resources vertically or horizontally as needed.

**Supported database engines**

Amazon RDS supports different database engines, including Amazon Aurora, MySQL, PostgreSQL, Microsoft SQL Server, MariaDB, and Oracle Database.

**Use cases**

Some examples of practical use cases for Amazon RDS are web applications, enterprise workloads, and product inventories for e-commerce platforms.

- **Cost optimization**

Amazon RDS eliminates the high upfront costs of purchasing and maintaining database hardware infrastructure. You only pay for the compute and storage resources that you consume through a flexible pay-as-you-go model. As a managed service, it also reduces operational expenses by automating time-consuming administrative tasks like backups, patching, and monitoring.

- **Multi-AZ deployment**

Amazon RDS improves database reliability through Multi-AZ deployments. It automatically replicates data to a standby instance in a different Availability Zone. During system failures, maintenance, or zone disruptions, Amazon RDS automatically fails over to the standby instance without manual intervention. This ensures continuous database operations with minimal downtime.

- **Performance optimization**

Amazon RDS enhances database performance through automated management of resource allocation, monitoring, and optimization tasks. It includes features like automated backups and read replicas that can help offload read traffic from the primary instance. Amazon RDS performance insights provide real-time monitoring and analysis of database load, to help you identify and resolve performance bottlenecks quickly.

- **Security controls**

Amazon RDS enhances database security through multiple layers of protection, including VPC isolation as well as encryption at rest and in transit. It leverages automated backups and offers Multi-AZ deployments to provide resiliency against potential system failures.

**Amazon Aurora**

---

Aurora is a managed relational database designed to help reduce unnecessary I/O operations. It's compatible with MySQL and PostgreSQL, provides high performance and availability, and automatically scales alongside your workloads. 


---

![Aurora](../Images/Media/Aurora.png)
[Aurora](../Images/Aurora.md)

---

Aurora replicates data across multiple Availability Zones for enhanced durability and fault tolerance, and features automated backups, encryption at rest, and continuous monitoring. Aurora provides comparable performance to high-end commercial databases but at one-tenth the cost, which makes it ideal for organizations looking to reduce database costs without sacrificing performance.

**Use cases**

Some examples of practical use cases for Aurora are gaming applications, media and content management, and real-time analytics.

- **High performance and availability**

Aurora delivers up to five times the throughput of standard MySQL and three times the throughput of PostgreSQL. It uses a distributed storage system across multiple nodes to provide high performance and availability.

- **Automated storage and backup management**

Aurora automatically grows storage from 10 GB to 128 TB based on your actual data usage, which eliminates guesswork in capacity planning. It also continuously backs up your database to Amazon Simple Storage Service (Amazon S3) to provide point-in-time recovery.

- **Advanced replication and fault tolerance**

Aurora replicates data across three Availability Zones with six copies of data, and provides 99.99% availability. It automatically detects database failures and redirects traffic to healthy replicas without data loss.

[Amazon RDS vs. Amazon Aurora](../Tables/Amazon%20RDS%20vs%20Amazon%20Aurora.md)

### NoSQL Databases Services 

**NoSQL databases**

NoSQL databases are sometimes referred to as ***non-relational databases*** because their structures are different than relational databases like Amazon RDS. Instead of row and column relationships, NoSQL databases build a structure for the data that they contain using ***key-value pairs*** instead. With key-value pairs, data is organized into **items identified by unique keys.**

Each **key** has one or more associated **attributes**, or **values**, that represent various characteristics of the data. You can think of a key as a word entry in a **dictionary**, and the value as its associated definition. Not every item in the table has to have the same attributes, and you can add or remove attributes at any time.

Aw yeah! It’s Amazon DynamoDB time! **DynamoDB is a fully managed serverless NoSQL database**. NoSQL means data is stored in a non-relational fashion instead of a relational database management system. Relational databases, like a standard MySQL database, require you to have a well-defined schema, which is one or more tables that might relate to each other. You then use SQL to query the data.

This works well for a lot of use cases, and has been the standard type of database historically. However, these types of **rigid SQL databases**, can have performance and **scaling issues** under specific circumstances. The rigid schema also means you can't always conveniently change that schema for any of the data you store in a table.

Therefore, it’s not usually the best fit for evolving datasets that can have **varying attributes**. But that’s fine. Since DynamoDB is non-relational, it gives you a **flexible schema**. You just create a table and start to store and query data.

Data is stored as **items**, and items are a collection of **attributes**. Each **attribute** has a **name** and a **value**. An attribute value can be **simpler** types like a **number** or more **complex** ones like a **set**, or a **document**. You can also add or remove attributes at any time, and **not every item** in the table needs to **have the same attributes**.

As for applications that need speed, DynamoDB offers **single-digit millisecond performance**. I mean that’s pretty fast. And, you get **no cold starts**, **no version upgrades, no maintenance windows, no patching, and no downtime maintenance**. Nada.

You can even use DynamoDB for **globally distributed applications**. That particular feature is called **DynamoDB global tables**. An awesome example of this feature in use is Amazon Prime Day 2024. For those 48 hours, there were tens of trillions of calls to the DynamoDB API. It peaked at 146 million requests per second. There was no underlying management needed, and it scaled seamlessly. Now that’s cool. I mean, seriously.

So, consider DynamoDB for your applications if you need the **speed**, **flexibility** of changing schemas, and **offloading of management**.

**Amazon DynamoDB**

---

DynamoDB is a fully managed NoSQL database service that provides fast and predictable performance for both document and key-value data structures. It's a powerful and incredibly fast database option for use cases that require a flexible schema, and is ideal for **applications** that require **high performance and seamless scaling.**


---

![DynamoDB](../Images/Media/DynamoDB.png)
[DynamoDB](../Images/DynamoDB.md)

---

DynamoDB seamlessly scales alongside your data without impacting performance, which means that you only pay for the resources that you use. It also includes built-in security features for enhanced protection, and **automatically spreads your data across multiple servers** to handle your workload.

**Use cases** ​Some examples of practical use cases for DynamoDB are g**aming platforms, financial service applications,** and **mobile applications** with **global user bases**.

- **Scalability with provisioned capacity**

DynamoDB automatically scales throughput up or down based on actual usage, which ensures consistent performance without manual intervention. You can specify **target utilization levels**, and DynamoDB automatically provisions capacity to maintain those targets. With no practical limits on table size or the amount of data stored, DynamoDB can seamlessly accommodate growing applications.

- **Consistent high performance**

DynamoDB delivers **single-digit millisecond response** times at any scale, which makes it ideal for high-performance applications. It maintains consistent performance by automatically distributing data across multiple servers and SSDs.

- **High availability and durability**

DynamoDB delivers 99.999% data availability by **replicating** data across **three** distinct facilities within each AWS Region. It also maintains multiple copies in separate AWS Regions, to provide **built-in fault tolerance** and **data durability**. This ensures continuous operation and protection against data loss even if individual facilities fail.

- **Data encryption**

DynamoDB offers comprehensive **encryption** capabilities to protect information both **at rest** and **in transit**. All data is automatically encrypted behind the scenes before being written to the storage layer. DynamoDB includes the flexibility to **choose between different kinds of encryption keys** for customized security control.

### AWS Databases Demonstration 

In this demo you'll explore a hands-on example of **configuring** two major database services: Amazon **RDS** and Amazon **Dynamo DB.**

Here we are in the AWS management console and to get started go to the search bar and enter *RDS*, and then select the service when it appears in the results. From there you'll find yourself in the Amazon **RDS dashboard**. Now you can choose *Create database* to get started. To **configure** this **database** we will choose ***MySQL***for the engine options. Then scrolling down, we will select the free tier template since we're just trying things out.

Then scrolling down some more we will provide a **database instance identifier**.

You can enter in a meaningful name for this one but for this demonstration we will leave it as *database-1*. To access the database after it's created you need to **configure authorization** under the credential settings. For the **username** we will leave it to be admin and then for the **password** I will enter in a password.

Scrolling down some more we need to find the ***connectivity***section, and from here you can select what sort of network you want to place this in. We'll leave the default VPC selected, but we do need to enable **public access**. So under *public access* I will choose *yes.*

This will allow us to easily connect to this database later in the demonstration using a **SQL client**. But in the real world, you likely would have this locked down so only **authorized applications** can connect.

Now we have all of our configurations in place, we will scroll to the bottom accepting the rest of the defaults, and then we will choose ***Create database***. You're then redirected to the databases page to wait for the **RDS instance** to finish creating. It's ready to use

when you see the status change from creating to available.

Now let's look at how to perform some basic commands in the **RDS MySQL instance** we just created. There are many different ways to connect to your RDS instance including a variety of clients. Setting up clients for connecting to the database is out of scope, but to set up the connection to the instance you would use the **endpoint** and **port values** shown on the ***connectivity*** *and* ***security*** **tab** of the *database-1* instance details page.

![image](../Images/Media/image%20(28).png)
[image](../Images/image%20(28).md)

Then to **authenticate** use the **username** and **password** that you defined when setting up the RDS instance. So using **that information**, we are **connected** to the **instance** and we can now **run the following SQL statements** to **create** a **database and 3 tables** in the RDS instance.

![image](../Images/Media/image%20(29).png)
[image](../Images/image%20(29).md)

We are creating the **database first** and then in that database we are **creating 3 tables users, products** and **orders**. These **tables relate to each other through foreign keys**, so if we run this these tables have now been created.

Now let's run some **insert statements** to insert **data** into those tables. Running these statements will populate 3 tables with some data. One thing to note is that **every entry in one table has to have the same columns**, so the **schema** here is **rigid**.

![image](../Images/Media/image%20(30).png)
[image](../Images/image%20(30).md)

Let's go ahead and run this, and now that we have some data in our tables, we can run this next statement to **retrieve data** from across the tables we just created. Running this statement **returns all orders a user placed joining together the data across the different tables into one result set**. Not too bad, right?

![image](../Images/Media/image%20(31).png)
[image](../Images/image%20(31).md)

Now that you know how to create and interact with a table in a basic RDS instance, let's shift focus to another AWS database service **Dynamo DB**. Unlike Amazon RDS, DynamoDB is a **NoSQL database** that doesn't require managing instances or multiple tables within a single database. Instead, it has its **own query language** and uses **stand-alone tables**. There is no concept like a foreign key to relate tables to each other. You don't use SQL to query the data and it has a **flexible schema**. Let's explore this.

Starting here in the AWS management console, enter *DynamoDB* into the search and then select the service when it appears in the results. After you're in the DynamoDB dashboard, choose ***Create table***. In the *table details* section enter the **table name "orders"** and then for the ***partition key*** we will choose ***number***from the dropdown and we will give the **partition key** a **name** - "***order number"*****.** Then, for this demonstration, we will keep the rest of the defaults scroll down to the bottom and choose***Create table*****.**

This is all you need to create a table - just the table name and the partition key. Every **item** in this table has to have a **value** for the ***partition key****,* but otherwise the schema for each item can vary. It's ready to use once you see the status change from *creating* to *active*.

Now let's add some items to the Dynamo DB table we just created. To do that, I have a **Python script** created that will **load 10 items into this database**. This is the code for this task, and don't worry too much about how this works. Instead, just understand that in order for applications to interact with DynamoDB, they **invoke** the **DynamoDB APIs using the AWS SDK**.  Let's give this a run using the terminal.

```python
import boto3
from botocore.exceptions import ClientError
from decimal import Decimal
#Create DynamoDB resource
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('Orders')
orders = [
{"OrderNumber": 1, "user": "Example Customer 1", "total": Decimal("29.99"), "items": ["notebook", "p "pen"], "status": "pending", "delivery": "standard",
["OrderNumber": 2, "user": "Example Customer 2", "total": Decimal("54.10"), "items": ["headphones"] "), "status": "shipped", "delivery": "express", "promo
("OrderNumber": 3, "user": "Example Customer 3", "total": Decimal("13.75"), "items": ["journal"], "st status": "pr "processing", g", "delivery": "standard", "prom
{"OrderNumber": 4, "user": "Example Customer 4", "total": Decimal("89.00"), "items": ["t-shirt", "jeans"], "status": "delivered", "delivery": "express"
{"OrderNumber": 5, "user": "Example Customer 5", "total": Decimal("19.99"), "items": ["book"], "status": "pending", ", "delivery": "standard", "promo": Fa
("OrderNumber": 6, "user": "Example Customer 6", "total": Decimal ("47.89", "items": ["water bottle", "mug' ug"], "status": "shipped", "delivery": "express"
["OrderNumber": 7, "user": "Example Customer 7", "total": Decimal ("22.5 "items": ["pen", "planner"], ], "status": "processing", "delivery": "standard"
["OrderNumber": 8, "user": "Example Customer 8", "total": Decimal ("36.0 , "items": ["backpack"], "status": "s "pending", "delivery": "standard", "promo"
{"OrderNumber": 9, "user": "Example Customer 9", "total": Decimal("63.20"), "items": ["keyboard", ", "mouse"], "status": "delivered", "delivery": "express"
{"OrderNumber": 10, "user": "Example Customer 10", "total": Decimal("38.00"), "items": ["charger"] "], "status": "processing", "delivery": "standard", "promo" }

]

#Insert items
print(" Inserting orders into DynamoDB...")
for order in orders:
try:
I
table.put_item(Item=order)
print(f" Inserted Order #{order ['OrderNumber']}")
except ClientError as e:
print(f"X Failed to insert Order #{order ['OrderNumber']}: {e.response ['Error'] ['Message']}")
```

OK, now that the script is done running we should have 10 items in the table.  Let's go check. So here we are back in the AWS management console. Let's select the table that we created and then we will run a **scan** on the table to see if those items loaded.

A **scan** will **bring back all of the data** in the table essentially performing a **read all type of query**. To do that choose ***Explore table items*** and then with the **scan selected**, choose ***Run****.* This will **display** the **results** from a scan that returns all of the **items** with the table entries listed down here under **items returned** You can scroll over to see all of the information that was entered by that Python script.

Notice how the *notes* attribute is not present for every item in the table. This is an example of showing how **Dynamo DB allows for a flexible schema**. **Not every item in the table needs to have the same attributes.**

Now, what if your table starts getting larger and you want to bring back **only data for one specific order**? For this demo, we will run a **query** to do this. So selecting *query* and then providing the ***order number****,* which in this case we can say we want to pull back order number 5.  We can then choose **run** and see that **only one item is returned**, which is order number 5.  

All right there is of course always more to learn but that wraps things up for this demonstration of AWS database services.

### In-Memory Caching Services 

As businesses experience **growth** in demand for their applications and services, it's not unusual for them to face **increasing pressure** on their **back-end relational databases**. Performance bottlenecks of this nature are common in databases, including Amazon RDS.

**Bottlenecks** can arise when dealing with **high read traffic volumes**, or when running c**omplex queries on large datasets.**

For example, think of an **e-commerce site** that uses Amazon **RDS** to store product information. When **thousands** of **customers repeatedly view the same product detail**s, the **database** must run that **same query over and over again**, returning the same results for each customer. This sort of **heavy read traffic** for **frequently accessed data** can overwhelm the database and lead to **latency and performance issues.**

This scenario isn't unique to e-commerce; many applications experience high volumes of read requests for **relatively static data**. There are many ways to improve performance to avoid these kinds of bottlenecks, and a particularly effective approach involves introducing a **caching layer** into the **architecture**.

**Caching reduces** the **pressure** on your **primary database** by **storing frequently accessed data** in a **high-speed, easily accessible location.** Data in a caching layer is commonly **stored directly** in the **system's memory** **instead** of on **disk**. This approach allows for **near-instantaneous access to data,** which can significantly **reduce the time** it takes to **serve requests to users.**

Additionally, **caching data reduces strain** on **backend databases** by **decreasing query volume**. Common **tools** for **caching** include **Redis OSS**, **Valkey**, or **Memcached**. **Amazon ElastiCache** provides a **fully managed cache** that is compatible with these tools to make caching on AWS more convenient.

**ElastiCache** can significantly **improve application performance** by delivering **microsecond latency for data reads and offloading database queries**. ElastiCache is **flexible** and makes it possible for you to **adjust the cache size according to demand**, while AWS manages the complex infrastructure tasks, which reduce operational overhead. There's also a **serverless** option for **ElastiCache that scales with demand**.

And one of my favorite benefits of ElastiCache is that it can be used as a **cost-optimization tool** for your **database deployments**. By directing your applications to use the cache, you can potentially use **smaller, more economical database instances**. Pretty cool!

Now, ElastiCache is useful for a wide range of applications that require quick access to data. For example, if you're running a **gaming platform**, you can use **ElastiCache** to maintain **real-time analytics** and **update leaderboards** efficiently. Or, if you're managing a **content delivery system,** you can use it to **store frequently accessed data** and ensure swift delivery to **end users.**

To better understand how ElastiCache fits into a typical **AWS architecture,** let's review a common setup involving **Amazon RDS**, **Amazon EC2, and ElastiCache**. In this **architecture**, an **EC2 instance hosts** your **application servers** while Amazon **RDS** provides the **backend relational database. ElastiCache** sits alongside the application and the database.

When a **user requests** data from your **EC2 application**, the application **first checks ElastiCache.**

If the **data exists** in the cache, it is **immediately returned to the user**. However, if the **data can't be located in cache**, the application will **read** the **data** from **RDS**, **store** it in **cache**, **then return it** to the **user**. This way the **next time** the **data** is **requested**, it's already in the **cache** and can be **retrieved quickly.**

![image](../Images/Media/image%20(32).png)
[image](../Images/image%20(32).md)

By reducing server load, providing **consistent performance** with **microsecond latency**, and **scaling efficiently to mee**t your needs, **ElastiCache** is a great way to level-up your databases.

---

**Amazon ElastiCache**

ElastiCache is a **fully managed in-memory caching** service that was built to help reduce the complexity of **administering in-memory caching systems.** This means that you can continue to use the same Redis, Valkey, or Memcached tools and configurations to scale your workloads. It **automatically detects and replaces failed nodes**, which makes it ideal for applications that need consistent high performance.


---

![ElastiCache](../Images/Media/ElastiCache.png)
[ElastiCache](../Images/ElastiCache.md)

---

### Use cases

Some examples of practical use cases for ElastiCache are **session data management,** **database query enhancement,** and **gaming leaderboards.**

#### In-memory caches

An in-memory cache is a high-speed storage layer that *temporarily stores frequently accessed data in* a computer's main memory, or *RAM*. Retrieving data from RAM provides extremely fast processing and retrieval speeds, often hundreds or thousands of times faster than traditional disk-based storage systems. In-memory caches are ideal for storing session data, API responses, database query results, and other information that applications require repeatedly.

**Benefits**

- **High performance for Redis, Valkey, or Memcached instances**

ElastiCache streamlines the deployment and maintenance of in-memory caching **environments**, offering high availability for Redis, Valkey, and Memcached by automatically handling hardware provisioning, software patching, and monitoring. ElastiCache offers **seamless scalability** so you can add or remove nodes as demand changes.

- **High availability**

ElastiCache provides high availability by constantly monitoring primary nodes for potential failures. When issues are detected, it maintains application availability while promoting a replica node to become the new primary without manual intervention. The entire recovery process typically finishes within minutes, which minimizes downtime and preserves operations during infrastructure disruptions.

- **Replication across multiple Availability Zones**

ElastiCache enables automatic replication across multiple Availability Zones to protect against infrastructure failures. You can configure primary and replica nodes across different Availability Zones according to their durability requirements. This helps to ensure that data remains accessible even if one zone experiences an outage.

- **Data encryption**

ElastiCache supports data encryption mechanisms to safeguard sensitive information throughout its lifecycle. **At-rest encryption** protects data while stored in disk storage and **automated backups**. **In-transit encryption** secures data traveling between **clients and cache nodes** by employing transport layer security, or **TLS**, for encrypted connections.

[ElastiCache](../Concepts/ElastiCache.md)

[Database Comparison: With vs. Without ElastiCache](../Tables/Database%20Comparison%20With%20vs%20Without%20ElastiCache.md)

### Additional Database Services 

Before we wrap up databases let's loop back to the topic that started all this: choosing the right database to fit your business needs, rather than forcing your data to fit your database's requirements. There is no one-size-fits-all database for all purposes. AWS recommends purpose-built databases for specific workloads.

We've covered quite a few database flavors already, but there are even more databases AWS offers for special business requirements. We don't have time to cover them all, but it's worth knowing about them in case you need them.

For example, Amazon **DynamoDB** is great for **key-value pair databases**, but what if instead of basic keys and values, you need your database to support semi-structured data?

That is, data with complex attributes that don't fit neatly into the rows and columns of a relational database.

---

**Amazon DocumentDB**

Amazon DocumentDB (with **MongoDB compatibility**) is **fully managed** service designed to handle **semistructured data**, which is information that doesn't conform to rigid relational schemas. Amazon DocumentDB is a MongoDB-compatible database, so it manages **JSON-like documents** with dynamic schemas.


---

![DocumentDB](../Images/Media/DocumentDB.png)
[DocumentDB](../Images/DocumentDB.md)

---

Amazon DocumentDB is perfect for applications requiring frequent schema changes and document-oriented data. Unlike relational databases or nonrelational databases, you can **quickly iterate** without relying on predefined schemas. Amazon DocumentDB can **store**, **query**, and **index JSON data** effortlessly, all while benefiting from **automatic scaling**, **continuous backup**, and **enterprise-grade security features.**

One can use Amazon **DocumentDB**, a specialized database service that helps manage data with complex, varied information that doesn't fit neatly into traditional spreadsheet-like tables. It's great for uses like **content management**, **catalogs**, and **user profiles**.

**Use cases**

Some examples of practical use cases for Amazon DocumentDB are **content management** systems, **catalog** and **inventory management,** and **user profile** and personalization systems.

- **MongoDB compatibility**

Amazon DocumentDB is fully compatible with **MongoDB** workloads and supports MongoDB APIs, drivers/**queries**, and tools. This compatibility means that you can use **existing MongoDB code** and skills without modification. You can also migrate MongoDB applications to Amazon DocumentDB with minimal changes to their application code.

- **Performance and scalability**

Amazon DocumentDB **automatically scales** storage up to **64 TB** in **10 GB increments** based on your application needs. It can handle **millions of requests per second** with consistent performance. It also provides the option to **scale compute resources** up or down as needed.

- **Increased read throughput**

Amazon DocumentDB improves **read throughput** for high-volume applications by creating up to **15 replica instances** that share underlying storage.

---

**Amazon Neptune**

Neptune is a **fully managed**, purpose-built **graph database** service that manages highly connected data sets, like those used in **social networking** applications. It excels at understanding **complex relationships** that are difficult to identify in traditional relational databases like **user connections, friend networks, and interaction patterns**. Neptune can maintain high performance even as data complexity grows, and offers **high availability with automatic failover and backups.**


---

![Neptune](../Images/Media/Neptune.png)
[Neptune](../Images/Neptune.md)

---

What if there's a **social network** that you want to track? Social webs that identify **who** is **connected** to **whom** are very clunky to manage in a traditional relational database.

**Amazon Neptune** was created to solve this problem. It's a **graph database** designed specifically to store and manage **interconnected data**, making it convenient to **query social networking data** to find **relationships** and **patterns**. It's also a great tool for **fraud detection**.

### Use cases

Some examples of practical use cases for Amazon Neptune are social network user connection mapping, fraud detection systems, and **search and recommendation systems.**

- **Purpose-built for complex relationships**

Neptune excels at storing and querying highly connected data using graph models. It supports both **property graph and resource description framework,** or **RDF**, models making it ideal for relationship mapping and **pattern matching applications.**

- **High performance and scalability**

Neptune delivers consistent performance at scale, **processing billions of relationships in milliseconds**. It **automatically grows** storage up to **64 TB** based on your application needs. Its purpose-built **engine optimizes graph querie**s to enable **fast traversal** of **connected data points** at scale.

---

**AWS** **Managed Blockchain**

Perhaps you have a **supply chain** that you have to **track** with **assurances** that nothing is lost. Think of a grocery store **maintaining data** on **shipments** from food suppliers to help ensure food safety. For this type of scenario we offer A**mazon Managed Blockchain**, a service that helps you create and manage **blockchain networks.**


---

![Managed-Blockchain](../Images/Media/Managed-Blockchain.png)
[Managed-Blockchain](../Images/Managed-Blockchain.md)

---

**AWS DynamoDB Accelerator**

Now databases by themselves are great but what if there was a way to make them faster? Wouldn't that be greater? AWS offers database accelerator options that can be used in a number of unique scenarios. For example, if you're using DynamoDB, try using the **DynamoDB Accelerator**, or **DAX**, a **built-in caching layer** designed to dramatically improve **read times** for your **nonrelational data.**

---

**AWS Backup**

AWS Backup **streamlines data protection across various AWS resources** and **on-premises deployments** by providing a **single dashboard for monitoring and managing backups.** It eliminates the complexity of managing multiple backup strategies by supporting multiple storage types, including Amazon Elastic Block Store (Amazon **EBS**) **volumes**, Amazon Elastic File System (Amazon **EFS**) file systems, and various **databases**.


---

![Backup](../Images/Media/Backup.png)
[Backup](../Images/Backup.md)

---

AWS Backup **centralizes** and **automates** data protection processes, improving consistency and **reducing administrative overhead**. It offers flexible **scheduling options,** **encryption capabilities**, and **cross-Region backup support** for enhanced **disaster recovery.**

**Use cases** ​Some examples of practical use cases for AWS Backup are centralized disaster recovery, consistent backup policies for **compliance requirements**, and c**onsolidating multiple backup processes** through a single interface.

**Benefits**

- **Centralized backup management**

AWS Backup provides a single dashboard to *manage backups across* ***multiple*** *AWS* ***services*** *and* ***accounts***. You can **monitor backup jobs, restore points**, and **verify compliance status** from one central location to reduce operational complexity and potential configuration errors.

You can create ***automated backup schedules*** that align with your business requirements and compliance needs. You can set up **backup policies** that automatically protect **new resources as they're created.**

- **Cross-region backup redundancy**

AWS Backup enables ***automatic replication***of backup data ***across*** *different* ***AWS Regions*** for disaster recovery purposes. You can quickly restore data from secondary Regions if the primary Region experiences an outage. Cross-Region redundancy helps you meet **compliance** requirements while guaranteeing data accessibility during Regional failures.

- **Streamlined regulatory compliance**

AWS Backup **maintains** ***detailed audit logs a****nd* ***reports***to demonstrate **compliance** with **regulatory** requirements. You can use it to *enforce backup policies* across your organization and track backup activities for security and compliance purposes.

There's one more important service that's related to databases and storage in general: **AWS Backup**. When planning for data backup, it's often a discussion of backing up the disks -- in this case, EBS volumes -- and backing up specific data in a structured way as it is stored in databases. And with all the types of databases at AWS this can lead to overlapping and confusing backup strategies and methods. AWS Backup simplifies this by supporting EBS volumes, EFS filesystems, RDS Databases, DynamoDB Tables and more-- even encompassing backup of data stored outside of AWS, say in an **on-premises deployment.**

---

#### AWS EMR

**AWS EMR**, or Elastic **MapReduce**, is a **managed** web service that simplifies running **big data frameworks** like **Apache** Hadoop and Apache Spark on AWS to process and a**nalyze large datasets.** It **automates** tasks like **cluster provisioning** and **tuning**, making it easier to **use open-source tools** for tasks like **machine learning,** **log file analysis, and web indexing.** EMR **separates** data storage (using Amazon **S3**) from compute (using Amazon **EC2** instances) to allow for **scaling** and **on-demand use.** 


---

![EMR](../Images/Media/EMR.png)
[EMR](../Images/EMR.md)

---

How it works

- **Managed service**: 

    AWS handles the provisioning, management, and maintenance of the infrastructure and software for the big data clusters, including tasks like capacity provisioning and cluster tuning. 

- **Open-source frameworks**: 

    It leverages popular open-source big data tools such as Apache Spark, Apache Hive, Apache HBase, Apache Flink, and Presto. 

- **Scalable infrastructure**: 

    It uses Amazon **EC2** instances to create resizable clusters for **distributed processing**, and data is stored in Amazon **S3.** 

- **Job execution**: 

    You can launch a cluster with specific frameworks and then run jobs on it by connecting to the master node or by sending steps (jobs) through the AWS console. 

Key features and use cases

- **Big data processing**: EMR is designed for processing massive datasets, with the ability to run petabyte-scale analyses. 

- **Machine learning**: It supports various machine learning tasks and frameworks. 

- **Interactive analytics**: You can perform interactive analytics on large datasets. 

- **Data pipeline automation**: You can automate data processing pipelines, for example, by creating steps that process data stored in S3. 

- **Security and access control**: It integrates with AWS Identity and Access Management (IAM) to control user permissions and uses security configurations to manage encryption and authentication. 

When to use AWS EMR

- You need to **process large volumes of data** using frameworks like Hadoop or Spark. 

- You want to **automate** big data **environment** setup, operation, and scaling. 

- You need to perform tasks like **machine learning**, **log analysis,** or **web indexing** on a large scale.



The key thing to understand is that AWS wants to make sure that you are using the best tool for the job.

A key benefit of **AWS Database Migration Service - DMS** is that the source database remains fully operational during migration, which minimizes downtime to applications.

[AWS Databases Table](../Tables/AWS%20Databases%20Table.md)


## Module 8 - AI/ML and Data Analytics  

### Introduction to AI and Machine Learning 

And we're back in the coffee shop! Each day, we see new and familiar faces while noticing the time when rush hours begin and end. We track which pastries and coffee blends fly off the shelves, and we keep an eye out for which coffee trends are the most popular.

What if we somehow tracked and analyzed all of this information and data? Could we use it to accurately predict what our customers might want next? Could we determine how many coffee beans to purchase for next month? Or even predict future demand for new coffee shop locations around the world? Over time, we could even use all of this data to invent entirely new drinks and menu items based on what we've learned. Of course, to do all this, we need a clean and reliable way to gather and process all of the relevant data points. Otherwise, we’re just guessing.

**AI**

**Artificial Intelligence** is a broad field focused on the **development** of **intelligent computer** systems capable of **performing humanlike tasks.**

This is where artificial intelligence and machine learning can be a huge boost for businesses. Artificial Intelligence, or AI, is a broad field focused on the development of intelligent computer systems capable of performing humanlike tasks.

**ML**

**Machine learning** is a **type of AI** for training machines to **perform** complex **tasks without explicit instructions.** **Machine learning training** finds the **patterns** hidden in vast amounts of **historical data** to produce an **ML model**. This ML model can then be applied to new data to make **predictions** or **decisions based** on the **patterns** it's **learned**.

---

Machine learning, or ML, is a type of AI for training machines to perform complex tasks without explicit instructions. For instance, we're creating an app so customers can order their coffee online. We want our app to **recommend food items** based on each c**ustomers' order history** to go along with their coffee purchase. This is a prime use case for machine learning!


---

![image](../Images/Media/image%20(33).png)
[image](../Images/image%20(33).md)

---

Now, without machine learning, using **classical programming**, you would typically set up **predefined rules** based on **established relationships** between different products. For example, previous customers who purchased a caramel latte often purchased a cheese Danish. You would create a rule that recommends a cheese Danish with any new caramel latte purchase. This rule might prompt some customers to purchase the recommended cheese Danish, but it doesn't really account for the individual customer or product.

---

![image](../Images/Media/image%20(34).png)
[image](../Images/image%20(34).md)

By contrast, **machine learning** finds the **patterns** between customers and sales **hidden in vast amounts of historical data**. This process is known as **training**. At the end of the training process, an **ML model** is created using the **patterns** that were found. 


---

![image](../Images/Media/image%20(35).png)
[image](../Images/image%20(35).md)

---

This model can then be used for **inference**, which means you give it **new data** and have it **make predictions** or **decisions based** on the **patterns** that it's learned.

So, taking our trained ML model, it is then applied to new data like customer purchases for a more relevant and **personalized** food **recommendation without explicit rules**. Recommendation or personalization engines like this are major use cases for machine learning.

Now, our customers can use our **ML-powered app** to order their coffee ahead of time and receive food **recommendations** that are tailored to their **personal preferences**. Our customers are happy, and our coffee shop sells more food items. Definitely a win-win!

So that is an example of using machine learning to improve business outcomes. But, let's talk about how we can use AI to innovate in other parts of our business, as well.

Imagine if we installed an AI-powered kiosk at the counter. As each customer steps up, the kiosk greets them, understands their spoken order, and enters it directly into the register for the baristas to fulfill. Using **natural language processing**, or **NLP**, the kiosk could even **ask clarifying questions**. For example, "Would you like an extra shot of espresso?" or "Are you interested in trying our new seasonal latte?" This kiosk isn't just rule-based. It's a **conversational AI** that can **change** and **adapt** to customer responses in **real time**.

Meanwhile, a separate AI system could **analyze** and **combine local coffee trends** on **social media** with our **own historical sales data**. It could then **predict** which drinks might be popular next week, or even generate new recipe ideas for our baristas to experiment with.

Those are just two examples related to our coffee shop. The technology behind AI continues to progress and it can help us innovate across different types of businesses.

AWS offers a variety of different services for machine learning and AI. You can **create**, train, and **deploy** your **own custom ML models** using tools like **Amazon SageMaker AI**. You can also choose from AI services that use **pre-built models** for **common tasks** like **language translation** or **image recognition**. By using these services on demand, businesses of all sizes can take advantage of AI without having to spend large amounts of time and money building everything from scratch.

But keep in mind that AI models are trained on data that can come from all sorts of places. These might include sales records, social media posts, sensor readings, customer feedback forms, and more. You'll need to gather that data, clean it up, and make sure it's in the **right format.** Without the **right data** and processes, your AI's predictions won't be very accurate.

### AI/ML on AWS

Businesses of all types have been using artificial intelligence and machine learning for years. For example, at Amazon, **ML models** power our **ecommerce recommendations** engine and **fulfillment center optimizations**, among many other areas.

But **ML models** can help solve a variety of problems outside of ecommerce. For instance, they can help make **predictions** about **stock market trends** or the **price** of **goods**. They can help route a caller to the right department based on a voice-prompt request. They can even detect **financial anomalies**, such as **fraud**, in online-banking systems.

Let's discuss the **AWS AI/ML stack.** It's composed of three tiers: **AWS AI services**, **AWS ML services**, and highly **customizable solutions** using **frameworks** and **infrastructure**.

AWS AI services are **managed services**. They provide you with access to **pre-built models** that are **already trained** to perform **specific functions**. These include **Amazon Polly for text-to-speech generation**, and **Amazon Comprehend for text or sentiment analysis.**

For use cases that require more customization, **AWS ML services**, such as **Amazon SageMaker AI**, can be the way to go. With SageMaker AI, you can **build**, **train**, and **deploy** your own **ML models** using **fully managed infrastructure**, **tools**, and **workflows**. SageMaker AI even helps you **track model training experiments,** **visualize data**, and perform model **debugging** and **monitoring** all within a **single environment.**

Sometimes though, your business requires a highly **specialized ML solution**. In these cases, you can choose a completely custom ML modeling approach by **using AWS frameworks** and **infrastructure**. This includes using **purpose-built chips** that **integrate** with popular **ML frameworks**. You can even build a solution hosted on an **ML-optimized EC2 instance.**

In the following lessons, we'll dive into the world of AWS AI/ML. And we'll even explore the emerging field of generative AI and the AWS services that make it all possible.

### AWS AI/ML Solutions 

Let's examine the three tiers of the AWS AI/ML stack in more detail. You can think of the tiers as a progression from **pre-built, easily deployable managed solutions** to highly **customized** solutions that require more skill to implement.

#### Tier 1: Pre-built AWS AI services

The AWS AI services tier is made up of pre-built models that are already trained to perform specific functions. These ready-to-use, managed services can help you quickly solve for a variety of business use cases. In the next section, you will learn about the following three groups of AWS AI services:

- Language services

- Computer vision and search services

- Conversational AI and personalization services



####  **Language services**

AWS AI language services are great for when you need to **interpret text or speech** and **transform** it into something **meaningful**. Let's examine how these services solve for some common use cases.

![image](../Images/Media/image%20(36).png)
[image](../Images/image%20(36).md)


---

> **Amazon Comprehend**

Amazon **Comprehend** uses natural language processing to extract **key insights** from **documents**. It develops these insights by recognizing **key phrases,** **language**, **sentiment**, and other common elements in documents.

**Use cases:** **Content classification**, **customer sentiment analysis**, and **compliance monitoring**


---

![image](../Images/Media/image%20(37).png)
[image](../Images/image%20(37).md)

---

---

> **Amazon Polly**

Amazon Polly **converts text into lifelike speech**. It supports multiple languages, different genders, and a variety of accents.

**Use cases: Virtual assistants**, **e-learning applications**, and accessibility enhancements for **visually impaired users**


---

![image](../Images/Media/image%20(38).png)
[image](../Images/image%20(38).md)

---

---

> **Amazon Transcribe**

Amazon Transcribe **converts speech into text**. It supports multiple languages and offers features such as **speaker identification**, custom vocabulary, and **real-time transcription**.

**Use Cases:** **Customer call transcription**, **automated subtitling**, and metadata generation for media content.


---

![image](../Images/Media/image%20(39).png)
[image](../Images/image%20(39).md)

---

---

> **Amazon Translate**

Amazon Translate is a text translation service. This service is ideal for global communication because it supports real-time and batch text translation across multiple languages.

**Use cases:** Document translation and multi-language application integrations


---

![image](../Images/Media/image%20(40).png)
[image](../Images/image%20(40).md)

---

---

####  **Computer vision and search services**



These services are ideal for **answering questions** and **gathering insights** from various types of content sources such as documents, images, videos, and more. Let's look at some examples.

---

> **Amazon Kendra**

Amazon Kendra uses **natural language processing** to **search** for **answers** within **large amounts of enterprise content**. Because it understands the context of a **query**, it can return more **precise** and **relevant answers** than just a list of documents with matching keywords.

**Use cases:** **Intelligent search**, **chatbots**, and application search integration


---

![image](../Images/Media/image%20(41).png)
[image](../Images/image%20(41).md)



---

---

> **Amazon Rekognition**

Amazon Rekognition is a **video analysis** service. It can **identify objects,** **people**, **text**, **scenes**, and **activities within images and videos** stored in Amazon Simple Storage Service (Amazon **S3**).

**Use cases:** **Content moderation**, **identity verification**, **media analysis**, and home automation experiences


---

![image](../Images/Media/image%20(42).png)
[image](../Images/image%20(42).md)

---

---

> **Amazon Textract**

Amazon Textract detects and **extracts typed and handwritten text** found in **documents**(including scanned documents in image formats), **forms**, and even **tables** within documents. Preserves table structure (rows, columns, cells).

**Use cases:** **Financial**, healthcare, and government form text extraction for **quick processing**


---

![image](../Images/Media/image%20(43).png)
[image](../Images/image%20(43).md)

---

---

####  **Conversational AI and personalization services**

With these services, users can **interact** with your **apps** through **text and voice conversations**. You can also present your customers with **product recommendations** personalized just for them. Let's explore these services.



> **Amazon Personalize** 

---

**Key Features**

- ML service for building personalized recommendations.

- No ML expertise required for deployment.

- Integrates with applications via API.

- Optimized for real-time personalization.

**Common Use Cases**

- Recommending products to e-commerce customers

- Personalizing content for streaming platforms

- Suggesting relevant articles in news apps


---

![image](../Images/Media/image%20(44).png)
[image](../Images/image%20(44).md)

---

---

> **Amazon Lex**

With Amazon Lex, you can **add voice** and **text conversational interfaces to your applications**. This service uses both **natural language understanding** (NLU) and **automatic speech recognition** (ASR) to create **lifelike conversations.**

**Use cases:** **Virtual assistants**, natural language search for FAQs, and **automated application bots**


---

![image](../Images/Media/image%20(45).png)
[image](../Images/image%20(45).md)

---

[AWS pre-built (managed) AI services](../Tables/AWS%20pre-built%20(managed)%20AI%20services.md)

An AWS Comprehend Medical architecture diagram 

[https://claude.ai/public/artifacts/59192e14-8274-4693-af61-e96f0b6eb474](https://claude.ai/public/artifacts/59192e14-8274-4693-af61-e96f0b6eb474)

---

#### Tier 2: ML services

The ML services tier provides a **more customized** approach for customers who want a bit more **control** over their **ML solutions** without having to manage infrastructure. **SageMaker AI** is a key offering in this tier.

---

**Amazon SageMaker AI**

With this **fully managed service**, you can **build**, **train**, and **deploy** your own **ML models** without worrying about infrastructure. The SageMaker AI integrated development environment (**IDE**) provides simplified access control and transparency over your ML projects. You can **track model training experiments**, **visualize data**, and **debug** and **monitor** your workflows all within **one environment**. SageMaker AI even offers **access** to hundreds of **pre-trained models** that you can deploy in a few quick steps.


---

![image](../Images/Media/image%20(46).png)
[image](../Images/image%20(46).md)

---



---

**Choice of ML tools**

Increase innovation with different tool choices. **Data scientists** can use the **IDE**, and **business analysts** can use the **no-code interface.**


---

**Fully managed infrastructure**

Focus on ML model development while SageMaker AI provides you with **high-performance**, **cost-effective infrastructure.**


---

**Repeatable ML workflows**

**Automate** and **standardize** your **MLOps** practices and governance across your enterprise to support **transparency** and **auditability**.


---

---

#### Tier 3: ML frameworks and infrastructure

Some organizations have **highly specialized** needs that require **complete control** over the **ML training process**. They can use in-house expertise, ML frameworks, and AWS infrastructure to develop their own ML solutions.

> **ML frameworks**

An ML framework is a **software library** or tool that provides **experienced ML practitioners** with **pre-built**, **optimized components** for building **machine learning models**. AWS supports ML frameworks like **PyTorch**, **Apache** M-X Net, and **TensorFlow**.

> **AWS ML infrastructure**

AWS **ML infrastructure**, such as **ML-optimized** Amazon Elastic Compute Cloud (Amazon **EC2**) **instances**, **Amazon EMR**, and Amazon Elastic Container Service (Amazon **ECS**), can support these custom solutions. These services provide high performance and flexibility for **advanced ML workloads.**

[Bedrock vs. SageMaker](../Tables/Bedrock%20vs%20SageMaker.md)

### Introduction to Generative AI

We've talked about AI, and we've talked about its subset, machine learning. Let's go even further and talk about deep learning. Deep learning is a subset of machine learning. The theory behind it has been around for decades, but we lacked the hardware to realize it until recently.

In deep learning, models are trained using **artificial neural networks** that mimic the human brain. These networks contain layers of artificial neurons, or **math functions**, that mimic real human neurons. Each of them **summarizes** and **feeds information** to the **next layer** of **artificial neurons** until a **final model** is **produced**. This advanced technique helps us tackle more complex problems than ever before, such as computer vision, and **natural language processing.**

All of this makes **generative AI** possible. You might have heard of it. **Generative AI is a type of deep learning** that produces **models** capable of **creating new content and ideas**, like conversations, stories, images, and music. Generative AI is powered by extremely **large machine learning models** that are **pre-trained on vast collections of data.** These are commonly called **foundation models,** or **FMs**.

Large language models, or **LLMs**, are a popular type of **foundation model** that are trained on vast amounts of text so they can learn how human language works. Unlike **traditional ML models**, which are trained to perform **singular tasks**, **pre-trained FMs** can be adapted to perform **multiple tasks**.

![image](../Images/Media/image%20(47).png)
[image](../Images/image%20(47).md)

AWS provides tools and services to help you **build** and **scale** customized **generative AI solutions** tailored to your business.

The first of these services is Amazon **SageMaker JumpStart**. SageMaker JumpStart is a **machine learning hub** with **foundation models** and **prebuilt ML solutions** that you can deploy with a few clicks. These **pre-trained models** are **fully customizable** for your specific use case, by using **your own data.**

**Amazon Bedrock** is a **fully managed** service that offers a broad choice of high-performing, **pre-trained foundation models** from Amazon and **other leading AI companies**. With Amazon Bedrock, you can privately **adapt these models with your data** and deploy them without managing infrastructure. You can even use a common **API to access multiple** **FMs**.

**Amazon Q** is an **interactive assistant** that can be tailored to your business. It seamlessly **integrates** with **your company's information repositories** so it can engage in **contextualized conversations**, provide insightful **solutions**, and **complete actions** relevant to your organization. The **Amazon Q family** of products includes **Amazon Q Business** and **Amazon Q Developer.**

The capabilities of generative AI are exciting to contemplate. It's already helping us reimagine customer experiences, boost productivity, and drive innovation.

**Deep learning**

Deep learning (DL) is a subset of machine learning where models are trained using layers of artificial neurons that mimic the human brain. Each layer of these neural networks summarizes and feeds information to the next layer until a final model is produced.

**Generative AI**

Generative AI is a type of deep learning powered by extremely large ML models known as foundation models (FMs). FMs are pre-trained on vast collections of data. While traditional ML models are trained to perform singular tasks, FMs can be adapted to perform multiple tasks.

Large language models (LLMs), are a popular type of FM trained to use human language. Foundation models can also be used to create videos, images, music, and more.

---

- ***Amazon SageMaker JumpStart***

    - An ML hub with FMs and pre-built ML solutions deployable with a few clicks


---

![image](../Images/Media/image%20(48).png)
[image](../Images/image%20(48).md)

---

---

- ***Amazon Bedrock***

    - A fully managed service for adapting and deploying FMs from Amazon and other leading AI companies


---

![image](../Images/Media/image%20(49).png)
[image](../Images/image%20(49).md)

---

---

- ***Amazon Q***

    - An interactive AI assistant that can be integrated with a company's information repositories


---

![image](../Images/Media/image%20(50).png)
[image](../Images/image%20(50).md)

---

**How to develop Gen AI with AWS**

[https://claude.ai/public/artifacts/43e0d9fe-37a2-4dcc-9272-c67e5c3013dc](https://claude.ai/public/artifacts/43e0d9fe-37a2-4dcc-9272-c67e5c3013dc)

![genai_development_paths](../Files/Media/genai_development_paths.html)
[genai_development_paths](../Files/genai_development_paths.md)

**Deep Learning & Generative AI Explained**

[https://claude.ai/public/artifacts/8e2680de-3031-43be-931c-418c46a1f7a6](https://claude.ai/public/artifacts/8e2680de-3031-43be-931c-418c46a1f7a6)

![deep_learning_hierarchy](../Files/Media/deep_learning_hierarchy.html)
[deep_learning_hierarchy](../Files/deep_learning_hierarchy.md)

**Simple Example:**

**Scenario:** You run an e-commerce company

**Use SageMaker ML for:**

- Predicting which customers will return a product (you train on YOUR past return data)

- Detecting fraudulent transactions based on YOUR transaction patterns

- Recommending products based on YOUR customer behavior

**Use Bedrock FM for:**

- Creating a chatbot that answers customer questions in natural language

- Generating product descriptions automatically

- Summarizing customer reviews

- Translating product pages to different languages

#### Key Differences: SageMaker ML vs Bedrock FM

| Aspect               | SageMaker MLs                 | Bedrock FMs                                |
| :------------------- | :---------------------------- | :----------------------------------------- |
| **Training**         | **YOU train it from scratch** | **Already trained** (by Amazon/others)     |
| **Model Size**       | Small to medium (MB-GB)       | HUGE (100+ GB)                             |
| **Data Needed**      | Your specific labeled dataset | Already trained on billions of data points |
| **Tasks**            | ONE specific task             | MANY different tasks                       |
| **Time to Deploy**   | Days/weeks (training time)    | Minutes (ready to use)                     |
| **Expertise Needed** | ML engineering skills         | API integration skills                     |
| **Cost Model**       | Pay for training compute      | Pay per API call/token                     |

---

### Amazon Generative AI Solution 

- Amazon SageMaker JumpStart for accelerating model development and deployment.

- Amazon Bedrock for deploying high-performing FMs through a single API. 

- Amazon Q integrates with your existing information repositories to answer questions and helps generate insights and new content.

#### **Amazon SageMaker JumpStart**

SageMaker JumpStart is a machine learning hub within SageMaker AI that **accelerates** the process of **building**, **training**, and **deploying ML models**. SageMaker JumpStart offers a **library** of **pre-built ML** solutions across various domains such as computer vision, NLP, and tabular data. These pre-trained models can be fine-tuned to suit your specific needs and deployed with just a few clicks.

- **Rapid ML model deployments**

Quickly deploy pre-trained models without extensive ML expertise.

- **Custom fine-tuned solutions**

Fine-tune pre-trained FMs with your domain-specific data.

- **ML experiments and prototypes**

Compare performance for different models before committing to a specific approach.

#### **Amazon Bedrock**

Amazon Bedrock is a **fully managed** service that was specifically designed for working with large foundation models and building generative AI applications. It provides access to FMs from Amazon and leading AI startups, such as **Claude** and **Stable Diffusion**, all through a **single unified API**. With Amazon Bedrock, you can quickly experiment with FMs, fine-tune them with your own data, and seamlessly integrate them into your AWS applications.

**Uses :**

**Enterprise-grade generative AI**

Build **production-ready** generative AI applications with enterprise-level security, privacy, and scalability.

**Multimodal content generation**

Create **applications** that can **generate multiple content types**, such as text and images.

**Advanced conversational AI**

Develop advanced conversational **agents** that connect to **your enterprise data** to provide **accurate responses.**

#### Amazon Q products

Amazon Q is a generative AI assistant that can help companies streamline processes, get to **decisions faster**, and improve **employee productivity**. It can help every employee gain insights into their data and accelerate their tasks.

**Amazon Q Business**

Amazon Q Business can **answer** pressing **questions**, help **solve problems**, and **take actions using the data** and expertise found in **your company's information repositories**. Amazon Q Business provides this tailored assistance with a secure connection to commonly used systems.

**Use cases:** Information requests, automated workflows, and insight extraction

**Amazon Q Developer**

Amazon Q Developer provides **code recommendations** to accelerate development for coding languages including C#, Java, JavaScript, Python, and TypeScript applications. It **integrates** with multiple **IDEs** and helps developers write code faster by **generating** entire functions and logical blocks of **code**.

**Use cases:** Faster code generation, improved reliability and security, and automated code reviews

### Introduction to Data Analytics 

Let's talk about data. It's what makes advanced technologies like AI and ML possible. In turn, the predictive capabilities of AI/ML are revolutionizing the way we analyze data.

Both AI/ML and traditional data analytics need **clean and accessible data**. Data analytics is when analysts transform **raw historical data** to uncover valuable insights and **trends**. And, though there is a lot of focus on AI/ML in today's tech landscape, traditional data analytics are still incredibly relevant and necessary.

For example, loan companies rely on data analytics to explain lending decisions to customers. Medical researchers still need traditional methods like hypothesis testing to analyze clinical trial data. And insurance companies use analytics to make sure their risk assessment models can be clearly understood and approved by regulators. Additionally, with smaller datasets, data analytics methods can be more efficient and more cost-effective than AI/ML methods.

Regardless of the method, both AI/ML and traditional data analytics have one thing in common: they're hungry for data. **Lots and lots of data**! This data can come from any number of source systems. Every time you make a purchase, log into a website, or even just browse online, you're generating data. All of this data is scattered across different systems and formats. To have any hope of analyzing it or making use of it, it needs to be brought together in **one place**. This is where the concept of **data lakes** comes in. A data lake is like a giant reservoir where businesses can **store all of their data.**

But having all of your data in one place isn't enough. It also needs to be in a **format** that's usable by **analytics tools** and **AI algorithms.** This is where the **extract**, **transform**, and **load**, or **ETL processes** are used. With ETL, you **extract** the data from various source systems and **store** it. Then, you **transform** it into a consistent usable **format** for downstream tools to consume. And then, you **load** it into a **destination system**, like a data warehouse or **analytics platform**. Or sometimes, you might follow an **ELT** pattern instead, where you **extract** the **data** and **ingest** it, **load** the data into the **tools**, and then **transform it as needed**. The choice depends on your specific needs and infrastructure.

Sometimes ETL isn't even necessary. **A zero-ETL process** works fine when your **data** is already in a **usable format** and **location** to be consumed by target systems.

When ETL or ELT is needed, **data pipelines** are used to make the process efficient and **repeatable**. These pipelines serve as **assembly lines** that help **automate** the **flow** of **ingesting data, processing it, and making it consumable.**

AWS has a suite of services for every step of this process. That includes **data ingestion** services like **Amazon Kinesis** and **AWS Glue**, and **storage** solutions like Amazon S3or **Amazon Redshift**. For **processing data**, tools like **Amazon EMR** are available, and for **visualization**, you can use services like **Amazon QuickSight**.

AWS services integrate with each other in different ways. So, let's say you’re using Amazon S3 as a data lake where you have ingested a massive amount of raw data. You can set up processes to make that same data set available for a wide variety of different business needs. For example, your marketing team can use QuickSight to analyze a dataset for business intelligence. And your data science team can use that exact same dataset in Amazon SageMaker AI to train ML models.

**Data pipelines for ETL processes**

1. *Extract* the data from various sources and store it.

2. *Transform* it into a consistent, usable format for downstream tools to consume.

3. *Load* it into a destination system, like a data warehouse or analytics platform.



## **Data Pipelines on AWS**

It's time to explore data pipelines on AWS. A data pipeline **automates** the process of **ingesting**, **cataloging**, **transforming**, and **delivering data** from **source to destination**. This streamlining helps reduce manual effort and minimize errors.

But to understand these concepts better, let’s take a step back and review a generic data pipeline.

The **first part** of our pipeline is where we **ingest** and **store** our required **data**. Data can come from many different sources such as applications, databases, live sensors, and streams. To gain insights, we need to consolidate this data in a **single location** and transform it into a useful **format**. Two choices are **data lakes** and **data warehouses**. Data lakes can store vast amounts of **raw data** and are more **flexible**. Data warehouses, however, are more structured because they are **optimized** for **business intelligence**. Amazon **S3** is a popular choice for **data lakes**, and Amazon **Redshift** is commonly used for **data warehouses.**

Let's move to **ingestion**. This is the process of **moving data** from the **source** systems into our chosen **storage solution.** Some applications might require **real-time ingestion,** whilst others can **tolerate** some **latency**, which makes **batch ingestion** the more appropriate choice.

---

**Amazon Kinesis Data Streams**

You can use Kinesis Data Streams for real-time ingestion of terabytes of data from applications, streams, and **sensors**. This **serverless** service even provides **automatic provisioning** and **scaling in on-demand mode.**


---

![image](../Images/Media/image%20(51).png)
[image](../Images/image%20(51).md)

---

**Amazon Kinesis** **Data Streams** is ideal for **real-time** data ingestion. This is vital for applications requiring **low-latency processing**. Even better, **multiple apps** can consume data from the **same stream simultaneously**. A financial services company might use Kinesis Data Streams to ingest real-time stock market data so they can analyze it for immediate trading decisions.

[Amazon Firehose and Kinesis](../Concepts/Amazon%20Firehose%20and%20Kinesis.md)

---

**Amazon Data Firehose**

Firehose is an option for data ingestion in near real-time. This fully managed service provides automatic provisioning and scaling. It also delivers data within seconds to data lakes, warehouses, and analytics services.


---

![image](../Images/Media/image%20(52).png)
[image](../Images/image%20(52).md)

---

Another service to mention is **Amazon Data Firehose**, which is a **fully managed near-real-time streaming ETL solution**. Firehose **collects data from a source and delivers it to a destination**. For example, a smart home device manufacturer might use Firehose to collect device data from all its devices for long-term storage and analysis.

Once data is ingested and stored, the **next step** is to **catalog** that data using a **centralized data repository**. This provides an inventory of your organization's data. It's like when you take a selfie on your smartphone. It contains metadata, like the time you took the picture, where you took it, and its format. Is it a GIF? GIF? GIF me a break!

**AWS Glue** is a managed service with a feature called the **Data Catalog**. You can use **this centralized repository** to **store metadata** about your organization's data sets.

**Next**, we need to **clean** and **transform** our data so it’s ready to be **analyzed**. For this, you can use **AWS Glue**. It’s a fully managed service that offers **visual ETL job creation**, **built-in job scheduling,** and support for **various data sources** and **formats**. It's ideal for organizations looking for a **simplified** approach, and it offers **code-free script creation** as well.

---

**AWS Glue**

AWS Glue is a **fully managed ETL** service that makes data preparation simpler, faster, and cost effective. AWS Glue ETL jobs can use the AWS Glue Data Catalog to access metadata about data sources, which can help inform transformations defined in the ETL script.


---

![image](../Images/Media/image%20(53).png)
[image](../Images/image%20(53).md)

---

---

**AWS Glue Data Catalog - (also explained in** [Amazon Athena](../Concepts/Amazon%20Athena.md))

AWS Glue Data Catalog provides a centralized, scalable, and managed metadata repository that enhances data discovery. It improves the overall efficiency of data pipelines by delivering metadata to various data stores and analytics services.


---

![image](../Images/Media/image%20(54).png)
[image](../Images/image%20(54).md)

---

For more **complex data processing**, there's **Amazon EMR**. It’s ideal for **large-scale data** processing using popular **frameworks** like **Apache** Spark, Apache Hadoop, and Apache Hive. Amazon EMR is best suited for organizations with existing big data expertise and those requiring **customized configurations.**

---

**Amazon EMR**

Amazon EMR is ideal for large-scale data processing and organizations with existing big data expertise. It **automatically** handles infrastructure **provisioning**, **cluster management**, and **scaling**. Amazon EMR supports popular big data frameworks like Apache Spark, Apache Hadoop, and Apache Hive.


---

![image](../Images/Media/image%20(55).png)
[image](../Images/image%20(55).md)

---

OK folks, so we've ingested, stored, cataloged, and processed our data. It’s finally ready to be used. Actually, I can see a bunch of consumers lined up already to analyze the data. But they're looking for the right **query solution.** Well, good news for them! They have lots of options, including **Amazon Athena** and **Amazon Redshift**, among others.

---

**Amazon Athena**

With Athena, you can run **SQL queries** to analyze data in relational, nonrelational, object, and custom data sources. This **fully managed** serverless service can access data hosted on Amazon **S3**, **on premises**, or even in **multi-cloud environments**. It offers a **cost-effective** solution for data analysis because you only **pay** for the **queries** you run.

[Amazon Athena](../Concepts/Amazon%20Athena.md)

---

![image](../Images/Media/image%20(56).png)
[image](../Images/image%20(56).md)

---

**Athena** is a **fully managed serverless service**. You can submit a **SQL query** to analyze data in **relational**, **nonrelational**, **object**, and **custom data sources** running on Amazon **S3** or even **hybrid environments**. Oh yeah, it can analyze data outside of AWS, too.

---

**Amazon Redshift**

Amazon Redshift is a fully managed data warehouse solution. Its columnar storage and massively p**arallel processing architecture** make it ideal for a**nalyzing large datasets**. You can use it to perform complex SQL queries on large datasets for frequent, high-performance analytical workloads.


---

![image](../Images/Media/image%20(57).png)
[image](../Images/image%20(57).md)

---

If you prefer a **fully managed data warehouse solution**, then **Amazon Redshift** is the ideal choice. It’s better suited for complex queries on large datasets and **frequent**, **high-performance analytical workloads.** Amazon Redshift can store **petabytes** of **structured** or **semistructured data**. With the **scalability** and **pay-as-you-go** pricing model, organizations can **cost-effectively** analyze large datasets.

[Amazon Athena vs Amazon Redshift - in a ETL process](../Concepts/Amazon%20Athena%20vs%20Amazon%20Redshift%20-%20in%20a%20ETL%20process.md)

OK, after they have queried their data, analysts usually need to **visualize** everything. For this, analysts can use **Amazon QuickSight** and **Amazon OpenSearch Service.**

---

**Amazon QuickSight**

With QuickSight, both technical and **non-technical users** can quickly create modern interactive **dashboards** and reports from various data sources without managing infrastructure. Amazon Q in QuickSight provides natural language queries so business analysts and users can build, discover, and share meaningful insights in seconds.


---

![image](../Images/Media/image%20(58).png)
[image](../Images/image%20(58).md)

---

**QuickSight** is ideal for **unified business intelligence**, or **BI**, at **scale**. Both technical and **non-technical users** can **quickly** c**reate interactive dashboards and reports.** This means they can all meet their specific analytical needs without waiting on development teams. Also, with **Amazon Q in QuickSight**, they can use **natural language** to **build**, **discover**, and share **meaningful insights.**

---

**Amazon OpenSearch Service**

With OpenSearch Service, you can **search** for **relevant content** through **precise keyword matching** or **natural language queries**. **Unified dashboards** provide **real-time data visualization** as you **analyze** and **monitor** logs, **traces**, and **metrics** for various applications.


---

![image](../Images/Media/image%20(59).png)
[image](../Images/image%20(59).md)

---

Let's flip to **OpenSearch Service**. It can be used for **real-time search**, **monitoring**, and **analysis** of **business and operational data.** This is especially helpful for use cases like **application monitoring**, **log analytics,** **observability**, and **website search.**

[QuickSight vs OpenSearch](../Tables/QuickSight%20vs%20OpenSearch.md)

And with that, we’ve come to the end of this video. Remember that this is just the tip of the data pipeline iceberg.



### Data Analytics and AI/ML

#### Cloud in Real Life: Data Analytics and AI/ML:

**Morgan:** OK, wow! We covered a lot of great information in this module.

**Rudy:** Oh fully! And I think it’s only fitting that we dive into another diagram. Alan, time to break out that ecommerce app you have lying around.

**Alan:** That is a great idea! Here, we can see this company has trained a machine learning model to make **recommendations** to customers using its **online app**. The company needs to keep this **model up to date** with the latest data. Data scientists also need to **query** that same data for **important insights.**

**Morgan:** I see where you're going with this, Alan. It's a perfect use case for an **automated data pipeline** because we need to **continuously** **collect** and **analyze** customer **data**. So, this company is **storing historical** customer **data** gathered from the app in an Amazon **DynamoDB** table.

**Alan:** Yeah, exactly. So, DynamoDB is a good fit for **low-latency reads and writes**, but it’s **not practical** to **scan all the data** in a **DynamoDB** table to **train a model**. We really need to bring this data into **storage**, like a **data lake**, so that it can be available to the **machine learning process** used for personalized **recommendations**. And so, the data needs to go on a little journey.

**Rudy:** Oh, a journey! I love this part—a data pipeline journey! Learners, an **automated data pipeline** can help deliver data using an **efficient, repeatable, and error-free process.**

**Morgan:** So, the **first** step is to **ingest** the data. Amazon **Data Firehose** makes a lot of sense here. It provides **near real-time data ingestion**(like 5 minutes intervals). Plus, it requires **minimal setup** and gives you **automatic** **scaling**. The catch here is that there currently isn't a direct integration between DynamoDB and Firehose. We actually need to send the data changes from DynamoDB through **Amazon Kinesis Data Streams** first.

E-commerce ML Data Pipeline - Firehose role - [Amazon Firehose and Kinesis](../Concepts/Amazon%20Firehose%20and%20Kinesis.md)

[https://claude.ai/public/artifacts/695d8737-dc2f-4221-a321-9ff5ae89929c](https://claude.ai/public/artifacts/695d8737-dc2f-4221-a321-9ff5ae89929c)

**Alan:** So, DynamoDB sends the data to Kinesis Data Streams, then **Firehose aggregates** that **data** and delivers it to **S3 in near real time**. That’s awesome! But the data coming from DynamoDB will be in **JSON** format and a little birdie tells me the **ML engineer and data scientist** need the data in **comma-separated values**, or .**csv**, format. We're going to need to transform the data.

**Rudy:** Ah, yes. Luckily, **Firehose** has a feature where it can **invoke** an AWS **Lambda function**. That function can **transform** incoming source **data** and then deliver the resulting data to a destination. That means after it's processed and properly **formatted**, say as a .csv file, the data is **available** for delivery to **multiple consumers** in **S3**.

**Morgan:** Right. And, in this case, the data is delivered toS3, which is the **data lake** for this company. This is where the company stores all of its **data** used for **ML and analytics**. The data scientists will want to run **ad-hoc queries** against the data, but we need a way to make this **data discoverable** so it's **accessible** for **querying**. To achieve this, we'll use the **AWS Glue Data Catalog as the metadata repository** and set up a **table** for the **customer data**. The Data Catalog will make it possible for us to define tables that describe the **schema** and **location** of our **data** stored in **S3**.

**Rudy:** Schweet, bru. That's amazing. And, this is perfect for **Amazon Athena**. Data scientists can simply run standard **SQL queries** against the **data** in **S3**. The **data doesn't** even need to be **moved out of S3** itself. Better yet, Athena can use the **table stored** in the **Glue Data Catalog**. This helps to **automatically recognize** the **schema** and **structure** of the **data**. Athena is so cool. I mean, seriously. It's so easy to set up and use.

[Amazon Athena](../Concepts/Amazon%20Athena.md)

**Morgan:** Yeah, I agree, I really love using Athena. Also, for our **pipeline**, **Amazon SageMaker A**I can **read** the latest information **directly from S3** to **train new versions of the model.**

**Alan:** That's right. And the beauty of the **data pipeline** is that after it's set up, it can **repeat automatically** based on a set **schedule**. The **data scientists** can focus on **gathering insights**, and the **ML engineers** can focus on keeping the **model up to date.**

**Morgan:** OK, well, that's great! This is a real time saver. It's super common that the **same data** needs to be **used** for **more than one purpose**. So, this is a really good example of that.

**Rudy:** Oh, and this is just a basic pipeline. Imagine manually performing all these steps for a more complex one?

**Morgan:** Yeah, for real. As usual, **automation** is key for **efficiency** and innovation.

# Complete E-commerce ML Data Pipeline Architecture

[https://claude.ai/public/artifacts/59a8c3c1-2aa1-40cc-b5df-06709ab19357](https://claude.ai/public/artifacts/59a8c3c1-2aa1-40cc-b5df-06709ab19357)



![image](../Images/Media/image%20(60).png)
[image](../Images/image%20(60).md)

1. Make recommendations

    An e-commerce company uses an ML model to make product recommendations.

2. Store app data

    An Amazon DynamoDB database stores the historical customer data gathered through the app. This makes sense for low-latency reads and writes but isn't ideal for ML model training.

3. Ingest data

    Kinesis Data Streams ingests the data from DynamoDB. Amazon Data Firehose then aggregates the data.

4. Process data

    The data is in JSON format, so Firehose invokes an AWS Lambda function that transforms the data into .csv format.

5. Deliver data

    Firehose then delivers the data to the company's Amazon S3 data lake, where it is available for multiple consumers.

6. Catalog data

    AWS Glue Data Catalog serves as a metadata repository with tables that describe the schema and location of the Amazon S3 data.

7. Perform data analytics

    Data scientists use Athena to gather insights through queries.

8. Train model

    SageMaker AI reads the same dataset directly from Amazon S3. ML engineers can then train new versions of the recommendation model using the latest information.

[AWS Data Pipeline Services](../Tables/AWS%20Data%20Pipeline%20Services.md)

[Complete AI-Powered E-commerce Platform](../Concepts/Complete%20AI-Powered%20E-commerce%20Platform.md)

[AWS Data Pipeline(s)](../Concepts/AWS%20Data%20Pipeline(s).md)


## Module 9 - Security

### Introduction to Security 

In fact, every one of us has a role to play in security. To help you on your way of becoming a security guru, two crucial security components you should know about are authentication and authorization.

**Authentication** is the process of **verifying** the **identity** of a **user** or entity through **credentials** like a **username** and **password** combination.

**Authorization**, on the other hand, determines which **actions** users **are permitted** to **perform** in a system or application. This is usually done by **granting** a user **certain access rights** and **permissions**.

For instance, **authentication** permits me to **log in** to our employee portal. But **authorization** limits me to just the **areas** that I'm **allowed to access**, such as my own employee records.

![image](../Images/Media/image%20(62).png)
[image](../Images/image%20(62).md)

Authentication and authorization play a vital role in data privacy and protection. Organizations must, therefore, safeguard all their users' personal information. This protection helps to maintain customer trust and prevent identity theft and financial fraud.

In essence, **organizations must prevent unauthorized access** and **misuse** as much as possible.

In this spirit, AWS offers multiple security mechanisms like the [AWS Shared Responsibility Model - SRM](../Concepts/AWS%20Shared%20Responsibility%20Model%20-%20SRM.md), and a few other examples like:

- Preventing security incidents through proper permission and **access ma**nagement

- Proactively addressing security issues through **network, application, and data protection**

- And quickly **detecting** and **responding** to **security incidents as they occur**

And with that, let’s get things started and take a look at the different security services, mechanisms, and features that AWS has to offer.

### Preventing Unauthorized Access 

When you create an AWS account, you are given what is called the **AWS account root user**. This root user is the **owner** of the account and has permission to do anything they want inside of that account.

This is like being the owner of the coffee shop.

In this situation, let's say I am the owner of the coffee shop. I can come into the shop, use my credentials to work the register, work the inventory system, or any other system in the coffee shop. I cannot be restricted.

With the AWS account **root user**, you can access and control any resource in the account. You can spin up databases, EC2 instances, machine learning services, or literally whatever you want. Because that user is so powerful, we recommend that when you create an AWS account, you associate a strong password with your root user account. Then, as soon as you log in with your root user, you turn on **multi-factor authentication**, or **MFA**. This ensures that you need not only the email and password, but also a randomized token to log in.

Now, that's great. But even with MFA turned on, for security reasons, you really **don't** want to use the **root user** for **daily tasks**. So, with that being said, you can control access in a granular way on AWS by using the service, **AWS Identity and Access Management**, or **IAM.**

In IAM, you can create **IAM users** to represent **individual identities**. When you create an IAM user, by **default**, they have absolutely **zero permissions**. They can't launch an EC2 instance. They can't create an S3 bucket. Nothing. You have to **explicitly grant** the **user permission** to do anything in the account. So, remember, by default, all actions are denied. You have to explicitly allow any action done by any user. You give people **access only** to **what they need** and nothing else.

This idea is called the **least privilege principle**. And the way that you grant or deny permission is to associate what is called an **IAM policy** to an IAM user. An IAM policy is a **JSON document** that **describes** what **API calls a user can or cannot make**. Let's take a look at this quick example.

In this example, you can see we have a **permission statement**. This permission statement has the **effect** defined as **Allow**, the **action** as **s3:ListBucket**, and the **resource** is a **unique ID(arn)** for the **S3** bucket.

```json
{
  "Version": "2012-10-17",
  "Statement": {
    "Effect": "Allow",
    "Action": "s3:ListBucket",
    "Resource": "arn: aws : s3 : : : coffee_shop_reports'
  }
}
```

So, if I attach this policy to a **user**, that user could **view** the **bucket** coffee_shop_reports, but perform **no other action** in this account. To break this down further, it's good to note that there are only **two potential options** for the **effect** on any policy: either **allow** or **deny**.

For **action**, you can **list any AWS API call**, and for **resource**, you would list what AWS resource that **specific API** call is for.

Now, as a businessperson or **non-technical person**, you likely would not need to write these types of policies yourself. But, they are used all over in AWS accounts. One way to make it more convenient to manage your users and their permissions is to organize them into **IAM groups.** Groups are, well, they are groupings of users. You can **attach** a **policy** to a **group** and all of the **users** in that group will **inherit those permissions.**

Alright, so far with IAM, you have the root user—they can do anything. You have users that can be organized into groups. And you have **policies**, which are documents that describe permissions that you can then attach to users or groups. There is one other major identity in IAM, and that’s called a **role**.

This idea of **temporary access** is important to understand when thinking about how **IAM roles** work in AWS. Roles, similar to users and groups, can have **associated permissions** that allow or deny specific actions. And these roles can be **assumed** for **temporary** amounts of time. It’s similar to a user, but has **no static credentials** like a **username** and **password**. Instead, it’s an identity that can be **assumed to gain access to temporary permissions**. You use roles to temporarily grant access to AWS resources, to users, external identities, applications, and even other AWS services.

**Roles** are particularly helpful when trying to manage **permissions at scale** in an organization. By using roles, you can actually avoid creating IAM users for every person in your business that needs access to your AWS account. You can accomplish this by federating users into your account. This means that they could use their regular corporate credentials to log into AWS by **mapping their corporate identities to IAM roles.**

**IAM Identity Center** is a service that can help you set up and manage this process. With this service, you can set up single sign-on so that your users get a streamlined login experience when accessing AWS account resources.

With IAM, we have authentication and authorization in place. So, I know my employees will only have access to what they need, which prevents some security incidents before they can even start.

---

#### AWS Identity and Access Management (IAM)

**Securely manage identities and access to AWS services and resources.**

One of the best ways to prevent security incidents before they happen is through proper permission and access management. With IAM, by default, all actions are denied. You must explicitly grant permission to someone before they can perform any actions in your account.


---

![image](../Images/Media/image%20(63).png)
[image](../Images/image%20(63).md)

---

When you grant permissions, you should provide access only on a need-to-have basis. This concept is called the principle of least privilege.

> *The* ***principle of least privilege*** *dictates that you should only give people and systems access to what they need and nothing else.*

IAM provides users, groups, and roles so you can configure access based on your company’s specific operational and security needs. IAM policies define the needed access for these identities.

![image](../Images/Media/image%20(64).png)
[image](../Images/image%20(64).md)

Now that you understand the fundamentals of IAM, let's learn how this works in the **AWS Management Console.**

#### Demonstration: AWS Identity and Access Management 

Now that you understand the basics of IAM, let's see how this really works. In this demonstration, I'll create a new user and then add them to a group. Then I'll create a role that can be assumed to gain access to temporary credentials.

I'll begin by searching "IAM" in the search bar. And then, I will choose the IAM service. The **IAM dashboard** provides a bunch of different resources for managing user permissions. In this demo, we'll be focusing on the **Access management section of the navigation pane.**

The first thing we need to do is to **create** a new **IAM user profile** for an employee named John Doe. I'll select Users from the navigation. And you can see we already have one user here named "**admin**." I will go ahead and select Create user.

And, this brings me to a series of steps that help me define this user's information. In the first step, I'll give my user a **unique name**. john_doe works! And then, I'm going to check the checkbox to provide user access to the AWS Management Console so that John can login to the console. Then, I will scroll down and select **Next**.

And now we need to set the **permissions**. At this point, I could choose to **attach permission policies** directly to John's **user identity.** But, we have a standard set of permissions for our employees that I'll need to update from time to time. It would be much more convenient to **manage these permissions all at once**, instead of modifying each employee's permissions individually. Thankfully, we can do this using an **IAM group**. And wouldn't you know it, that's the recommended action! Any existing IAM groups will be listed on this page with the Add user to group option selected. I can conveniently **add** John **to the appropriate group** if it's already been created.

Because I want to establish a new IAM group, I will select Create group. I will name this group "employees." Next, I'll assign permission policies to the group. I'm presented with a long list of policies to choose from. I can shorten this list by searching for a specific policy.

Or, I can filter the list by choosing from the Filter by Type drop-down menu. By default, this menu is set to show me all permission policy types.

There are two permission policy types to be aware of. **AWS managed policies** and **Customer managed policies**. AWS managed policies are standalone policies **created and administered by AWS**. I can apply these policies to as many users as I want.

I can also create **my own permission policies** if I have a specific use case where I need **custom control**. These policies can be found under the **Customer managed policies.**

For now, I'm going to provide my employees group with the **ViewOnlyAccess** that is managed by AWS. I can add more permissions in the future, if I'd like. I'm curious about how this policy works. So, I can expand it to **view the JSON** and learn more about this specific policy.

Next, I will go ahead and select **Create user group**. And, after the group is created, I can then select it. And now, I can choose **next**. And John will be added to this group, and he will receive the ViewOnlyAccess permissions granted to the group. Any new group members will also have these permissions.

Now we are presented with a page to view the **user details** and **permissions summary**. Everything looks good, so I will choose **Create user** to complete John's user account.

Now let's move on to creating an **identity** that can be **assumed** as **temporary**, **rotating credentials** to access AWS resources. For this, I will create an **IAM role**.

I will return to the Users list, select Continue, and then we are brought back to the **dashboard**. Now, I will select **Roles** from the **navigation**, and then **Create** role. For **Trusted Entity Type**, I'll choose **AWS account.** And then I will require **MFA** to turn on multi-factor authentication. This will provide an extra layer of security.

Let's say this temporary role needs **access** to Amazon **S3**. I'll select **Next**. And then we can search for S3 permissions. I'll type in "s3." I'll select **AmazonS3ReadOnlyAccess** and **AmazonS3TablesReadOnlyAccess** permission policies for **minimum access** to our data. Then, I will scroll down and select Next. At this step, I'll enter "s3_read_only" into the **Role name** field and then we can review the role details. Everything looks good, so I will scroll down and then select **Create** role.

Now, someone can **assume** the role and the **needed permissions** to **access** Amazon **S3**, as defined in the policy. When they assume this role, they will have access to our Amazon S3 bucket, but nothing else.

IAM roles are used for many different use cases, including granting temporary permissions to access specific AWS resources like our S3 bucket. **Roles** allow AWS **services** to **interact with each othe**r to enable federated identity access for users and applications, and to support **cross-account access** for secure **resource sharing.**

---

**AWS IAM Identity Center**

IAM Identity Center centralizes identity and access management across AWS accounts and applications. IAM Identity Center can also connect to an **existing identity source** and provide your workforce with **single sign-on access** to all your connected AWS services and accounts. This is called **federated identity management.**


---

![image](../Images/Media/image%20(65).png)
[image](../Images/image%20(65).md)

---

> ***Federated identity management*** *is a system that allows users to access multiple applications, services, or domains using a single set of credentials.*

---

**AWS Secrets Manager**

Secrets Manager provides a secure way to manage, **rotate**, and retrieve **database credentials**, **API key**s, and other **secrets** throughout their **lifecycle**. This helps keep your applications, services, and IT resources safe.

[Secrets Manager](../Concepts/Secrets%20Manager.md)

---

![image](../Images/Media/image%20(66).png)
[image](../Images/image%20(66).md)

---

> ***Secrets*** *are confidential or private information intended to be known only to specific individuals or groups. Examples include passwords, database credentials, and API keys.*

---

**AWS Systems Manager**

Systems Manager provides a **centralized** view of **nodes** across your **organization’s accounts** and **Regions** and **multi-cloud** and **hybrid environments**. With this service, you can quickly access **node information**, such as **ID** and **operating system details**, and **automate registry edits**, **user** management, and **security** patching. 
​***Nodes*** *are connection points in a network, system, or structure****.***


---

![image](../Images/Media/image%20(67).png)
[image](../Images/image%20(67).md)

---

AWS Secrets Manager(SM) vs SSM Parameter Store (PS)

| **Feature**              | **AWS Secrets Manager (SM)**                                                                          | **SSM Parameter Store (PS)**                                                                        |
| :----------------------- | :---------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------- |
| **Primary Focus**        | **Secrets Management** (database credentials, API keys, OAuth tokens).                                | **Configuration Management** (app settings, AMI IDs, URLs) and simple secrets.                      |
| **Automated Rotation**   | **Built-in Native Support** for databases (RDS, Redshift, DocumentDB). **Primary value proposition.** | **No built-in rotation.** Requires custom code (e.g., a Lambda function scheduled via EventBridge). |
| **Encryption**           | **Mandatory** (always encrypted by default). Cannot store plaintext data.                             | **Optional** (`SecureString` for encryption or `String` for plaintext/config data).                 |
| **Cost**                 | **Paid service** (billed per secret stored per month + API calls).                                    | **Standard tier is FREE** (up to 10,000 parameters) for storage and standard throughput.            |
| **Cross-Account Access** | **Easier** to configure, supporting central secrets management.                                       | Supported, but requires more manual IAM setup.                                                      |
| **Maximum Size**         | Can store secrets up to **64 KB** in size.                                                            | **4 KB** (Standard) or **8 KB** (Advanced tier).                                                    |
| **Versioning**           | Supports **staging labels** to manage multiple active versions during rotation.                       | Supports version history, but only **one version is active** at any time.                           |

A software development team needs to centrally manage its database credentials and API keys on AWS.

Which of these services should the team choose?

- AWS Identity and Access Management (IAM)

- AWS IAM Identity Center

- **AWS Secrets Manager**

- AWS Systems Manager

**Secrets Manager** can provide the team with a secure way to manage, rotate, and retrieve database credentials, API keys, and other secrets throughout their lifecycle.

### Protecting Network and Applications

Network and Application Protection:

Now, let's discuss how you can **proactively** address some security issues by protecting your network and applications.

You might have heard of **DDoS**, which stands for **distributed denial of service**. It's an attack on your enterprise's infrastructure. Your security team might have written a plan for it, and many businesses have been devastated by it. But what exactly is it, and more importantly, how can you defend against it?

In normal operations, your application takes requests from customers and returns results. In a denial-of-service attack, a bad actor tries to **overwhelm** the **capacity** of your **application**, basically to **deny anyone your service**s. But a single machine attacking your application has no hope of providing enough of an attack by itself.

So, the **distributed** part is when the attack uses other machines around the internet to **unknowingly attack** your infrastructure. The bad actor creates an army of zombie bots, brainlessly assaulting your enterprise as you **process an unbearable workload.**

For example, the **UDP** flood Denial of Service attack is based on the helpful parts of the internet, like the National Weather Service. Anyone can send a small request to the weather service, and say, "Give me the weather forecast." In return, the weather service's fleet of machines will send back weather telemetry, forecasts, and updates. To initiate the attack, the **bad acto**r, and its army of zombie bots, send a s**imple request**: give me the weather forecast. But they give a **fake return address** on the request—**your return address.** So, the weather service very happily **floods** your server with megabytes of rain forecasts. And your system could be brought to a standstill by just sorting through the information it never wanted in the first place. That's just one example of half a dozen low-level, brute-force attacks, all designed to **exhaust your network.**

Fortunately, AWS can **automatically defend** your **infrastructure** from these crippling assaults. How? Let's examine the **UDP flood attack.**

**Security groups**

Security groups only allow in proper request traffic. They operate at the AWS network level so they can shrug off massive attacks using the entire AWS Region's capacity.

The AWS solution here is **Security groups**. Security groups only allow in **proper request traffic.** Things like weather reports use an entirely **different protocol** than the ones **your customers** use. Not on the list, you don't get to talk to the server. And what's more, **security groups operate** at the **AWS network level**, **not at the EC2 instance level**, like an operating system **firewall** might. So, massive attacks like UDP floods just get shrugged off by the scale of the entire **capacity** of the **AWS Region**, **not your individual EC2 capacity.**

---

**Elastic Load Balancing (ELB)**

ELB handles traffic first before handing it off, so your frontend server is not overwhelmed. Like security groups, it runs at the Region level.


---

![image](../Images/Media/image%20(68).png)
[image](../Images/image%20(68).md)

---

Another strategy is the use of **AWS managed services**. Simply making the **front door** of your **application** an **Elastic Load Balancer instead of an EC2 instance** does a lot to **mitigate** an **attack**. That's because **AWS Shield Standard** automatically protects AWS resources from the most common, frequently occurring types of DDoS attacks. **Shield Standard** is **built into AWS managed services** like **Elastic Load Balancing, CloudFront, and Route 53 at no extra cost.** The **enormous capacity** of **Regions** makes them **extremely difficult to overwhelm**. It would be massively expensive to achieve.


**AWS Shield**

---

*AWS Shield* ***Standard***is designed to **automatically** protect AWS customers from the most common, frequently occurring types of DDoS attacks at no cost. It uses a variety of analysis techniques to detect and mitigate incoming malicious network traffic in real time.

*AWS Shield* ***Advanced***is a **paid** service that provides detailed attack diagnostics and the ability to detect and mitigate **sophisticated DDoS attacks**. It also integrates with other services, such as Amazon CloudFront, Amazon Route 53, and ELB.


---

![image](../Images/Media/image%20(69).png)
[image](../Images/image%20(69).md)

---

Additionally, you can integrate AWS Shield with AWS WAF by writing custom rules to mitigate complex DDoS attacks.

---

**AWS WAF**

AWS WAF is a **web application firewall** that monitors **network requests** that come into **your web applications**. When a request comes into AWS WAF, it checks the IP address against a web access control list (**web ACL**). If the request comes from a **blocked IP address** on the web ACL, AWS WAF denies access. Legitimate requests are allowed access.


---

![image](../Images/Media/image%20(70).png)
[image](../Images/image%20(70).md)

---

AWS Shield can be **combined** with **AWS Web Application Firewall,** or **WAF**, to further protect your environment. AWS WAF **filters incoming traffic** for the signatures of **bad actors**. It has extensive **machine learning capabilities**, and can **recognize new threats as they evolve**. So, it can **proactively** help **defend** your system against an ever-growing list of destructive vectors.

For even more protection, you can use **AWS Shield Advanced**. This is a **paid service** that provides **detailed attack diagnostics** and the ability to **detect** and **mitigate sophisticated DDoS attacks.**

Unfortunately, DDoS network and application threats exist. But AWS infrastructure and specialized security services can help you can stop these attacks to protect your enterprise.

**DoS attacks**

In a denial of service attack, an attacker floods a web application with excessive network traffic. Legitimate customer requests are denied if the web application becomes overloaded and can no longer respond.

In a distributed denial of service (DDoS) attack, an attacker can use multiple infected computers (called *zombie bots*) to unknowingly send excessive traffic to a web application.

#### AWS Services for DDoS Protection

| **Service**                        | **Primary Function in DDoS Defense**                                                                                        | **DDoS Layer(s) Covered**     | **Key Features / Distinction**                                                                                                                                |
| :--------------------------------- | :-------------------------------------------------------------------------------------------------------------------------- | :---------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **AWS Shield** (Standard/Advanced) | **Managed DDoS Protection.** Detects and mitigates volumetric and sophisticated attacks.                                    | L3, L4, & L7                  | **Standard** is **free**, automatic protection against common attacks. **Advanced** provides 24/7 Shield Response Team (SRT) access and DDoS Cost Protection. |
| **AWS WAF**                        | **Application Layer Filtering.** A Web Application Firewall that monitors and blocks malicious web requests.                | Application (L7)              | Filters common web exploits (SQLi, XSS) and uses **rate-based rules** to mitigate HTTP floods and sophisticated attacks.                                      |
| **Amazon CloudFront**              | **Volumetric & Caching Defense.** Acts as a global Content Delivery Network (CDN) to absorb traffic at the edge.            | L3, L4, & L7 (via Caching)    | **Absorbs traffic** across 450+ Points of Presence (PoPs) globally, preventing requests from reaching the origin.                                             |
| **Amazon Route 53**                | **DNS Availability & Resilience.** Highly distributed and scaled Domain Name System (DNS) service.                          | DNS (a form of L3/L4)         | Designed to withstand large **DNS query floods** due to its massive scale and Anycast routing.                                                                |
| **Elastic Load Balancing (ELB)**   | **Traffic Distribution & Scalability.** Acts as the secure "front door" that scales automatically to absorb traffic volume. | L3 & L4                       | **Scales automatically** up to enormous capacity, making it extremely difficult to overwhelm; has **Shield Standard** built-in.                               |
| **Security Groups**                | **First-Line Network Filtering (Stateful Firewall).** Restricts traffic based on port and protocol.                         | Network (L3) & Transport (L4) | **Shrugs off massive attacks** (like UDP floods) by filtering unwanted traffic at the AWS network level before it reaches the EC2 instance.                   |

### Protecting Data

Let's return to our coffee shop. Our new app is increasing sales while also saving our customers time! No more long lines. Order your coffee, pick it up, and sip that caffeine goodness.

**We need to protect customer data that is shared through the app**. This data includes sensitive **personal information**, such **as phone numbers** and **credit card information.** Think about it. The last thing we want is for some hacker to steal our customers' data and run up high bills on our customers' credit cards! I mean, look, we would lose customer trust and potentially face **legal consequences**. These are big no-nos.

So, let's **proactively secure** that **data**. One well-known method is called **encryption**. It's like a lock and key mechanism. If you have the right key, you can open the lock. If not, then you are locked out. In this case, we only provide **authorized parties** with the right key to **encrypt** the **data**. Then, to unlock the lock, they **decrypt** their **data** by using that same exact key.

This comes in two flavors: **encryption at rest** and **encryption in transit**. At rest means that the data is idle and not moving.

For example, the secret recipe for Rudy's Rhubarb Refresher, Trademark, is stored in an Amazon S3 bucket. It's encrypted at rest but... you know, we've gotten to know each other a bit by now... so I'll let you in on the secret.... pssshh come closer... closer... The secret ingredient is....

Alright, let's examine how some AWS services encrypt data at rest.

With Amazon **S3**, all new buckets have **encryption** configured by **default**. Moreover, all **new objects** that are **uploaded** to an S3 bucket are **automatically encrypted at rest**.

Amazon **EBS volumes** and **snapshots** can be encrypted **at rest** as well. In fact, you can **encrypt** both the **boot** and **data volumes** of an **EC2 instance**.

And with **Amazon DynamoDB**, **server-side encryption** **at rest** is **enabled** on all table data using encryption keys stored in **AWS Key Management Service**, or **KMS** for short. In fact, KMS can be used across a wide range of AWS services for that extra bit of control.

**KMS** helps you **create** and **manage cryptographic keys**. These keys look like random strings of digits to the human eye, and they can be used to encrypt and decrypt your data. Additionally, you can set **specific levels** of access contro**l for your keys.** For **example, you can specify** which **IAM users and roles are able** to **manage keys**. You can also **disable keys** so they can no longer be used. And one other important thing to point out is that **your keys never leave KMS**, so you have complete control over them.

Flipping to **encryption in transit**, it means **data** is moving **between locations.** For instance, our coffee shop app needs to access a customer's phone number to text them that their order is ready. This phone number could be stored in a database. But, it would need to be sent over the network from one AWS service to another so we know where to send the text message.

For this, we can use a **protocol** called **Secure Sockets Layer**—or **SSL**, or **Transport Layer Security**—or **TLS**. TLS is an updated version of SSL. With SSL and TLS, you use **certificates** to **verify** the **identity** and subsequently **establish** an **encrypted network connection** from one system to another. This means bad actors can't access our customer's sensitive data in-transit. Actually, if you accessed our coffee shop website in a browser, you'd see this lock icon on the left here. The URL would also have **HTTPS** in the front. HTTPS stands for **hypertext transfer protocol secure**, and it means that the **site** is **secured** by an **SSL, or TLS certificate**.

The AWS service that **centralizes management of certificates** is aptly named **AWS Certificate Manager**, or **ACM**. What's nice about ACM is that it can be used to protect various AWS services, in addition to your connected **on-premises resources.**

### Types of data encryption

Data encryption comes in the following two forms: 

- **Data encryption at rest**: The data is idle and not moving, like when it's stored in a database.

- **Data encryption in transit:** The data is moving between locations, like when it's being sent from a database to an application. SSL/TLS certificates are used to establish encrypted network connections from one system to another.

![image](../Images/Media/image%20(71).png)
[image](../Images/image%20(71).md)

**AWS built-in data protection**

- **Amazon S3**

By default, all new S3 buckets have encryption configured, and all uploaded objects are encrypted at rest.

- **Amazon EBS**

Amazon EBS volumes and snapshots can be encrypted at rest, including both boot and data volumes of an Amazon EC2 instance.

- **Amazon DynamoDB**

Server-side encryption at rest is enabled on all DynamoDB table data using encryption keys stored in AWS Key Management Service (AWS KMS).

**AWS data protection services**

---

**AWS Key Management Service (AWS KMS)**

You can use AWS KMS to create and manage cryptographic keys. These keys can then be used to encrypt and decrypt your data. You can also control the use of keys across a wide range of services and in your applications. For example, you can specify which IAM users and roles can manage keys. Your keys never leave AWS KMS, and you can temporarily disable them so they can no longer be used.


---

![image](../Images/Media/image%20(72).png)
[image](../Images/image%20(72).md)

---

> *A* ***cryptographic key*** *is a random string of digits used for locking 
​(encrypting) and unlocking (decrypting) data.*

---

**Amazon Macie**

With Amazon Macie, you can **monitor your sensitive data at rest** to make sure it's safe. Macie uses **machine learning** (ML) and **automation** to discover sensitive data stored in Amazon S3. You can use Macie to **assess your security posture**, which is especially helpful for meeting **compliance** requirements.


---

![image](../Images/Media/image%20(73).png)
[image](../Images/image%20(73).md)

---

---

**AWS Certificate Manager (ACM)**

ACM centralizes the management of your SSL/TLS **certificates** that provide data encryption **in transit.** It can be used to protect various AWS services and your connected on-premises resources.

***SSL/TLS certificates*** *are used to establish encrypted network connections from one system to another.*


---

![image](../Images/Media/image%20(74).png)
[image](../Images/image%20(74).md)

---

### Detecting and Responding to Security Incidents 

By now, you can tell that security is extremely important for all businesses. You should always be working to prevent and proactively address security events. You also need to be able to detect and respond to security issues quickly. Remember our attempted break-in?

Sometimes, security events occur due to unaddressed **software vulnerabilities**, simply because you didn't know they were there.

---

**Amazon Inspector**

Amazon Inspector helps improve the security and compliance of applications by running automated security assessments for Amazon **EC2** instances, **containers**, and **Lambda functions**. It checks applications for security vulnerabilities and deviations from security best practices, such as **open access** to **EC2** instances and installations of vulnerable software versions.


---

![image](../Images/Media/image%20(75).png)
[image](../Images/image%20(75).md)

---

**Amazon Inspector** helps to bring **attention** to these potential vulnerabilities. The way it works is that Amazon Inspector runs **automated security assessments** against your **infrastructure**. It helps to **check** on deviations of **security best practices**, **exposure of Amazon EC2 instances**, and **vulnerable software version installations**.

After Amazon Inspector has performed an **assessment**, it provides you with a **list** of **security findings** prioritized **by severity** level in the Amazon Inspector **console**. Each security **issue** includes a **detailed description** and a **recommendation** for how to **fix** it. You can also **retrie****v****e** findings through an **API**.

But wouldn't it be nice if we had something looking for security threats across some of the other resources in our account, too?

---

**Amazon GuardDuty**

Amazon GuardDuty provides **intelligent threat detection** across your infrastructure and resources. GuardDuty identifies threats by continuously monitoring streams of your account metadata and network activity in your environment. It uses known malicious IP addresses, anomaly detection, and machine learning to identify threats more accurately.


---

![image](../Images/Media/image%20(76).png)
[image](../Images/image%20(76).md)

---

Well, that's why we have **Amazon GuardDuty**. This service **analyzes continuous streams** of your **account metadata** and **network activity** as it looks for threats. It uses integrated **threat intelligence**, such as known **malicious IP addresses,** **anomaly detection,** and **machine learning** to **identify threats** more accurately.

You can review detailed findings about any GuardDuty detected threats in the AWS Management Console. Findings include **recommended steps for remediation**. You can also configure AWS **Lambda functions** to **perform remediation steps automatically.**

---

**Amazon Detective**

After a threat has been detected, you can use Amazon Detective to further investigate the root cause. Detective helps you analyze threats with interactive visualizations contained in a unified AWS Management Console view. These visualizations include resource and user interactions over a configurable timeline with recommended steps for remediation.


---

![image](../Images/Media/image%20(77).png)
[image](../Images/image%20(77).md)

---

After you've **detected** a security **issue**, you can use **Amazon Detective** to uncover the **root cause.** Amazon Detective streamlines the investigative process across your AWS accounts. This service **automatically collects log data** from your AWS resources and uses **machine learning** and **graph analytics** to build interactive **visualizations** of detected **issues**.

These **visualizations** provide a **unified, interactive** view of your **resource** and **user interactions** over a configurable **timeline**. These insights help you to quickly comprehend security threats so you can focus on fixing problems.

---

**AWS Security Hub**

Security Hub brings multiple security services together into a **single place and format.** With this service, you can quickly see your security and compliance state in one comprehensive view. Security Hub automatically aggregates security findings from AWS and **partner services** and organizes them into actionable, meaningful groupings called **insights**. It can a**ccelerate time to resolution (TTR)** with **automated remediation.**


---

![image](../Images/Media/image%20(78).png)
[image](../Images/image%20(78).md)

---

As you can tell, AWS provides multiple services to help keep your resources secure. But it would be really useful if we could somehow consolidate them all in one place. **AWS Security Hub** was designed for this exact purpose. With this service, you can quickly see your **AWS security** and **compliance** state in **one comprehensive view**. Security Hub **automatically** aggregates findings and organizes them into **actionable**, **meaningful groupings** called **insights**.

This helps you efficiently maintain a secure, and compliant environment.



[AWS Security Services Comparison](../Tables/AWS%20Security%20Services%20Comparison.md)

### Additional Security Resources 

#### AWS security documentation

There are lots of considerations when dealing with security on AWS. Make sure you read the documentation on securing your AWS resources because it varies from service to service.

- For general information on AWS security, identity, and compliance services, refer to [Security, Identity, and Compliance on AWS(opens in a new tab)](https://aws.amazon.com/products/security/).

- To find answers to questions, troubleshoot issues, and learn more about AWS security services, refer to the [Knowledge Center(opens in a new tab)](https://repost.aws/search/content?globalSearch=security).

- To search through documentation by product category, refer to [AWS Security Documentation(opens in a new tab)](https://docs.aws.amazon.com/security/).

- For expert insights, best practices, and updates on security-related features, refer to the [AWS Security Blog(opens in a new tab)](https://aws.amazon.com/blogs/security/).

#### AWS Marketplace security resources

The AWS Marketplace provides a digital catalog where you can purchase third-party software and services that run on AWS. This includes the following types of security services.

---

**Threat detection and prevention tools**

Identify and block malicious activities.


---

**Identity and access management tools**

Control user permissions and authentication.


---

**Data protection**

**tools**

Encrypt and safeguard sensitive information.


---

**Compliance and governance tools**

Meet security regulatory requirements.


---



## Module 10 -Monitoring, Compliance and Governance in the AWS Cloud 

### Introduction to Monitoring, Compliance and Governance in the AWS Cloud 

**Monitoring your resources in the AWS Cloud**

To effectively monitor your Amazon Web Services (AWS) Cloud solutions, you will need ways to provide insights into resource utilization, identify potential issues, and facilitate proactive problem resolution.

The progression you generally want to use is as follows:

1. Securing systems 
​Protect data, systems, and infrastructure from **unauthorized access**, use, disclosure, disruption, modification, or destruction.

2. Monitoring activities 
​**Continuously** observe and analyze system activity, network traffic, and security events to detect potential threats or **anomalies**.

3. Conducting audits
​**Periodically** review and **assess** the **effectiveness of security controls** and **check** that all **requirements** are met and security policies and procedures are adhered to.

4. Ensuring compliance
​Help ensure that an organization's security practices and controls meet the requirements of relevant **regulations**, **industry standards**, and **contractual obligations.**

### Introduction to Monitoring

As the owner of the coffee shop, I want to watch what's going on throughout the day to make sure that things are running smoothly. In the coffee shop, I can see that people are getting their coffees, and things look generally fine. But I can't just sit there and watch things all day long. As the owner, I am a pretty important person. And, I would like to eventually leave and then get a **report** about how things went.

For example, I might want to know how many coffees were sold any given day. How long was the average wait time for someone when ordering a coffee? Did we run out of any inventory for anything today? Even better yet, I'd love to be **automatically alerted** if the wait times become too long.

Every business, including this coffee shop, can use **metrics** to measure how well systems and processes are running. This idea of **observing systems**, **collecting metrics**, **evaluating** those metrics over time, and then using them to make **decisions** or take **actions** is what we call **monitoring**.

It's important to set up monitoring in the cloud. AWS services can dynamically scale up and down. So, you'll want to keep a close watch on your AWS resources to ensure that your systems are running as expected.

For example, if an EC2 instance is being over-utilized, a scaling event can be triggered to automatically launch another EC2 instance using EC2 Auto Scaling. Or if an application starts sending error responses at an unusually high rate, notifications can be sent to the employees to troubleshoot the issue.

AWS monitoring tools help you **measure** how your **systems** are **performing**, **alert** you when things aren't right, and even help you **debug** and **troubleshoot issues** as they come along.

Monitoring your cloud resources is important. It provides a way for you to **continuously observe** and **analyze** system **activity, network traffic, and security events** to **detect** potential threats or **anomalies**. Monitoring and observability are critical components for ensuring the **security**, **availability**, **reliability**, and **performance** of your cloud-based workloads and data.

**Monitoring is performed using real-time monitoring tools, log collection and analysis, and dashboards.**

### Amazon CloudWatch 

In both our coffee shop and the AWS Cloud, there are so many systems to monitor. Wouldn't it be nice to have one **centralized place** to go? Yep. That's where **Amazon CloudWatch** comes in. CloudWatch makes it possible for you to monitor your **infrastructure** and the **applications** you run on AWS. It accomplishes this through **monitoring and tracking of metrics.**

**Metrics** are **variables** that are **tied** to your **resources**. For example, the number of espressos made by an espresso machine or the **CPU utilization** of an Amazon **EC2 instance.** For espresso machines, they need to be cleaned after every 1000 espressos. So, we go into CloudWatch and create a **custom metric** called Espresso Count. This tells us what the espresso count is at any given time. But after it reaches 1000, how do we let our employees know they need to clean the machine?

Well, with another CloudWatch feature called **CloudWatch alarms**. We create an alarm and then set the **threshold** for a **metric**. After the threshold is reached, the **alarm** is **triggered** and we can **add a corresponding action.**

With our Espresso Count metric, we set the threshold to 1000 and set the action to let the manager know the machine needs to be cleaned. Even better, because **CloudWatch alarms** are **integrated** with **Amazon SNS**, we can set up the action to send a **text message** to the manager directly.

We can create all sorts of custom alarms for metrics from all different types of AWS resources. But I can see you asking, “Rudy, where do I see all these metrics?” I got you, boo. You can use the **CloudWatch dashboard** feature. A dashboard, or screen, **lists out all the metrics** in **near real time.**

In our case, we create a CloudWatch dashboard that shows us all our espresso machines and their espresso counts. No need to click the refresh button on your browser either. These dashboards **auto refresh** so you can see up-to-date information with ease. But where does all the data on the dashboard get stored? And what if we want to review what happened in the coffee shop, say last week, or search for an issue on a specific machine, or even **analyze data further**?

That's where **CloudWatch logs** can help. This feature **centralizes log management** and **analysis** by **collecting**, **storing**, and **monitoring log files from AWS resources**. You can **view**, **search**, and **filter logs**, depending on what you need. In fact, it’s very useful for **filtering certain error codes** or searching for why espresso machine two started making decaf coffee last week!

Let’s wrap up by touching on the benefits of CloudWatch. The first is **centralized access** to all your **metrics** from **all** your different **sources**. That means all your AWS resources and your **on-premises servers**. No more siloed monitoring. Use a single pane of glass for **system-wide visibility**. Reduce **mean time to resolution** or **MTTR**. Improve **total cost of ownership**, or **TCO**, and much more.

In application terms, this means freeing up important resources like developers to focus on adding business value like coding the next great app. Lastly, you can drive insights to optimize applications and operational resources. For example, **aggregating usage across** an entire fleet of **EC2 instances** to derive **operational** and **utilization insights**.

---

**Amazon CloudWatch**

CloudWatch monitors your AWS resources and the applications that you run on AWS in real time. With CloudWatch, you gain system-wide visibility into resource utilization, application performance, and operational health.  CloudWatch does more than just monitor. It has several features that work together:


---

![image](../Images/Media/image%20(79).png)
[image](../Images/image%20(79).md)

---

- **CloudWatch metrics** ​CloudWatch **collects metrics** from all your AWS resources, applications, and services that run on AWS and on-premises servers.

- **CloudWatch alarms** ​With CloudWatch alarms, you can **define thresholds** on CloudWatch metrics and **send** **notifications** or **automatically** make **changes** to the **resources**.

- **CloudWatch dashboards** ​Dashboards are customizable home pages in the CloudWatch console that you can use to monitor your resources in a **single view.**

- **CloudWatch logs** ​CloudWatch Logs **centralize** the **logs** from all of the systems, applications, and AWS services that you use.

**Example:** A retail company is using CloudWatch features to **monitor** their **application** running on Amazon Elastic Compute Cloud (Amazon **EC2**) instances. CloudWatch **automatically collects metrics**, like utilization, on the EC2 instances. The company sets up CloudWatch to collect **logs** on the **application performance**. They also have **alarms** for when the Amazon **EC2** utilization gets too **high** for an extended period. They even have an **action configured** to **automate** and **scale** up the number of **EC2** instances when the alarm sounds. Finally, they create a **custom dashboard** to visualize everything all in one place. Now they can **analyze the logs** to gain **insights** on **performance** issues or application **errors**.

### AWS CloudTrail

Being able to **audit transactions** of IT events is a critical ability. In a physical datacenter there are so many places where a human can, even by accident, make changes without any record of that change getting saved.

In the AWS Cloud, that problem goes away because **every action** in AWS is an **API call.** They can be **centrally logged** and **audited** with **AWS CloudTrail.** This service is straightforward. It **logs every request made to AWS**. It doesn't matter if it's to launch an Amazon Elastic Compute Cloud, or Amazon EC2 instance, or add a row to an Amazon DynamoDB table, or change a user's permissions.

Every request gets logged in CloudTrail. It **records** exactly **who** made the request, **what** operator, and **when** the API call was sent. **Where** were they? What was their **IP address**? And what was the **response**? Did something change? And what is the new state? Or was the **request denied**?

This is great for us, and this makes an auditor's job much easier which in turn makes our job easier! CloudTrail is an **audit log** of the **AWS API calls**, so it is a **history** of **configurations** and **changes** in a **deployment**. CloudTrail even comes with features to **validate log file integrity** to **show evidence of tampering**.

Furthermore, if we are concerned an actor with **root level permissions** could still **tamper** with the CloudTrail **logs**, we can **ship** the **logs** to **another AWS accoun**t which by design has **different permissions** to further **protect** the **log integrity.**

---

**AWS CloudTrail**

CloudTrail tracks **user activity** and **API** usage in the AWS **Cloud**, **on premises,** and even with **other cloud providers**. CloudTrail provides a **detailed history** of API calls, so you can track changes and identify who made them and when. This helps you understand what actions were taken on your AWS resources.


---

![image](../Images/Media/image%20(80).png)
[image](../Images/image%20(80).md)

---

**Benefits:** CloudTrail provides auditing, security monitoring, and operational **troubleshooting**. It also helps you prove **compliance** and improve your **security** posture.

**Use cases:** It can be used for compliance and auditing, identifying security incidents, troubleshooting operational issues.

**CloudTrail events**

CloudTrail events **capture details** about **actions performed** within your AWS account, such as **API calls, console actions**, or other activities. Event history provides a viewable, **searchable**, downloadable, and immutable record of the **past 90 days** of management events in an AWS Region. There are **no** CloudTrail **charges** for viewing event history.

**CloudTrail logs**

CloudTrail monitors events and delivers those **events** as **log files** to your Amazon Simple Storage Service (Amazon **S3)** bucket. Because CloudTrail logs are securely stored, they can be used to **prove compliance** with regulations such as **Payment Card Industry** (PCI) and **Healthcare Insurance Portability and Accountability Act** (HIPAA).

**CloudTrail Insights**

CloudTrail Insights **analyzes** your normal **patterns** of API call **volume** and API **error** rates. CloudTrail Insights also generates Insights events when API call volumes and error rates **deviate** from these normal patterns. You can enable CloudTrail Insights in your trails or event data stores to **detect anomalous behavior** and **unusual activity.**

#### AWS CloudTrail vs. Amazon CloudWatch

[AWS CloudTrail vs. Amazon CloudWatch](../Tables/AWS%20CloudTrail%20vs%20Amazon%20CloudWatch.md)

### Compliance

For every industry, there are specific standards that need to be upheld, and you could be **audited** or **inspected** to ensure that you have met those standards. You rely on **documentation**, **records**, and **inspections** to **pass audits** and compliance checks as they come along.

Depending on what types of solutions you host on AWS, you will need to ensure that you are up to compliance for whatever standards and regulations your business is specifically held to. If you run software that deals with consumer data in the **European Union**, you would need to make sure that you're in compliance with **general data protection regulation** or **GDPR**. Or if you run healthcare applications in the US, you will need to **design** your **architectures** to meet **Health Insurance Portability and Accountability Act** of 1996, or **HIPAA**, compliance requirements.

Whatever your compliance need is, you'll need some tools to be able to collect documents and records. You will also need to inspect your AWS environment to check if you meet the compliance regulations that you're under.

The first thing to note is that AWS has already built out data center infrastructure and networking using industry best practices. As an AWS customer, you inherit all the best practices of AWS policies, architecture, and operational processes. AWS complies with a long list of assurance programs that you can find online. This means that segments of your compliance have already been completed, and you can focus on meeting **compliance** within your **own architectures** that you build **on top of AWS.**

The next thing to know in regard to compliance and AWS is that the AWS **Region** you choose to operate out of might help you meet **compliance regulations**. If you can only legally store data in the country that the data is from, you can choose a Region that makes sense for you, and AWS will not automatically replicate data across Regions.

You should also be very aware of the fact that **you own your data in AWS**. As shown in the AWS **Shared Responsibility Mode**l([AWS Shared Responsibility Model - SRM](../Concepts/AWS%20Shared%20Responsibility%20Model%20-%20SRM.md)), **you have complete control over the data that you store in AWS.** You can employ multiple different **encryption** mechanisms to keep your **data safe,** and that varies from service to service. You can either use the features that already exist in many services or **build** it yourself **on top of AWS**. For a lot of services though, **enabling data protection** is a **configuration setting** on the **resource**.

AWS offers multiple **whitepapers** and **documents** that you can **download** and use for **compliance reports**. One place you can **access** these documents is through a service called **AWS Artifact.** With AWS Artifact, you can gain **access** to **compliance reports** done by **third parties** who have validated a wide range of compliance standards.

Check out the **AWS Compliance Center.** It will show you **compliance-enabling services** in one place. And you can also use resources like the **AWS Risk and Security whitepaper** which contains a lot of awesome information that you can learn from.

When it comes to compliance, the good news is that the underlying infrastructure "of" the cloud is secure.

**Compliance in AWS**

Compliance refers to your cloud resources and data adhering to relevant regulations, industry standards, and internal policies regarding security and data protection. AWS helps you meet compliance goals and requirements in the following ways:

- Inheriting the latest security controls that AWS uses on its own infrastructure

- Third-party validation for thousands of global requirements

- Streamlining and automating compliance

- On-demand compliance reports

---

**AWS Artifact**

AWS Artifact is a service that provides **no-cost, on-demand access** to AWS security and **compliance reports** and select online agreements.

**Benefits:** AWS Artifact helps you **manage at scale**, save time with on-demand access to compliance reports, and deploy with more confidence.


---

![image](../Images/Media/image%20(81).png)
[image](../Images/image%20(81).md)

---

**Use cases:** It can be used to manage **select online agreements** and assess third-party security and compliance.

**AWS Artifact consists of two types:**

- AWS Artifact **agreements** and AWS Artifact **reports**.

**AWS Artifact Agreements**

Suppose that your company needs to sign an **agreement** with AWS regarding your **use** of **certain types of information throughout AWS services**. You can do this through AWS Artifact Agreements.

In AWS Artifact Agreements, you can **review**, **accept**, and **manage** **agreements** for an **individual account and for all your accounts in AWS Organizations.** **Different types of agreements** are offered to address the needs of customers who are subject to **specific regulations,** such as the Health Insurance Portability and Accountability Act (HIPAA).

**AWS Artifact Reports**

Next, suppose that a member of your company’s development team is building an application and needs more information about their responsibility for complying with certain **regulatory standards**. You can advise them to access this **information** in **AWS Artifact Reports.**

**AWS Artifact Reports** provide **compliance reports** from **third-party auditors**. These auditors have tested and verified that AWS is compliant with a variety of global, regional, and industry-specific security standards and regulations. **AWS Artifact Reports remains up to date** with the latest reports released. You can provide the AWS audit artifacts to your auditors or regulators as **evidence** of AWS **security controls**.

To learn more about AWS compliance programs, visit [AWS Compliance Programs.](https://aws.amazon.com/compliance/programs/)

#### AWS Compliance

The [AWS Compliance portal(opens in a new tab)](https://aws.amazon.com/compliance/) contains resources to help you learn more about AWS compliance. You can read **customer compliance stories** to **discover how companies in regulated industries have solved various compliance, governance, and audit challenges.**

You can also access compliance **whitepapers** and **documentation** on topics such as the following:

- AWS answers to key compliance **questions**

- An overview of AWS **risk** and compliance

- An **auditing security checklist**

For essentials and best practices, guides, and workbooks, including training, visit [Additional compliance resources(opens in a new tab)](https://aws.amazon.com/compliance/resources/).

### Auditing AWS Resources for Compliance 

You might be wondering how you know if the resources and architectures you create are in compliance with your own company standards.

Your **organization** will likely have **rules** you want your **architectures** to adhere to including specific **configuration guidelines** for different AWS resources. You're going to want a way to assess and **audit the resources you create** on AWS to ensure that they meet these rules. That's where **AWS Config** comes in.

---

**AWS Config**

AWS Config is a service that you can use to assess, audit, and evaluate the **configurations** of your AWS resources.

**Benefits:** AWS Config helps evaluate configurations against a **desired state**, manage resource configuration changes, and simplify troubleshooting and remediation.

**Use cases:** It can be used to continually audit security monitoring and analysis and to streamline operational troubleshooting and change management.


---

![image](../Images/Media/image%20(82).png)
[image](../Images/image%20(82).md)

---

**AWS Config** is a service that **monitors** and **records** AWS **resource configurations** and **evaluates** them against the **configurations you want to implement**. It helps you **assess**, **audit**, and **evaluate** your **resources** so your solutions can be in **compliance** with **internal policies** and **regulations**.

**Config continuously tracks changes** to your AWS resources. You can create **rules** that **define** your **compliance standards**, and then **Config** will **automatically evaluate** if your **resources** meet those **standards**. You can receive **notifications** when **Config identifies** any **noncompliant** resources, and you can even set up **automated remediation actions** to get your resources **back into compliance.**

You can also **generate reports** showing which resources are **compliant** and which ones are not. After all, compliance **isn't** something you do **once** and you're done. It's an **ongoing** thing. With **Config**, you can **monitor** your **configurations** to ensure that they **don't change over time.**

Sounds like you'd be all set, right? Well, not so fast. If you’re in an industry that requires high levels of compliance, it's not enough to be compliant. You must be able to **provide evidence** that you meet the **standards** and **regulations**.

---

**AWS Audit Manager**

Audit Manager is a service that **continually audits** your AWS usage to simplify risk and compliance assessment. It helps collect evidence and manage audit data.

**Benefits:** Audit Manager saves time with automated evidence collection, streamlines collaboration across teams, and helps ensure integrity of audits with read-only permissions.


---

![image](../Images/Media/image%20(83).png)
[image](../Images/image%20(83).md)

---

**Use case:** It can be used to automate evidence collection, continually audit to assess compliance, and deploy internal risk assessments.

So, for example, a healthcare company might need to provide evidence that patient data is kept private and secure. Or, a financial firm might need to provide evidence to regulators that it’s handling money safely and correctly.  That's where you can use **AWS Audit Manager**, a **fully managed** service that **automates evidence collection** to reduce the manual effort of several cross-functional teams that audit activities often require.

You can assess if your policies, procedures, and activities, also called **controls**, are operating **effectively**. And it helps you manage **stakeholder reviews** of your controls as well as provides information for building **audit-ready reports** with less manual effort.

As you can see, **Audit** **Manager** has **pre-built frameworks** that cover a range of compliance standards and **maps your AWS resources** to the **requirements** for i**ndustry standards and regulations.**

#### AWS Audit Manager vs. AWS Config Comparison

**How They Work Together**

1. **AWS Config** acts as your environment's **"flight recorder,"** continuously tracking every change and evaluating compliance against defined rules (e.g., "All S3 buckets must be encrypted").

2. **AWS Audit Manager** takes the **compliance results** (the "Non-compliant" findings) from AWS Config and automatically transforms them into **formal, human-readable evidence** that can be easily packaged into an **audit report** for an auditor.

| **Feature**            | **AWS Config**                                                                                                             | **AWS Audit Manager**                                                                            |
| :--------------------- | :------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------- |
| **Primary Goal**       | **Continuous Governance & Tracking.** Record and assess the configuration state of resources.                              | **Automated Audit Evidence Collection.** Simplify the preparation for formal external audits.    |
| **Core Functionality** | **Resource Change Tracking** and **Compliance Assessment** via rules.                                                      | **Evidence Aggregation** and **Report Generation** using prebuilt frameworks.                    |
| **Key Question**       | *"Is my EC2 instance compliant with Rule X* ***right now****?"* and *"What did this security group look like last month?"* | *"How can I* ***prove*** *to my external auditor that I followed SOC 2 standards last quarter?"* |
| **Data Type**          | **Configuration Items (CIs)**, **Configuration History**, and **Rule Compliance Status** (Compliant/Non-compliant).        | **Audit-ready Evidence** (converted CloudTrail logs, Config findings, Security Hub data, etc.)   |
| **Typical Audience**   | Cloud Engineers, Security Analysts, Governance Teams (daily operational use).                                              | Internal Audit Teams, Compliance Officers, and External Auditors.                                |
| **Cost Basis**         | Billed per **Configuration Item** recorded and per **Rule Evaluation**.                                                    | Billed per **Assessor Resource** (the AWS services included in the scope of the assessment).     |

### AWS Organization 

With your first foray into the AWS Cloud, you will most likely start with a single AWS account. This is great if you are experimenting with AWS and moving test workloads. However, as your company’s AWS footprint matures, you will start to create more and more separate AWS Accounts.

These accounts will all have specialized purposes like production and non-production, or an account just for your developers, and another just for your infrastructure team. These accounts could also limit access to certain AWS Services and have other customizations that are not shared across all accounts.

---

**AWS Organizations**

Organizations helps you **centrally** manage and govern your environment as you grow and scale your AWS resources. It helps you manage policies for groups of accounts and **automate account creation.**


---

![image](../Images/Media/image%20(84).png)
[image](../Images/image%20(84).md)

---

**Benefits:** Organizations provides several benefits like quickly **scaling your environment by programmatically creating new AWS accounts** for **resources** and **teams**. It also helps by simplifying permission management through **SCPs** and managing and optimizing costs across your AWS accounts and resources.

**Use cases:** It can be used for automating AWS account creation, providing tools and access for your security teams, controlling user access to designated services, and sharing common resources across accounts.

Moreover, you need a way to **manage** your **accounts** since doing it manually is not ideal. This is where **AWS Organizations** can help. Organizations is an **account management service** that allows for the **consolidation** and **central management of multiple AWS accounts** within an organization. It allows you to manage **billing**, **access**, **compliance**, and **security** as well as **share resources across accounts.**

![image](../Images/Media/image%20(85).png)
[image](../Images/image%20(85).md)

You designate a main, or **parent account**, and all other accounts are secondary, or **children**, to that main account. Billing is consolidated into the primary account. So, all the bills for the children accounts roll up to the parent account. Then, **discounts** are applied at the **top level**.

Another feature is **hierarchical account groupings** to meet security, compliance, or budgetary needs. For example, you can group all the accounts into **organizational units** or **OUs**. So, if you have accounts that must access only the services that meet certain regulatory requirements, you can put those accounts into one, single OU.

Or if, say, you have accounts that fall under the developer OU**,** you can **group them** accordingly. As an admin of the primary account of an organization, you even have control over the **AWS services** and A**PI actions** that each account can access.

You can even use **service control policies**, or **SCPs**, to specify the **maximum permissions** for member accounts in the organization. In essence, with SCPs you can control which services, resources, and individual API actions, the **users** and **roles** in each member account **can access**.

So, consider using Organizations, sooner rather than later, so you don’t end up with ghost AWS accounts. After all, nobody wants ghosts running around. That’s spooky.

In AWS Organizations, you can apply **SCPs** to the organization root, an **individual member account,** or an **OU**. An SCP affects all IAM users, groups, and roles within an account, including the AWS account root user.

You can apply IAM policies to IAM users, groups, or roles. You cannot apply an IAM policy to the AWS account root user.



### Governance 

Imagine you're the mayor of a rapidly growing city: Cloud Town. As your city expands, you need a way to oversee all the new buildings, roads, and services while making sure everything follows the city's rules. You want to empower your builders to act autonomously, but you need to ensure **governance**.

**Governance** is the **framework** that makes it so **all the work of building and operating your deployment is efficient and supports the overall goals**. In Cloud Town, we might want a zoning code limiting the height of buildings because we know we're building an airport later.

You might want to enforce that all **resources** are **tagged** with the **department** that **creates** them for simple **cost tracking**. How can you do this if every AWS account's root user can in theory do whatever they want?

---

**AWS Control Tower**

AWS Control Tower is a service you can use to **enforce** and manage governance rules for security, operations, and compliance at scale across all your organizations and accounts in the AWS Cloud.


---

![image](../Images/Media/image%20(86).png)
[image](../Images/image%20(86).md)

---

**Benefits:** AWS Control Tower can help you **save time** while providing **governance**. It uses **preconfigured controls**, which can help you to quickly set up multi-account environments, **automation with built-in governance**, and **integration** of **third-party software at scale.**

**Use cases:** Use AWS Control Tower to quickly deploy applications and provision compliant AWS accounts.

With multiple accounts, that's where **AWS Control Tower** can help. It’s like a **high-tech control center** for your cloud city, helping you **govern**, **manage**, and **organize** your AWS **environment** as it grows. AWS Control Tower is especially helpful because the more people you have building in the cloud, the more complex and time-consuming set up and governance can be.

You need **everyone** creating new accounts and spinning up AWS resources to **follow** the **rules**. You can provision new AWS accounts, and you have peace of mind knowing your **accounts conform** to your **company-wide policies.** It helps you **standardize initial account setup according to best practices.**

Let's look at how it works. First, **Control Tower** makes it possible for you to **automate setu**p using established **blueprints** for configuring your AWS environment with federated access management and account provisioning workflows.

Next is applying **guardrails**. These are like the **safety barriers** on a highway. They help prevent accidents by **automatically enforcing rules** and best practices across your **AWS environment.**

You can apply **security** and **compliance policies** using established **guardrails** to prevent resources from being deployed that don’t conform to policies. Plus, you can **detect** and **remediate noncompliant accounts** and **resources** as your team provisions them.

**Guardrails (Controls):** A mix of **Preventive** (using SCPs) and **Detective** (using AWS Config rules) policies for continuous compliance monitoring.

Finally, you can **monitor compliance**. Control Tower provides a **visual summary** of your **AWS environmen**t through a **dashboard** that you can use to observe your **accounts**, **guardrails**, and **compliance status** all in one place.

With Control Tower, you can save time and have greater control over your AWS environment so you can govern your workloads more efficiently while making sure they also conform to your company-wide policies.

So, whether you’re starting out on your journey to AWS, building a new AWS environment, or launching a new cloud initiative, Control Tower will help you with governance and best practices built-in to make sure you’re successful.

**Governance in the AWS Cloud**

- **AWS Control Tower**

- **AWS Service Catalog**

- **AWS License Manager**

**Landing zone**

A landing zone is a well-architected **multi-account environment** that's based on security and **compliance best practices**. It's the enterprise-wide container that holds all of the organizational units (OUs), accounts, users, and resources you want to regulate for compliance.

Managing **employee requests** for new AWS services or **resources** can be time consuming, but you also **don't** want **everyone guessing which type** of services and settings should be used. That's where **Service Catalog** can help.

A Landing Zone includes **foundational elements** like:

- A multi-account structure (e.g., separate accounts for Logging, Security, and Development).

- Pre-configured security best practices (e.g., centralized logging via CloudTrail).

- Identity and access management ready to go.

---

#### **AWS Service Catalog**

With Service Catalog, you can **create**, **share**, and **organize** from a **curated catalog of AWS resources**. You can **deploy baseline networking resources** and **security** tools for **new AWS accounts** so you can **govern consistently**.


---

![image](../Images/Media/image%20(87).png)
[image](../Images/image%20(87).md)

---

**Benefits:** Service Catalog saves **time** by making it **quick** to **find and deploy approved, self-service cloud resources**. It also helps you stay **agile** while improving **governance** over **resources across multiple accounts.**

![image](../Images/Media/image%20(88).png)
[image](../Images/image%20(88).md)

**Use cases:** Use it to provision resources across AWS accounts, apply access controls, and accelerate provisioning of **continuous integration and continuous delivery** (CI/CD) **pipelines**.

[Access Controls + CI/CD](../Concepts/Access%20Controls%20+%20CICD.md)

---

When companies move from on premises to the cloud, they must decide how to handle their software licenses. With **AWS Bring Your Own License** model (**BYOL**), they can use existing **software licenses purchased** directly from vendors, such as Microsoft, on AWS services like **Amazon EC2 Dedicated Hosts** and Amazon **WorkSpaces**. This can result in significant **cost savings** compared to purchasing licenses directly from AWS. By using **BYOL** with **existing licenses** in a cloud environment, you get flexibility and potential optimized costs. The service that helps you **manage** and **govern** your software **licenses** is **AWS License Manager.**

---

**AWS License Manager**

License Manager is a service that helps you manage your software licenses and **fine-tune your licensing costs.**

**Benefits:** License Manager helps with **visibility** and **control**, **tracking** and **managing** licenses, and reducing the **risk** of **noncompliance** with licenses.


---

![image](../Images/Media/image%20(89).png)
[image](../Images/image%20(89).md)

---

**Use cases:** Use it to streamline license management and to simplify the **Microsoft License Mobility** through Software Assurance experience. You can also use it to **automate** the **distribution and activation of software entitlements** across AWS accounts for end users.

- **Simpler explanation:**

    - **"Streamline license management"**

        - **Simple Meaning:** Keeping track of what you own.

        - It helps you maintain a perfect, digital count of all the software licenses your company owns and uses. This prevents your company from accidentally buying too many licenses (wasting money) or using too few (breaking the software company's rules).

    - **"Simplify the Microsoft License Mobility through Software Assurance experience"**

        - **Simple Meaning:** Moving licenses you already own to the cloud legally.

        - This is about saving money on specific Microsoft licenses. If your company already paid for expensive Microsoft software for your old office servers, License Manager handles the tricky rules that let you legally move and use those *existing* licenses on AWS cloud servers.

    - **"Automate the distribution and activation of software entitlements across AWS accounts for end users"**

        - **Simple Meaning:** Giving employees access instantly and automatically.

        - When an employee needs a specific piece of software (the "entitlement"), this service automatically sets up the permission for them to use it across all the different AWS accounts your company might have. IT doesn't have to manually install or activate the software on every new machine.



### AWS Health 

**Health of your AWS Cloud resources**

**Notifications on service events**

AWS Health is the go-to **data source** for **events** and **changes** affecting the health of your AWS Cloud resources. It **notifies you** about service **events**, **planned changes**, and **account notifications** to help you manage and take actions.

---

#### **AWS Health Dashboard**

With AWS Health Dashboard, you can view **account-specific health information** and get AWS Health event **updates**. You can also use AWS Health **programmatically** using the **AWS Health API,** which is available with **AWS Premium Support.**


---

![image](../Images/Media/image%20(90).png)
[image](../Images/image%20(90).md)

---

**Benefits:** AWS Health Dashboard provides valuable information as a **data source** for **events** and **changes**. It gives you timely and **actionable guidance** to remedy **issues**. It also helps manage service health and is integrated and **automated** to use at scale.

**Use cases:** Use AWS Health Dashboard to view account-specific health information. You can also use it to **plan for lifecycle events** or troubleshoot an **incident**.

*Example:* If AWS Health reports a service degradation affecting a database instance, EventBridge can automatically trigger a Lambda function to failover the database to a healthy Availability Zone (AZ) or notify your support team.

Use **CloudWatch** to monitor your performance and **CloudTrail** for security/auditing. Use **AWS Health** to monitor the health of the platform *underneath* your resources.

[AWS Health vs CloudWatch vs CloudTrail](../Tables/AWS%20Health%20vs%20CloudWatch%20vs%20CloudTrail.md)

### AWS Trusted Advisor

When running a business, you might need some advisors who can come in from the outside and say, “Hey, this process should be streamlined.” Or, “Hey, I have some good tips on how to save money on your overhead.” Or even, “Hey, I noticed I was able to waltz right in, go behind the cash register, and open the drawer without anyone noticing.”

Not good!

The point I'm trying to make is, sometimes it's nice to have someone who knows the **industry best practices,** and **knows what to look for**, come in, and tell you what you need to change to run more **efficiently**, be more **secure**, or to **lower costs.**

**Trusted Advisor**

---

Optimizing large scale cloud deployments is extremely important to do, and it's not a one-time thing. You must look for ways to **optimize** for **costs**, **performance**, **security**, and **resilience**. With **AWS Trusted Advisor**, you can **continuously evaluate** your AWS environment by using best practice checks across several categories. All AWS Support plans include access to dozens of Trusted Advisor checks. With Business Support and other advanced plans, you can benefit from hundreds of checks.


---

![image](../Images/Media/image%20(91).png)
[image](../Images/image%20(91).md)

---

**Benefits:** Trusted Advisor helps you align with AWS best practices, prioritize recommendations, and optimize your AWS resources at scale.

**Use cases:** It can be used to optimize cost, efficiency, security, improve performance, and track service limits.

AWS has an **automated advisor** called **AWS Trusted Advisor.** This is a service that you can use in your AWS account that will **evaluate** your **resources** against **five categories** of checks.

The checks look for areas of improvement related to 

1. **cost optimization** 

2. **performance** 

3. **security** 

4. **fault tolerance**

5. **service limits**

**Trusted Advisor** runs through a series of **checks** for each category in your account in **real time,** based on **AWS best practices**. It **compiles categorized items** for you to look into, and you can view them directly in the **AWS Management Console.**

**Some checks** are **included** in your AWS account, and others are available, **depending on the level of your support plan.** For example, if you don't have **multi-factor authentication** turned on for your root user, it's going to **let you know.** It also lets you know if you have **underutilized EC2 instances** that might be able to be **turned off to lower costs**. Another example, is if you have **EBS volumes** that **haven't been backed up in a while**. To get a better idea, let's look at AWS Trusted Advisor in my own account.

Here I am in the **Trusted Advisor dashboard** and I'm going to choose Cost Optimization first to view what it has found.  You can see that we have red here, which means action recommended, orange, which means investigation recommended, and green, which means that there were no problems detected.

Lucky for me, I don't have any critical items for Cost Optimization. However, I can go through and read more about each check that Trusted Advisor ran. For example, there is a **check** that **looks** to see if there are any **RDS instances** that are idlein this account. And here is another example of a check that **evaluates ELB utilization**. And then here is another one that checks for **EBS utilization.** If I had resources in this account that got **flagged** with these checks, I could decide to scale these resources down to save on cost. Or, if they aren't being used at all, I could decide to delete them.

Now, let's move on to **Performance**. There are no action recommended or investigation recommended items, but we can **review** some of the **checks** that Trusted Advisor performed. Scrolling down, I can **type** in **EBS**, and there is this one here that checks for EBS volumes whose **performance** might have been **affected** by the **throughput capability of the EC2 instance** that it's **attached** to.

Next up, let’s check out **Security**. In this demo account, you can see there are two alerts that are at the **action recommended level.** There are some **security groups allowing public access to EC2 instances**, which is putting those resources at **risk**, and this should be **resolved**.

Now let's move on to **Fault tolerance.** For this, there were a few things that are **found** to be **insufficient**. First, Trusted Advisor is telling me that there are **EBS volumes without snapshots** in this account. Remember, a snapshot is a **backup**. So, without backups, if I had an EBS volume fail, I would lose that data.

Another alert we have here is that my **EC2 AZ balance** is at the **action recommended level**. This means that my **EC2 workload** is **not** properly **launched across AZs**. So, if one AZ or instance has trouble, my application might have a **disruption**. **Deploying across AZs** would be the answer to this one.

And then lastly, we have one for Amazon **S3** Bucket **Logging**. And this is checking to see if **logging** is **enabled properly** for my **S3 buckets**, which I have some buckets in this account that do not have proper logging.

Finally, let's go ahead and move onto **Service limits**. Service limits tell you when you are **approaching** or hitting any **AWS service li**mits. A lot of these are **soft limits,** meaning they are **restrictions** tha**t can be lifted to some degree.** It's good to know when you are approaching one of those limits, and when it's time to use the **Service Quota console**, which you can use to **request** a **change to these limits.** There is nothing to report for this specific account on that front.

Overall, you can see how **Trusted Advisor** can help **point you in the right direction.** You can set up email alerts that go out to billing, operations, and security contacts, as checks are run in your account. Make sure you have Trusted Advisor turned on so that you, too, can start taking action to optimize your AWS account.

Although Trusted Advisor does check to optimize security, you might need help to check the fine-grained permissions of your AWS Identity and Access Management (IAM). IAM Access Analyzer can help meet your goals for least privilege access within your AWS environment.

---

#### IAM Access Analyzer

**IAM Access Analyzer** provides capabilities to **set**, **verify**, and **refine permissions** by **analyzing external access** and **validating** that your **policies match your corporate security standards.**

**Benefits:** IAM Access Analyzer provides benefits like refining permissions, **validating IAM policies,** helping you meet your **least privilege goals**, and **automating** IAM policy **reviews**.


---

![image](../Images/Media/image%20(92).png)
[image](../Images/image%20(92).md)

---

**Use cases:** It can be used to set fine-grained permissions, verify who can access what, remediate **unused access,** and **refine and remove broad access.**





## Module 11 - Pricing and Support 

### Introduction to Pricing and Support 

We've covered a lot at this point. Now it’s time to talk about pricing and support.

Just like how we have monthly bills that we need to track and manage for the coffee shop, you'll have to manage costs and understand pricing for your AWS resources. In this section, we'll dive into key pricing concepts, helping you understand how AWS charges for its services. Then, you'll learn more about how you can use services and features like the **AWS Billing Dashboard**, **AWS Budgets,** and **AWS Cost Explore**r to help you track your AWS **spending**, **set budgets**, and **forecast** future **costs**.

Now, in our coffee shop, what happens when the espresso machine isn't functioning like we'd expect or if we have a question about our lease? We would want reliable support, right? We'd reach out to the equipment provider and locate their resources to troubleshoot whatever issue or question we might have. Well, when it comes to your AWS resources, you have a lot of options for support. In this section, we'll also examine **support plans** and resources, and you can find which level of support is right for your business.

And just like we'd look for ways to reduce waste and increase efficiency in the coffee shop, AWS has some great resources for optimizing cost in the cloud. We'll finish the section by looking at some use cases that illustrate cost optimization with AWS.

### AWS Pricing Concepts

You’ve heard a little bit about AWS pricing concepts here and there. Let's unpack AWS pricing a bit more as well as talk about the main drivers of cost. Let's start with the three fundamental principles of AWS pricing.

**Pay as you go**

With pay as you go, you can adapt to changing business needs and reduce the risk of overprovisioning or missing capacity.

First, a concept you’re familiar with: **pay as you go.** With this model, you only pay for the resources you actually **consume**, without any **upfront** costs or **long-term commitments**. It's perfect for **variable workloads** or when you're unsure about your exact needs.

**Save when you commit**

For certain services, such as Compute services on AWS, Savings Plans offer savings over On-Demand prices when you commit to a 1-year or 3-year plan.

The next key concept is that you **save** when you **commit**. By committing to a **certain level of usage** for a certain **period of time,** usually **1 or 3 years,** you can receive pretty significant discounts. This is ideal for **steady-state workloads.**

**Pay less by using more**

With AWS, you can realize important savings as your usage increases. For some services, pricing is tiered, meaning the more you use, the less you pay.

The third concept is that you pay less by using more. I know, this one sounds kind of similar to save when you commit. Here’s what we mean—we are talking about **volume-based discounts**. As your usage of AWS services increases, you can benefit from **economies of scale**, resulting in **lower per-unit costs.**

OK, so now you have the fundamental concepts down. You know the how, so let’s discuss the what— what are the **primary drivers of cost** at AWS? Well, the technical answer is that it depends. Every AWS service bills differently, so you’ll want to check the **pricing page** of each service to know the full details and associated costs. That said, there are pretty much **three main drivers** when it comes to AWS pricing: **compute**, **storage**, and **outbound data transfer.**

**Compute** cost includes services like **EC2**, **Lambda**, and **ECS**, when you're charged based on the **processing power** and **time used.** Storage includes services like **S3** and EBS, and pricing is based on the **amount** of **data stored** and for **how long**. And then we have **outbound data transfer**. One example for this, is if we host a static website in S3, anytime someone a**ccesses objects** from that bucket that data is being **transferred** out of AWS and would **incur charges.**

Now, there is nuance to this. Each service has different considerations, so ensure you are reading the documentation so that you fully understand how billing works.

**Driving factors of cost**

The pricing of AWS services varies based on several factors, such as service category or type, configuration, **AWS Region,** and which **pricing model** you choose. Refer to the pricing tab on a service's webpage for details on its specific pricing factors.

**Compute**

For compute resources, you pay by a certain span of time, like by the hour or by the second. Unless you've made a reservation for which the cost is agreed upon beforehand, you pay from the time you launch a resource until the time you stop the instance.

**Storage**

You can choose from a broad portfolio of storage solutions with deep functionality for storing, accessing, protecting, and **analyzing** data. Pricing for storage largely depends on how much storage you have provisioned or how much you are using.

For some storage options, such as Amazon Simple Storage Service (Amazon S3), storage cost is **tiered**. This means you can **optimize storage costs** based on how **frequently** and **quickly** you need to **access** data. With Amazon S3, consider the following **six cost components** when storing and managing customer data:

- **Storage pricing**

- **Request and data retrieval pricing**

- **Data transfer and transfer acceleration pricing**

- **Data management and analytics pricing**

- **Replication pricing**

- **The price to process your data with Amazon S3 Object Lambda**

To learn more about Amazon S3 pricing, choose the following link and navigate through the pricing tabs: [Amazon S3 Pricing(opens in a new tab)](https://aws.amazon.com/s3/pricing/?nc=sn&loc=4).

**Data transfer**

In **most cases**, there is **no charge** for **inbound** data transfer or for **data transfer between AWS services** within the **same Region**. There are some **exceptions**, so be sure to verify data **transfer rates** before beginning. 

**Outbound data transfer** is aggregated across services and then **charged** at the **outbound data transfer rate.** The **more data** you transfer, the **less you pay per gigabyte**. For data storage and transfer, you typically pay per gigabyte.

#### **AWS pricing scenario**

Let's apply these AWS pricing concepts and drivers of cost to a possible scenario. Use Amazon Elastic Compute Cloud (Amazon **EC2**), a service in the **compute** category, as an example. 

*An AWS customer decides to provision an EC2 instance for their nonprofit organization. To learn how this customer's EC2 instance might be impacted by the driving cost factors of compute, storage, and data transfer, choose each of the numbered markers.*

**Compute:**

The organization built their own **application** that processes and manages **online donations.** There are over **500 types of EC2 instances** that they can choose from to run that application. Each type of EC2 instance has a different quantity of **CPU** and **memory**, both of which are **compute factors** of Amazon **EC2**. Based on their requirements, they chose to use***t4g.nano*** **instance**, which provides the **lowest price** while still meeting their needs.

**Storage**

The organization's donation processing application requires **storage**, so they configure their **EC2** instance with Amazon **Elastic Block Store** (Amazon **EBS)**. Price will be impacted by the **amount** of **capacity** configured.

**Data transfer**

The organization's donation processing application will **transfer data** from their **EC2** instance to another solution to run **analytics**. This transfer would be considered **outbound** data transfer. Price will be impacted by **capacity** and **which internet source** or AWS **Region** the data is being transferred to.

For the chart associated with the cost of data transfer out, navigate to the following webpage and scroll to "Data Transfer": [Data transfer on Amazon EC2(opens in a new tab)](https://aws.amazon.com/ec2/pricing/on-demand/).

### AWS Pricing and Billing Services

OK, now that pricing concepts are fresh in your mind, let’s talk about billing options for AWS accounts: **single** or **consolidated**. With a **single** account, it’s all encompassed in that one account. Use AWS services. Deploy workloads. Receive a bill for what you use. **Rinse** and **repeat every month**.

For **consolidated** account billing, it’s ever so slightly more complex. With this approach, you use **multiple AWS accounts**. One is a **primary** and the others are **subaccounts** linked to the primary account. The subaccounts can be separated by **department**, **project**, **team**, or however you see fit. The important part is that when your AWS **bill arrives**, it is only sent to the **primary account**. All other account bills are **consolidated** into that **primary account**. In addition to consolidated billing, the **primary account owner** gets a clear view of your **entire organization’s AWS spend.**

And I use the word organization specifically because, yep, you guessed it: You can use **AWS Organizations** to set it all up. With **Organizations** and **consolidated billing,** you can take advantage of some great benefits, like **centralized management, discounts, and improved security**.

OK, with that out the way, it’s demo time! The first service that can help with billing is the **AWS Billing Dashboard**. It gives you an **overview** of your **forecasted spend** for the **month**, and a breakdown of your **most-consumed services** by **cost**. It's a great starting point for understanding your expenses. But what if you want to budget and plan things out ahead of time?

![image](../Images/Media/image%20(93).png)
[image](../Images/image%20(93).md)

Well, check out **AWS Budgets.** You can create **custom budgets** to **track** your **costs** and **usage**. You can generate budgets for specific services, cost categories, or even by tags. **Tags** are **metadata** that you can **add** to your AWS **resources**. They help you **identify resources easily and group them** together to find all related resources much quicker. For example, if we tag all our development resources with the "dev" tag, we can easily find all the related resources with one search instead of multiple. One final note on **AWS Budgets** is that you can **set up alerts.** These alerts can notify you when you're approaching or have exceeded budget **limits** that you have set.

Finally, let’s look at **AWS Cost Explorer**. It helps with **reviewing costs** and **usage over time.** You can **break down costs** by **service**, **linked account**, and again, even **tags**. For example, you might tag resources by project, department, or environment. With tag-based cost allocation in Cost Explorer, you can use these tags to organize your cost and usage information. This is incredibly useful for understanding which **projects** or **departments** are **driving** your AWS **costs**.

![image](../Images/Media/image%20(94).png)
[image](../Images/image%20(94).md)

#### **AWS pricing and billing services**

You learned about various AWS pricing and billing services and tools. These services are purpose-built to help you forecast, track, manage, and view your AWS costs. When you are first starting out with the AWS Cloud, they can be hard to tell apart. To help you differentiate the services, let's review these services and their key uses cases.

---

> **AWS Organizations**

AWS Organizations provides **centralized management and governance** of your AWS environment. Using AWS Organizations, you can create, group, and manage accounts. You can also apply security policies at the account level and consolidate billing with multiple accounts using a single payment method.


---

![image](../Images/Media/image%20(95).png)
[image](../Images/image%20(95).md)

---

Use cases:

- **Consolidate** multiple AWS accounts into one central organization.

- Implement **organization-wide policies.**

To learn more about AWS Organizations, refer to the [AWS Organizations User Guide(opens in a new tab)](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_introduction.html).

---

> **AWS Billing and Cost Management dashboard**

The AWS Billing and Cost Management dashboard **centralizes cost management,** showing **current** charges, usage, **forecasts**, and detailed **breakdowns**. It also provides **tools** to manage **payments**, view **invoices**, set **budgets**, and **consolidate billing.**


---

![image](../Images/Media/image%20(96).png)
[image](../Images/image%20(96).md)

---

Use cases:

- Use helpful **visualizations** and billing reports of monthly AWS spend.

- Set up and manage **payment methods**.

To learn more about the AWS Billing and Cost Management dashboard, refer to the [AWS Billing User Guide(opens in a new tab)](https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/view-billing-dashboard.html).

| **Feature**         | **AWS Organizations**                                      | **Billing & Cost Mgmt Dashboard**                             |
| :------------------ | :--------------------------------------------------------- | :------------------------------------------------------------ |
| **Focus**           | **Governance, Structure, and Permissions**                 | **Financial Reporting, Invoicing, and Payment**               |
| **Core Action**     | Creating and grouping accounts (OUs) and setting **SCPs**. | Viewing bills, paying invoices, setting up payment profiles.  |
| **Billing Role**    | **Enables Consolidated Billing** (The engine).             | **Displays the Consolidated Bill** (The speedometer/invoice). |
| **Data Type**       | Account IDs, Organizational Units, Policy documents.       | Dollar amounts, invoices, payment history, cost forecasts.    |
| **Key Distinction** | Manages **who can do what** at the account level.          | Manages **how much was spent** and how to pay for it.         |

---

> **AWS Budgets**

AWS Budgets helps **set custom budgets** and sends **alerts** when costs, usage, or **Savings Plans** and **Reserved Instances** (RIs) utilization or coverage exceed defined **thresholds**.


---

![image](../Images/Media/image%20(97).png)
[image](../Images/image%20(97).md)

---

Use cases:

- Set up alerts for when projected costs **exceed** predefined thresholds.

- **Forecast** future expenses based on **current usage trends.**

To learn more, refer to [Managing your costs with AWS Budgets(opens in a new tab)](https://docs.aws.amazon.com/cost-management/latest/userguide/budgets-managing-costs.html).

---

> **AWS Cost Explorer**

AWS Cost Explorer helps **visualize**, **analyze**, and manage AWS costs and usage with **interactive graphs**, **reports**, and **forecasts**. It provides **insights** into **spending patterns**, **trends**, and **Reserved Instance recommendations.**


---

![image](../Images/Media/image%20(98).png)
[image](../Images/image%20(98).md)

---

Use cases:

- **Analyze historical spending trends** to identify cost-saving opportunities.

- Forecast future AWS costs based on current usage patterns to budget effectively.

To learn more, refer to [Analyzing your costs and usage with AWS Cost Explorer(opens in a new tab)](https://docs.aws.amazon.com/cost-management/latest/userguide/ce-what-is.html).

---

> **AWS Pricing Calculator**

Another helpful tool is the AWS Pricing Calculator. The AWS Pricing Calculator is a **web-based planning tool** that you can use to create **estimates**. You input specific **configurations** such as instance types, storage options, and data transfer volumes. Then, based on your configurations, you receive a **detailed cost breakdown** to help you budget for your AWS resource allocation.


---

![image](../Images/Media/image%20(99).png)
[image](../Images/image%20(99).md)

---

Use cases:

- **Estimate potential costs before deployment.**

- **Compare costs of different AWS services and configurations.**

To learn more, refer to [Generating estimates with AWS Pricing Calculator(opens in a new tab)](https://docs.aws.amazon.com/cost-management/latest/userguide/pricing-calculator.html).

#### AWS Cost and Governance Services Comparison

[AWS Cost and Governance Services Comparison](../Tables/AWS%20Cost%20and%20Governance%20Services%20Comparison.md)

### AWS Support Plan

One of the great things about AWS is no matter how big or small your business is, you are never alone. From small start-ups to large enterprises, private sector and public, all businesses have support options available that are designed to fit your specific needs.

Let's start off with our support plan options, leading off with our first plan: **Basic Support**. Every customer automatically gets Basic Support at **no cost** at all. Any customer can access support functions like **24/7 access** to customer service, documentation, whitepapers, support forums, AWS Trusted Advisor, and the **AWS Personal Health Dashboard**. This dashboard is a personalized view of the health of AWS services and any **alerts** when your **resources might** be **impacted**. These functions are available to everyone at no cost, but as you begin to move **critical workloads** into AWS, we offer higher levels of support to match your levels of need.

The next support plan is our **Developer Support** which includes everything from the Basic Support plan. Plus, you can also **email customer support directly** about any questions you have. You can expect a **response** within **24 hours** or less than **12 hours** if your **systems** are **impaired**. This is great for businesses that are experimenting or just **getting started.**

As customers begin to take **production workloads live**, we find they often choose **Business Support.** Everything from the previous plans is included, plus **Trusted Advisor** now opens up the **entire suite of checks** for your account. You are given **direct phone access** to our **AWS Support team.** They have a **4-hour response time** if your production **system** is **impaired** and a **1-hour** **response time** for when your production **system** is **down**. Additionally, as part of the Business Support plan, we provide **access** to an **infrastructure event management team.** This means that for an **extra fee**, we can help you **plan** for **massive events like brand new launches** or **global advertising blitzes.**

Finally, for companies running **mission-critical workloads,** we recommend the **Enterprise Support.** There are two types: **Enterprise On-Ramp** and **Enterprise**. These options have everything from the previous plans, plus a **reduced response time** for business and **mission-critical workloads** and resources such a**s technical account managers**, or **TAMs**, to provide **guidance**. Your **TAM serves** as your **primary point of contact with AWS** and **proactively monitors** your **environment** and **assists with optimization.**

AWS Support looks at the customer holistically, not just if they have problems, but how we can help them be successful. There are even more teams and roles at AWS that are purpose-built to support your cloud journey.

![image](../Images/Media/image%20(100).png)
[image](../Images/image%20(100).md)

AWS offers a range of support plans tailored to meet the needs of different customers, from those just getting started to large enterprises with complex requirements. Each plan builds onto the previous one, adding more advanced tools, personalized support, and faster response times to help you get the most out of your AWS experience. To learn more about which plan is right for you, refer to [Compare AWS Support Plans(opens in a new tab)](https://aws.amazon.com/premiumsupport/plans/).



[AWS Support Plans comparison table](../Tables/AWS%20Support%20Plans%20comparison%20table.md)

A **technical account manager (TAM)** is included with the Enterprise On-Ramp and Enterprise Support plans. The TAM serves as your primary AWS contact, offering expert guidance on using AWS services, optimizing architectures, managing costs, and connecting you with AWS programs and experts. For example, if you're building an app using multiple AWS services, your TAM can advise on the best integration approach.

#### Additional resources for your cloud journey

**AWS re:Post**

AWS re:Post is a community-driven, question-and-answer platform where users can seek help, share knowledge, and find solutions related to AWS services and technologies.

AWS re:Post also houses AWS Knowledge Center. AWS Knowledge Center contains articles and videos covering the most frequently asked questions and requests from AWS customers. To learn more about AWS re:Post, refer to [AWS re:Post.(opens in a new tab)](https://repost.aws/) To learn more about AWS Knowledge Center, refer to [AWS Knowledge Center(opens in a new tab)](https://repost.aws/knowledge-center).

**AWS Trust and Safety Center**

The AWS Trust and Safety Center provides information on how to report activity or content on AWS that you suspect is abusive. To learn more about this service, refer to [AWS Trust and Safety Center(opens in a new tab)](https://repost.aws/aws-trust-and-safety).

**AWS Solutions Architects**

For Business and Enterprise Support customers, AWS solutions architects (SAs) provide architectural guidance, best practice recommendations, and help in designing scalable and secure applications.

**AWS Professional Services**

AWS Professional Services is a consulting service that offers deeper, project-based support. They help with complex migrations, security audits, performance tuning, and more. To learn more about this service, refer to [AWS Professional Services(opens in a new tab)](https://aws.amazon.com/professional-services/).

AWS Professional Services offers deep technical expertise and can assist with security audits, best practices, and strategic guidance tailored to specific needs.

**Self-support at AWS**

AWS also provides extensive documentation and self-support resources that you can use to research, answer a question, or troubleshoot an issue. Documentation includes user guides for AWS services, SDK guides, blog posts, and whitepapers for specific solutions.

To learn more about these resources, refer to [AWS documentation(opens in a new tab)](https://docs.aws.amazon.com/index.html).

### AWS Marketplace and AWS Partners 

In addition to the AWS Support options you've already covered, you also have the benefit of the AWS Marketplace. The **AWS Marketplace** is a **curated digital catalog** that you can use to **find**, **test**, **buy**, **deploy**, and **manage third-party software running in your AWS architecture.** This can help you **reduce the total cost of ownership** and **accelerate innovation** by **not spending development time recreating things that already exist.**

So, what are some of the key services included? Well, you'll see lots of **software** from independent software vendors, or **ISVs**, across a wide range of categories. Security, networking, storage, machine learning...you name it, it's probably there. There are both **free** and **paid** options and flexible pricing models, such as **pay-as-you-go** and annual **subscriptions**. The AWS Marketplace can reduce complexity in the procurement process, help you quickly deploy software, scale your software, and even help you **consolidate** your **billing in your AWS account.**

Another component of the AWS support world is the **AWS Partner Network** or **APN**. This is a **global program** for **technology** and **consulting businesses** who use AWS to build solutions and services for customers. As you can tell, AWS is super interested in your success.

With all these support options and resources dedicated to helping you succeed in the cloud, what will you build next? We can't wait to see.

#### **AWS Marketplace**

---

The AWS Marketplace is a digital catalog that includes thousands of software listings from independent software vendors. You can use AWS Marketplace to find, test, and buy software that runs on AWS. For each listing in AWS Marketplace, you can access detailed information on pricing options and reviews from other AWS customers. Solutions and services offered in the AWS Marketplace include the following:


---

![image](../Images/Media/image%20(101).png)
[image](../Images/image%20(101).md)

---

- **Software as a service (SaaS):**

    - Business applications such as project management tools

    - Marketing tools such as customer engagement platforms

    - Collaboration tools such as file sharing services

- **Machine learning (ML) and AI**:

    - Prebuilt models for image recognition, natural language processing, and more

    - ML algorithms for training custom models

- **Data and analytics**:

    - Business intelligence platforms for visualization and reporting

    - Data integration tools

You can also explore software solutions by industry and use case. For example, suppose your company is in the healthcare industry. In AWS Marketplace, you can review use cases that software helps you to address, such as implementing solutions to protect patient records or using machine learning models to analyze a patient’s medical history and predict possible health risks.

To explore more offerings and find the right fit for your business, refer to [AWS Marketplace(opens in a new tab)](https://aws.amazon.com/marketplace).

#### **AWS Partner Network**

The AWS Partner Network (APN) is a global community that uses AWS technologies, programs, expertise, and tools to build solutions and services for customers. Together, partners and AWS provide innovative solutions, solve technical challenges, and deliver customer value.

You can work with AWS Partners to create or use **specialized solutions** that are tailored to your unique business needs. For example, a retail company might use AWS to host their website. They could then work with an AWS Partner who specializes in advanced analytics and machine learning to improve customer personalization on that website. To learn more about working with AWS Partners, refer to [Engage with AWS Partners(opens in a new tab)](https://partners.amazonaws.com/).

You can also become an AWS Partner. There are many benefits to becoming a partner, including the following:

- **Funding benefits:** As businesses join the AWS Partner Network and participate in specific programs available to AWS Partners, they can unlock various **funding benefits** to help build, market, and sell with AWS. To learn more, refer to [AWS Partner Funding(opens in a new tab)](https://aws.amazon.com/partners/funding/).

- **AWS Partner events:** AWS Partner events include **webinars**, **virtual workshops,** and **in-person learning opportunities**. You can use AWS Partner **events** to **network** with other partners, learn more about new or current offerings, and collaborate with AWS experts. To learn more, refer to [AWS Partner Events(opens in a new tab)](https://aws.amazon.com/events/aws-partner-events/). 

- **AWS Partner Training and Certification:** Take advantage of unique, partner-centered offerings from AWS Training and Certification. From certification to a specific service or learning objective, the AWS Partner training portfolio has numerous opportunities to upskill your cloud knowledge. To learn more, refer to [AWS Partner Training(opens in a new tab)](https://aws.amazon.com/partners/training/).

### Cost optimization

**Rudy:** What up, barista buds? I've got this architecture diagram I wanna talk through. We've got an app running on EC2 instances along with an RDS database in a VPC. There's also an S3 bucket. I figured the three of us could discuss some cost-optimization techniques using this diagram. But first, Alan, my man. Digging the jacket.

**Alan:** Oh, thank you. I cost-optimized my AWS account so much that I put some of my savings towards this lovely jacket.

**Alan:** Sparkly jackets aside, I like the idea of looking at **cost optimization across multiple services that are working together.** I mean, that really is how AWS usually works...multiple services working together to form a unique solution. So, let's start with **EC2** since that's often a place where people are looking to save.

**Morgan:** Good idea. I don’t know about you two, but the first thing that comes to mind for me for cost optimization in **EC2** is **rightsizing**. Rightsizing is basically making sure that you are **analyzing** and **adjusting** your **resources** to **match** the **needs** of your **workload**. I heard of a customer just last week who saved a ton by using the service **AWS Compute Optimizer** to **identify overprovisioned instances**.

![image](../Images/Media/image%20(102).png)
[image](../Images/image%20(102).md)

**Rudy:** Oh that, that’s awesome. And Optimizer is like having a **cost-conscious** sidekick who’s always got your back. It'll help you make sure you **aren't overprovisioning compute**.

Alan: Definitely. And don't forget about the option to use **Spot Instances**. I've seen companies cut their compute costs in half by using Spot Instances for their **noncritical workloads.**

**Rudy:** That’s so cool! And it makes complete sense ‘cause Spot Instances are available at up to a **90 percent discount** compared to **On-Demand Instance prices**. As a reminder, Spot Instances are unused EC2 capacity in the AWS Cloud. They are fantastic for **flexible workloads** that can be started and stopped easily.

**Morgan:** And, you know, **auto scaling** is another big factor of how customers can think about **cost** optimization. If you are manually managing your Amazon EC2 fleet, auto scaling can really save you time and money. Speaking of manual management, I always remind people to **clean up after themselves in your AWS account.** I’m sure you both have seen it, too. That sometimes, unused resources, **Amazon EBS volumes**, and **snapshots** hang around, and customers are **unaware** that these unused resources are **quietly draining the budget.**

**Alan:** That's a really good point. Now, what about **RDS**? Are there any thoughts there?

Rudy: Well, I like that you brought up **rightsizing**, Morgan. ‘Cause it applies to **RDS** as well. No need to overprovision or underprovision. Just spin up RDS, **and it scales up and down** based on actual **demand**.

**Morgan:** True, and for **high-read workloads,** **read replicas** or **caching** can really help performance without breaking the bank.

**Alan:** Can you speak a little bit more about **read replicas** and caching can help somebody with cost optimization?

**Morgan:** Yeah, absolutely. So, I’m just thinking that RDS read replicas provide the capability to **scale read traffic horizontally**. This helps **spread** out your **read capacity instead** of unnecessarily **upgrading your primary instance** to a larger, more expensive instance. Or by storing frequently accessed data in a cache, like Amazon **ElastiCache**, you can also **reduce the load** on your primary instance.

**Alan:** That’s a great callout. Now, Rudy, I know you mentioned that Amazon **S3** is a part of this architecture, too. When thinking about cost **efficiency** with S3, I always emphasize **storage classes**. **S3 Intelligent-Tiering** is good for **data** with unknown or **changing patterns.**

**Rudy:** Oh, definitely. And customers should also consider **compressing their data** to save on **S3** storage costs, especially for **text-heavy data**. As objects are **uploaded** to **S3**, you can **configure** a **Lambda function to automatically compress them.** Even better, use **lifecycle policies** to **delete old versions** of objects. Actually, I had a customer who was paying for 10 years of daily backups when they only needed 30 days! Ten years compared to 30 days, seriously. You can imagine how happy they were when their AWS spend dropped like that.

**Alan:** Wow, that is impressive. Another thing I wanted to mention is that you can look into **architecting** your **applications** to **minimize inter-Availability Zone traffic and traffic to the internet.** It's important to remember **data transfer isn't always free.**

**Morgan:** Yeah, that's such a good point. Also, we didn’t get to talk too much about **VPC endpoints** in our **networking section,** but that’s very relevant to this conversation, and it's something to look into for **cost optimization.** **VPC endpoints** are a way to **privately connect your AWS VPC to supported AWS services without using the public internet**. Using **VPC endpoints** for Amazon **S3 access**, for example, can really **cut down on data transfer costs,** especially for **out-of-Region traffic.**

**Rudy:** It's just like traffic in real life: the less the better. Also, this is what teamwork does! Look, it's amazing how several small optimizations can add up to significant savings. And, most of these optimizations not only make things more cost-effective, but can also improve **performance** and **reliability**.

**Morgan:** Yeah, I couldn't agree more. It's all about finding that sweet spot between cost, performance, and operational efficiency.



## Module 12 - Migrating to the AWS Cloud 

### Introduction to Migration

We've established how to get going on the AWS Cloud with your brand spanking new AWS account. But what if you have existing on-premises environments? Maybe you even already started your cloud journey with another cloud service provider?

That’s all good. You can always migrate those workloads to AWS if you want to. We offer lots of tools, services, solutions, and architectures to **support** your **migration** journey. You can even use our **three-phase migration process** which provides resources and guidance for each individual phase.

First is the **assess phase**. You start with assessing your organization's **current readiness** for operating in the **cloud**. Then, you identify **business outcomes, goals, and the need for migration**. In this critical step, you evaluate your findings and develop the **business case** for **migration**.

Next is the **mobilize phase.** Here, you'll create a **migration plan** and address any of the gaps in your readiness. A strong plan starts with a deep **understanding** of the **interdependencies** between **applications** in your environments. You then evaluate **migration strategies** to meet your specific **business objectives.** Two services you might use in this phase are **AWS Application Discovery Service** and the A**WS Migration Hub.** Tools to support you include **AWS Application Migration Service** and **AWS Database Migration Service (AWS DMS).** If you are **transferring data,** you might use **AWS DataSync, AWS Transfer Family, and the AWS Snow Family.**

The last phase, called **migrate and modernize**, is where you get things moving. Each **application** is **architected**, **migrated**, and **validated**. You can also take advantage of **migration specialists** and **competency partners** during this phase. Or, if you have the expertise in house, you can move things on your own. Just remember, AWS is always here to help you with this **iterative process** every step of the way.

![migration-three phases](../Images/Media/migration-three%20phases.jpg)
[migration-three phases](../Images/migration-three%20phases.md)

### AWS Cloud Adoption Framework

Luckily, a lot of knowledge about how to migrate to AWS has been captured and shared, making cloud migrations much easier for organizations. Depending on your role, you will approach cloud migrations differently. If you are a **developer**, your role and **viewpoint** will be much **different** than a **cloud architect, business analyst, or financial analyst.**

Different people bring **different perspectives** to the table for migration, and you want to harness those different perspectives and make sure everyone is on the same page. You also want to make sure that you have the right team to help support your migration. This can be a lot to keep track of, and someone new to the cloud might not think of all of the different roles who need to be involved.

**The AWS Professional Services team** has created something called the **AWS Cloud Adoption Framework, or AWS CAF**, to help you manage this process through **guidance**.  **CAF** provides **advice** to your company to enable a quick and **smooth migration** to AWS.

The framework organizes guidance into **six areas** focused on the **different people** you will need to involve for your migration. Just like the different perspectives we talked about earlier, each one covers **distinct responsibilities** covered by **different groups.** They include **Business, People, and Governance**, which focus on the **business capabilities**, and then you have the **Platform, Security, and Operations**, which focus on the **technical capabilities.**

![CAF six areas](../Images/Media/CAF%20six%20areas.jpg)
[CAF six areas](../Images/CAF%20six%20areas.md)

Someone who is a business or finance analyst would fall under the Business perspective. HR would fall under the People perspective, and a cloud architect would fall under the Platform perspective. Each perspective is used to uncover **gaps in your skills and processes** which are then recorded as **inputs**. These **inputs** are used as the basis for creating what is called an **AWS CAF Action Plan.** You can then use the plan to **guide** your **organization's change management** as you journey to the cloud. Migrating to the cloud can be complicated, but again, you're not alone in this. There are tons of resources to help you get started, and the AWS CAF is a great place to begin.

---

**AWS CAF**

The AWS Cloud Adoption Framework (CAF) is a framework that brings **AWS** experience and **best practices** to companies preparing to migrate to the AWS Cloud. The framework provides tools to help accelerate the migration journey, organize resources, and align management **during the transition.**


---

![image](../Images/Media/image%20(103).png)
[image](../Images/image%20(103).md)

---

**Benefits:** AWS CAF provides benefits for migrations to **reduce business risk** and improve sustainability and corporate transparency. Companies can grow revenue by creating new products and services in their cloud transformation. They can also reduce operational costs, increase productivity, and improve customer experience in their new cloud environment.

**Use cases:** You can use AWS CAF to migrate technology like **legacy infrastructure** and **applications**. You can also use it to migrate and optimize business processes, operations, and even create new business models with the move to the cloud.

#### Functional and business-related stakeholders

**Business**

The Business perspective makes sure that **IT aligns with business** needs and that **IT investments** link to **key business results.**

Use the Business perspective to create a strong **business case** for cloud adoption and **prioritize** cloud adoption initiatives. Make sure that your business strategies and goals align with your IT strategies and goals.

The following are common Business perspective roles:

- Business managers

- Finance managers

- Budget owners

- Strategy stakeholders

**People**

The People perspective supports development of an **organization-wide** **change management** strategy for **successful** cloud **adoption**.

Use the People perspective to evaluate organizational structures and roles, assess **new skill** and process requirements, and identify **gaps**. This helps **prioritize training, staffing, and organizational changes.**

The following are common People perspective roles:

- Human resources

- Staffing

- People managers

**Governance**

The Governance perspective focuses on skills and processes to **align IT strategy** with b**usiness strategy**. This perspective helps you **maximize business value** and minimize risks.

Use it to understand how to update the staff skills and processes necessary to maintain business governance in the cloud. Manage and **measure cloud investments** to **evaluate business outcomes**.

The following are common Governance perspective roles:

- Chief information officer (CIO)

- Program managers

- Enterprise architects

- Business analysts

- Portfolio managers

## Governance vs. Business: The Distinction

| **Perspective** | **Primary Focus**                                  | **Role in Maximizing Value**                                                                                                      | **Analogy**                                                                                                                                                          |
| :-------------- | :------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Business**    | **Defining the Strategy** and **Making the Case.** | Defines *what* success looks like and *why* the investment is being made.                                                         | **The CEO:** Sets the company goal: "We will increase market share by 20%."                                                                                          |
| **Governance**  | **Control, Alignment, and Risk Management.**       | Creates the systems to **ensure** IT investments actually deliver the defined business value while preventing expensive failures. | **The Board of Directors/CFO:** Creates policies and metrics to ensure the goal is met safely, legally, and within budget, minimizing risk of fraud or overspending. |

**Platform**

The Platform perspective includes principles and patterns(microservices) for implementing new solutions in the cloud and migrating on-premises workloads to the cloud.

In simple terms, the Platform perspective is where the technical leaders decide **how to build everything** in the cloud.

Use a **variety of architectural models** to understand and communicate the structure of IT systems and their relationships. **Describe** the **architecture** of the **target state environment** in detail.

The following are common Platform perspective roles:

- Chief technology officer (CTO)

- IT managers

- Solutions architects

**Security**

The Security perspective makes sure that the organization meets security objectives for **visibility**, **auditability**, **control**, and **agility**.

Use AWS CAF to structure the selection and implementation of security controls that meet the organization’s needs.

The following are common Security perspective roles:

- Chief information security officer (CISO)

- IT security managers

- IT security analysts

**Operations**

The Operations perspective helps you to enable, run, use, operate, and recover IT workloads to the level agreed upon with your business stakeholders.

Define how **day-to-day**, quarter-to-quarter, and year-to-year **business is conducted.** Align with and support the operations of the business. AWS CAF helps these **stakeholders define current operating procedures and identify the process changes and training needed to implement successful cloud adoption**.

The following are common Operations perspective roles:

- IT operations managers

- IT support managers



### Seven Migration Strategies 

So, it’s finally time to migrate to AWS. Every application will have seven possible options for cloud migration. We call these the seven Rs.

1. Rehost

2. Relocate

3. Replatform

4. Refactor

5. Repurchase

6. Retain

7. Retire

The first strategy is **rehost**. This is as also called **lift and shift,** and it’s convenient for businesses because they **don’t need to make any changes**. At least, not at first. Just pick up the applications and move them pretty much as-is onto AWS. Usually this involves **turning existing servers into virtual machines or VMs**. You might not get all the possible benefits. But some companies find that even **without any optimization**, they can save up to **30 percent** of their total costs just by rehosting.

The next strategy is **relocate**. This could be if **applications** are **already VMs or containers** running on premises and it's **changing the hosting location to the cloud.**

The third option is called **replatform**, or **lift, tinker, and shift**. It's basically a lift and shift, but instead of a pure **one-to-one migration**, you might make a few cloud **optimizations**. But you're **not** touching any **core code in the process**. No new development efforts are involved here. For example, you might take your existing **MySQL database** and **replatform** it onto **Amazon RDS without** any **code changes** at all. Or you might even consider **upgrading** to Amazon **Aurora**. This can give significant benefits to your database team and provides improved performance.

Number four: **refactor** or sometimes called **rearchitecting.** Now, you're **writing new code**. This is driven by a strong business need to **add features or performance** that might **not be possible** on **premises** but now are within your reach. **Dramatic changes** to your **architecture** can be very beneficial to your enterprise, but this will come at the **highest initial cost** in terms of planning and human effort.

Number five is **repurchase** or **drop and shop**. This is a common strategy for companies that want to **change software vendors** and get a **fresh start** as part of their migration. For example, ending your licensing with a database vendor in favor of cloud-based database offerings. Now, this sounds great, but remember you will have to deal with a **new software package**. Some are straightforward to implement, but others take time. The total **upfront expense** of this strategy might **increase**, but the **potential benefits** can be substantial. Repurchasing involves moving from a traditional license to a software-as-a-service (SaaS) model.

The last two strategies, **retain** and **retire**, don't actually involve migrating anything. Let's look at retain first. Retain can also be called **stays where it lays.** This is when some applications are about to be deprecated but maybe not just yet. They still **need to run for another couple of months.** You can migrate these applications to AWS, but why? You should only migrate the applications that **make sense** for **your business**. And then as time goes on, these applications can be deprecated where they live and, **ultimately**, **retired**.

And speaking of **retiring**, that's our seventh strategy. I’s not unusual for companies to find that more than 10 percent of their workloads in an enterprise IT portfolio are **no longer being used.** Using the AWS migration plan as an opportunity to **end-of-life** these applications can save significant cost and effort for your team. Sometimes, you just need to turn off the lights. And that's it: the seven Rs of Migration.

[The Seven R's of Cloud Migration](../Tables/The%20Seven%20R's%20of%20Cloud%20Migration.md)

### Migration Services and Tools 

Let's explore four services that help businesses move their applications and data to the cloud.

---

**Application Discovery Service**

The Application Discovery Service discovers **on-premises server inventory and connections**. It gathers **configuration**, **performance**, and **connection details** for both servers and databases to create a **detailed migration plan.**


---

![image](../Images/Media/image%20(104).png)
[image](../Images/image%20(104).md)

---

**Benefits:** With Application Discovery Service, you get a comprehensive snapshot of your on-premises inventory. You also can integrate discovery data with other services like Migration Hub and protect the data Application Discovery Service collects.

**Use cases:** You can use the AWS Application Discovery Service to conduct discovery and inventory, map the connections and dependencies, and generate a migration plan.

Think of this as your migration **detective**. It **explores your current IT setup**, taking notes on **what programs** you use, **how** they **work together**, and what **resources** they **need**. This helps you **plan your move to AWS more effectively** by performing the **automatic discovery** of **applications** and providing detailed **reports on your IT landscape.** You can use this to make **informed decisions** about what you want to move and how to do it, saving time and **reducing risks** during migration.

---

**Application Migration Service**

Application Migration Service is a tool to move and improve your on-premises and cloud-based applications. It helps customers streamline, expedite, and **reduce** the **cost** of migrating and **modernizing** applications.


---

![image](../Images/Media/image%20(105).png)
[image](../Images/image%20(105).md)

---

**Benefits:** The benefits include support to **migrate from** any source infrastructure that runs a **supported operating system** (OS). It makes it possible to **modernize** your applications during migration. You can **maintain normal business operations** during the **application replication process** and also reduce costs by using one tool for a wide range of applications.

**Use cases:** You can use the Application Migration Service for **on-premises** applications running on **physical servers** or infrastructure, **cloud-based** applications, or moving **between AWS Regions.** You can also use it to modernize applications.

Next is the **AWS Application Migration Service**. This is like having a team of **expert movers.** It helps you pack up your applications and smoothly transport them to AWS. It can even make **small adjustments** to ensure everything works in its **new cloud home.** Benefits include **automated migration** and **minimal downtime** during the move. You can use this to **quickly transfer** their applications to the cloud without disrupting business operations.

---

**Migration Evaluator**

The Migration Evaluator is a migration assessment service that helps you create a business case for AWS Cloud planning and migration. It does this with a **data driven approach**, analyzing your current state, target state, and developing a **migration readiness** plan with projected cloud costs.


---

![image](../Images/Media/image%20(106).png)
[image](../Images/image%20(106).md)

---

B**enefits:** The benefits include removing the guesswork when migrating. It provides visibility into **multiple cost-effective** cloud migration **scenarios**. It also gives insights on **reusing existing software licensing,** which can further reduce costs.

**Use cases:** You can use Migration Evaluator to conduct broad-based discovery, take a snapshot of your current on-premises footprint to fine-tune licensing, view **server dependencies**, and gain visibility into multiple migration scenarios. You can also use it to estimate and reduce your cloud costs.

Then there is the **Migration Evaluator**. Imagine a **moving consultant** who helps you **estimate** the **cost of your relocation.** This tool **analyzes your current IT setup** and provides **detailed cost estimates for moving to AWS.** It helps you understand **potential savings** and **plan your budget.** Businesses can use this to make **data-driven decisions** about their cloud migration strategy and **justify the investment to stakeholders.**

---

**Migration Hub**

The Migration Hub is a centralized hub to take you from discovery, assessment, planning, and execution of your migration. It provides **tools**, **guidance**, and **automated recommendations** to collaborate with your team and **track your migration.**


---

![image](../Images/Media/image%20(107).png)
[image](../Images/image%20(107).md)

---

**Benefits:** With the Migration Hub, you have one location to go for your migration and, expert guidance in the form of prescriptive journey **templates**. Another benefit is cost savings because there is **no charge to use Migration Hub.**

**Use cases:** You can use Migration Hub for migration **assessment** and **planning** and migration **completion** and **collaboration** with teams. You can also use it for **modernization efforts** like **fast-tracking application refactoring.**

Finally, there is the **AWS Migration Hub.** This is your **command center for the entire moving process**. It gives you a **unified view** of all **tasks** and **progress tracking**. You can use this to keep your migration efforts organized and ensure nothing falls through the cracks. Working together, these AWS migration tools provide several benefits: **streamlined migration process**, **reduced risk of errors or downtime, cost savings through efficient planning, and faster time to value** in the **cloud**.

By using these tools, businesses can make their journey to AWS smoother, faster, and more cost-effective. And that in turn, helps businesses start enjoying the benefits of the cloud sooner.

#### **AWS Migration and Modernization Competency Partners**

When migrating to the AWS Cloud, if you need help and expertise, you don't have to go it alone. You can work with the AWS Competency Partner Program. You can search for AWS Migration and Modernization Service Partners who specialize in specific phases of the migration or the type of help you need. To learn more, refer to [AWS Migration and Modernization Competency Partners(opens in a new tab)](https://aws.amazon.com/migration/partner-solutions/?blog-posts-cards.sort-by=item.additionalFields.createdDate&blog-posts-cards.sort-order=desc&partner-case-studies-cards.sort-by=item.additionalFields.sortDate&partner-case-studies-cards.sort-order=desc).

[AWS Migration Tools and Services](../Tables/AWS%20Migration%20Tools%20and%20Services.md)

### Database Migrations

Companies choose to migrate their databases to AWS for a variety of reasons like cost optimization or modernization. No matter the motivation for your migration, **AWS Database Migration Service**, or **AWS DMS,** is a really useful service. DMS is a migration service to move your database to AWS. You can use it to migrate **relational databases, data warehouses, NoSQL databases, and even analytics workloads.**

---

**AWS DMS**

The AWS Database Migration Service (AWS **DMS**) makes it possible to quickly and securely migrate databases and perform ongoing data replication tasks for **live databases** and data warehouses. It provides a way to **plan**, **assess**, **convert**, and migrate databases even with data warehouses in one central tool.


---

![image](../Images/Media/image%20(108).png)
[image](../Images/image%20(108).md)

---

**Benefits:** AWS DMS provides benefits for migrating databases including **maintaining high availability and low downtime during the migration process.** It supports **homogenous** and **heterogenous migrations**. It also makes it possible to migrate **terabyte sized databases at a low cost.**

**Use cases:** You can use AWS DMS to move to managed databases, **remove licensing costs, replicate ongoing changes** in your database, and improve integration with data lakes.

At the most basic level, **DMS** is a **virtual machine** that **runs replication software**. You configure a **source** and **target database** to tell DMS where to **extract data** from and where to **load** it. Then, you **schedule** a **task** that **runs on this server to move your data.** When the migration starts, **data** is **migrated** while your original **database stays live**. AWS DMS handles all the complexity. You even have the **option** to **fall back to your original database**. Or you can **replicate to other databases** in different AWS **Regions** or **Availability Zones.**

Now, what if you need to change from **one type of database to another**? For example, maybe you want to move your legacy commercial database to a different type of engine like **Amazon Aurora.** That's called a **heterogenous conversio**n, and it requires a few extra steps. For this, you'd need to figure out the **schema**, or the **structure and organization of the data**, and **where** everything will **move to** in the new **database**.

---

**AWS SCT**

AWS SCT makes it possible to convert database schemas and code objects (like **stored procedures, views, and functions)** from one database **engine** to another. AWS SCT can even give you **estimates** of how big of an **effort** a conversion is, which helps with **planning**.


---

![image](../Images/Media/image%20(109).png)
[image](../Images/image%20(109).md)

---

**Benefits:** AWS SCT provides benefits to simplify database migrations by **automating schema analysis, recommendations, and conversion at scale.** It is compatible with popular databases and analytics services as source and target engines. It can save weeks or months of manual time and resources, which are typically required in conversions.

**Use cases:** You can use AWS SCT to move from **commercial databases** to **open source databases**. You can also use it for migrating **large data warehouse workloads** and **modernizing** or **updating database schemas** in place.

**AWS Schema Conversion Tool**, or **AWS SCT**, can be a huge help with these types of conversations. SCT **converts** the **source database schema and code** into a **format** **compatible with the target database.** Any code that can't be converted automatically is **marked for manual conversion** for you to review, and then the migration is ready to go.

These two AWS database migration services provide several benefits. They **save you time.** What might take weeks or months to do manually can be done much quicker. They provide a **cost**-**effective** solution and help reduce the effort of moving to new database systems. They give you flexibility so you can conveniently **explore** and **adopt different database options** that best suit your needs. And they’re secure, utilizing **AWS security best practices** during your migration to cloud.

So, whether you need to migrate to the same type of database or to one of the dozen different AWS databases, there are migration tools to help you make your move successful.

### Transferring Data Online

Several AWS services facilitate online data transfer to the AWS Cloud. In the last lesson, you learned that AWS Database Migration Service (AWS **DMS**) transfers the database and its data to the AWS Cloud. In this lesson, you will identify services that can help with the **considerations** of **online transfer** for other types of data and files.

In this lesson, you will review three services:

- **AWS DataSync**

- **AWS Transfer Family**

- **AWS Direct Connect**

When you migrate data to the AWS Cloud, there are a few considerations to keep in mind. You need to ensure **security** (will it get there safely), data **validation** (will it get there in **one piece**), **scheduling** (when is the best time). You would also confirm **bandwidth requirements**. For the majority of data migration workloads, AWS **DataSync** will do the job.

---

**AWS DataSync**

AWS DataSync is specifically designed for **automating** and **accelerating** data **transfer**. DataSync simplifies and accelerates moving large amounts of data between **on-premises** storage and **AWS storage** services like Amazon Simple Storage Service (Amazon **S3**). It **automates** many aspects of the transfer process, including **running instances**, **encryption**, and **network optimization.**


---

![image](../Images/Media/image%20(110).png)
[image](../Images/image%20(110).md)

---

**Benefits:** The benefits include streamlining and accelerating secure data migrations. DataSync manages data movement workloads with **bandwidth throttling**, migration **scheduling**, **task filtering**, and **task reporting**. It also provides **rapid data replication.**

**Use cases:** You can use DataSync to migrate your data, **archive** your **cold data**, and manage **hybrid data workflows.**

---

**AWS Transfer Family**

The AWS Transfer Family makes it possible to seamlessly manage and share data with simple, secure, and scalable file transfers. This service provides fully managed support for secure file transfers over FTP, **Secure File Transfer Protocol** (SFTP), **File Transfer Protocol Secure** (FTPS), and other protocols. It helps you transfer files directly into and out of AWS storage services like Amazon **S3** and Amazon **EFS**.


---

![image](../Images/Media/image%20(111).png)
[image](../Images/image%20(111).md)

---

**Benefits:** The benefits include **simplifying** the process of **setting up and managing file transfers** and reducing the need for complex infrastructure management. The Transfer Family provides **secure data transfer** with encryption and **authentication**, to ensure data **integrity** and **confidentiality**. It is built to **scale** and streamline workflows.

**Use cases:** You can use the Transfer Family to **modernize** and **manage your file transfers,** **simplify data sharing** with your **workforce** and **partners**, and **integrate transactional business data into a unified data lake.**

[AWS DataSync vs Transfer Family](../Tables/AWS%20DataSync%20vs%20Transfer%20Family.md)

You might remember Direct Connect from the networking module. With the bandwidth of a dedicated connection, it is also a great solution for moving your data online to the AWS Cloud when migrating.

---

**Direct Connect**

AWS Direct Connect is a service that makes it possible for you to establish a **dedicated private connection between your network and virtual private cloud (VPC)** in the AWS **Cloud**. Because it is your dedicated connection, it is a **fast**, **reliable**, and **secure** way to transfer your data or files.


---

![image](../Images/Media/image%20(112).png)
[image](../Images/image%20(112).md)

---

**Benefits:** Direct Connect helps **reduce network costs** and increase amount of bandwidth.

### Transferring Data Offline 

Alternatives for data migration

**Transferring data offline**

Many customers prefer online migrations, but there are some customers who need to transfer data offline. An example would be if **bandwidth is limited**, or in remote locations with no internet and Direct Connect is not an option. Or, in cases with **large data volumes**, sending **petabytes** of data **over the internet** would take **longer** than simply sending a **physical device**. In the following section, you will review **AWS Snowball Edge Storage Optimized devices.**

---

**Snowball Edge Storage Optimized devices**

**AWS Snowball Edge Storage Optimized devices** are a great solution for offline data migration where connecting to the internet might not be an option. These **devices** deliver **high performance NVMe storage**, making it possible to simplify **multi-petabyte data** migrations from **on-premises locations to AWS.**


---

![image](../Images/Media/image%20(113).png)
[image](../Images/image%20(113).md)

---

**Benefits:** The benefits include delivering better compute performance and larger storage capacity with gigabytes of data per second for data migration workloads with offline requirements.

**Use cases:** You can use Snowball Edge devices for data migration when offline migration is required. They can also be used for **edge computing** when a **secure**, **rugged** device is needed.



## Module 13 - Well-Architected Solutions 

### Introduction to Well-Architected Solutions 

Well, well, well, it's good to see you're still here. We're nearing the end of our time together, but with just a few topics left we aren't done yet!

There are actually hundreds of AWS services that we could cover, but we're just going to discuss a few more that can be used for development, business applications, and end user computing.

By now, you're also familiar with how to use AWS services as building blocks for your cloud solutions. With the flexibility AWS provides, you can create virtually any architecture to solve the problem at hand. Whether basic or complex, the options are endless. But here's the key question: how do you know if the architecture you’ve built is actually good? In other words, how can you ensure that your solution is both effective and optimized for the real world?

Luckily, AWS provides tools to help **evaluate** the quality of your **designs**. One of the most important tools at your disposal is the **Well-Architected Framework**. The Well-Architected Framework helps you evaluate the architectures you build, ensuring that they are aligned with **best practices** in key areas.

Alright, ready to wrap up this party with a few more services and some help on how to architect efficiently? Let's get going.

### AWS Specialized Services 

As you know, each AWS service is purpose-built for specific use cases, often times based on feedback or requests from customers. Let's look at a small sample size by considering some services for **development**, **business applications**, and **end-user computing.**

Starting with services for **development**, let's think about one that's purpose built for continuous **integration and continuous delivery, or CI/CD**, pipelines. **CI/CD pipelines** help developers continuously release code automatically as changes are committed to a source code repository.

**AWS CodePipeline** is a service that **automates** your **release pipeline.** It can **monitor** your **repository** for **changes**, and then it can kick off a series of steps, like **building**, **testing**, and **deploying** the **code**. Essentially, it helps developers set up a **workflow** that takes their code from **development to production** smoothly.

Another service to be aware of for developers is **AWS X-Ray**. This service helps you **monitor** and **debug** your **applications**, giving you **insights** into how they’re **performing**. When an application isn't behaving as expected, X-Ray helps you **visually pinpoint the issue** by **tracking requests** as they **move through** **your system**, so you can fix problems faster.

Then there's **AWS AppSync**, which is a service that streamlines building **GraphQL APIs**. GraphQL is a specific type of **API** that has gained **popularity** in **web** and **mobile development** in recent years. **AppSync** helps you more easily **connect frontend** apps with **backend data.**

Next up; **AWS Amplify**, which makes it more convenient to **develop**, **deploy**, and **manage applications** on **AWS**. Whether you're adding authentication, data storage, or hosting, Amplify handles a lot of the complexity for you, so you can focus on creating a great **user experience.**

Now, let's look at some **business application services**. One service in this category is **Amazon Connect.** It's an **AI**-**powered**, **cloud-based** **contact center** service that makes it more efficient to set up and manage **customer service operations.** Whether you're answering calls, handling chats, or running a **support center,** by using Amazon **Connect**, you can design solutions that ensure smooth **communication with customers.**

Another helpful tool is **Amazon Simple Email Service, or SES**. If your business needs to **send large volumes of emails**—whether it's **newsletters**, **promotional** messages, or transactional emails— SES is a great choice.

So, those were a few specialized services for business use cases. But let's shift gears a bit and talk about **end-user computing**. One of the functions of IT in modern businesses is setting up and configuring services that make it easier to provide **remote access** to resources like **virtual desktops and applications.**

Amazon **AppStream 2.0** makes it possible for you to s**tream desktop applications** to **users** on any device. Instead of installing software locally, users can simply access the **applications** they need **over the web.**

Then, there's **Amazon WorkSpaces,** a **fully managed virtual desktop infrastructure** service that **users** can **access** from **anywhere**.

For a more **lightweight solution**, there's **Amazon WorkSpaces Web -now called WorkSpace Secure Browser**, which is designed for people who only need **web-based applications.**

Okay, wow! That's a lot of different perspectives and services, and it's not even the whole list. But as you can see, of the hundreds of services and tools from AWS, each one is **purpose-built** and tailored to specific use cases.

**Types of services**

AWS services are purpose-built for specific use cases. In the following section, you will learn more about the following four types of specialized AWS services:

- Development services

- Business application services

- End-user computing services

- IoT services

#### Development services

AWS offers several services to help developers automate CI/CD pipelines, monitor and debug applications, build GraphQL APIs, and deploy web and mobile applications on AWS. Let's examine these services in a bit more detail.

---

> **AWS CodeBuild**

**CodeBuild** is a **fully managed continuous integration** service that **compiles source code**, **runs tests**, and **produces software packages** for **deployment**. It **automatically scales** to meet demand, and you only **pay for the build time** that you use.


---

![CodeBuild](../Images/Media/CodeBuild.png)
[CodeBuild](../Images/CodeBuild.md)

---

---

> **AWS CodePipeline**

**CodePipeline** is a **fully managed CI/CD** service that **automates** the **build**, **test**, and **deploy** phases of your **release process.** This helps developers streamline **software release workflows** and **reliably deliver new feature**s and fixeswithout needing to provision servers.


---

![CodePipeline](../Images/Media/CodePipeline.png)
[CodePipeline](../Images/CodePipeline.md)

---

- ***CI/CD pipelines*** *automate the integration, testing, and deployment of code changes to help provide quick and reliable software delivery.*

- **CodePipeline** is the orchestrator (the **workflow manager**), and **CodeBuild** is the **executor** (the engine) for one specific step (the build).

---

> **AWS X-Ray**

**X-Ray** is a powerful **tracing**, **debugging**, and **performance** **analysis** tool that helps developers **visualize application behavior**. With X-Ray, developers can quickly identify performance **bottlenecks**, **troubleshoot issues**, and **optimize applications** for better **efficiency** and **reliability**.


---

![X-Ray](../Images/Media/X-Ray.png)
[X-Ray](../Images/X-Ray.md)

---

---

> **AWS AppSync**

**AWS AppSync** is a **fully managed GraphQL** service. With AWS AppSync, developers can create a **single GraphQL API** that can securely access, manipulate, and combine data from multiple data sources. This helps developers connect frontend applications with backend data.


---

![AppSync](../Images/Media/AppSync.png)
[AppSync](../Images/AppSync.md)

---

- *With* ***GraphQL****, a query language for APIs, clients request only the specific data they need.*

---

> **AWS Amplify**

**Amplify helps** you streamline the process of **developing**, **deploying**, and **managing secure** and **scalable full-stack applications** on AWS. With Amplify, developers can quickly **add features**, like **authentication**, **APIs**, **storage**, and **hosting**, with **minimal infrastructure management.**


---

![Amplify](../Images/Media/Amplify.png)
[Amplify](../Images/Amplify.md)

---

- ***Full-stack applications*** *are software systems that involve both frontend (user interface) and backend (server-side) development.*

#### Business application services

These services are ideal for managing business application needs such as **customer service** operations and **email promotions**. Let's review a couple of examples.

---

> **Amazon Connect**

Businesses can use this **AI-powered contact center** service to efficiently **set up** and **operate** a **scalable customer service call center**. Amazon Connect provides capabilities for **call routing, recording**, and **analytics** while **integrating** seamlessly with **other AWS services.**


---

![Connect](../Images/Media/Connect.png)
[Connect](../Images/Connect.md)

---

---

> **Amazon Simple Email Service (Amazon SES)**

**Amazon SES** is a **scalable** and **cost-effective email** service provider that can be integrated into any application for **reliable**, **high-volume email automation.** It helps businesses optimize the **delivery** of **transactional** and **marketing email**s, resulting in enhanced **customer engagement.**


---

![Simple-Email-Service](../Images/Media/Simple-Email-Service.png)
[Simple-Email-Service](../Images/Simple-Email-Service.md)

---

#### End-user computing services

In modern businesses, IT departments often need to provide **remote access** to resources like **virtual desktops** and **applications**. Let's explore some AWS services that can be used to set up these environments for employees.

---

> **Amazon AppStream 2.0**

**AppStream 2.0** is a **fully managed** service that **streams applications** from the **cloud** directly to any **compatible device**. This includes **software-as-a-service** (**SaaS**) applications and applications **converted** from **desktop** to **SaaS without code revision**s. This provides instant access to powerful software without the need for high-end local hardware.


---

![AppStream](../Images/Media/AppStream.png)
[AppStream](../Images/AppStream.md)

---

- *In* ***SaaS****,* *applications are hosted on the cloud and accessed through the internet, without the need for local installation or maintenance.*

---

> **Amazon WorkSpaces**

**WorkSpaces** is a **fully managed** **cloud-based desktop computing** service. With WorkSpaces, **employees** can **securely access** their **work environment** from any **device** with an **internet connection.** Employees can perform the same tasks as if they were on a physical office computer, while companies can benefit from cost-efficiency and easy administration.


---

![image](../Images/Media/image%20(114).png)
[image](../Images/image%20(114).md)

---

> **Amazon WorkSpaces Secure Browser (formerly Amazon WorkSpaces Web)**

---

**WorkSpaces Secure Browser** is a **fully managed remote enterprise browser.** It provides a protected environment for employees to **access private websites**, **SaaS applications,** and the **public internet.** With WorkSpaces Secure Browser, IT departments **don't need** to manage specialized **client software, infrastructure, or VPN connections.**


---

![image](../Images/Media/image%20(115).png)
[image](../Images/image%20(115).md)

---

#### IoT services

**Internet of Things (IoT)** is a network of connected physical devices embedded with sensors and software that collect and exchange data over the internet. These devices can be monitored and controlled remotely to improve efficiency, provide new services, and enhance quality of life.

> **AWS IoT Core**

---

**AWS IoT Core** is a **managed** cloud service used to securely **connect physical devices** with **cloud applications**. It helps you create **efficient IoT solutions** by streamlining the complex process of **ingesting**, **processing**, and **acting on device data**. Device **connections** and data are **secured** with mutual **authentication** and **end-to-end encryption**, and you can choose from several c**ommunication protocols.**


---

![IoT-Core](../Images/Media/IoT-Core.png)
[IoT-Core](../Images/IoT-Core.md)

---

Some IoT solutions include the following:

- **Smart security cameras** – Home monitoring that sends alerts to your phone

- **Smart pet feeders** – A pet feeder that you can control remotely

- **Smart irrigation systems** – A rain machine that adjusts watering based on weather and soil conditions

[AWS Cloud Specilized Services Overview](../Tables/AWS%20Cloud%20Specilized%20Services%20Overview.md)

### AWS Well-Architected Framework

The AWS Well-Architected Framework helps organizations build more secure, high-performing, resilient, and efficient infrastructure for their applications. It's composed of **six pillars**, which can be applied to any workload. These six pillars are **Operational Excellence, Security, Reliability, Performance Efficiency, Cost Optimization, and Sustainability**. As architects, we gotta know those off by heart. But this framework provides a **consistent approach** for **designing architectures.**

The first pillar is **Operational Excellence**. It focuses on **running** and **monitoring systems** to deliver **business value** while **continuously improving processes**. This includes things like **automating deployments** through **pipelines** and **responding** to **events** effectively to ensure smooth operations.

The second pillar is **Security**. Don’t let bad actors in and keep everything locked down. This is where this pillar comes in. It helps to make sure you are **building security** **into** your **solutions** using **best practices.** Additionally, it shows you how to maintain **data integrity**, **protect systems**, and adhere to the principle of **least privilege access.**

The third pillar in the framework is **Reliability**. This pillar is centered on **recovery planning** and making sure systems can **withstand failures**. This includes **strategies** for recovering from **disruptions**. The other part of the pillar pertains to **adapting** systems to meet **evolving** business and customer **demands**.

The next pillar is **Performance Efficiency.** It focuses on using **resources efficiently**, like with **rightsizing** your **EC2 instance** based on workload and memory requirements. More so, this pillar promotes making **informed decisions** to ensure efficiency **continues**, even as **business needs change.**

The fifth pillar is **Cost Optimization**. As you can guess, it focuses on **controlling** and **reducing expenditures** by **optimizing resource allocation.** For example, you provision a specific EC2 instance to start out. And then, as you gain more information on your workload, you realize the instance is being underutilized. Are you stuck with it? No. You can switch to an instance with lower specs, which might actually be more cost-effective. Moreover, if you don’t need a service, **deprovision** it. Eliminate the cost.

The sixth and final pillar is **Sustainability**. It emphasizes designing **energy-efficient systems** and minimizing environmental impact. This pillar encourages using the most appropriate AWS infrastructure to **reduce** the need for **always-on resources.** For example, if you don’t need an **always-on EC2 instance,** consider switching to **AWS Lambda**. Or maybe using a smaller Amazon RDS instance if you don’t need that extra storage. Not only are you reducing cost, but you can **lower energy consumption** and **carbon emissions.**

Now that you have an understanding of the pillars, how do you actually use the framework? Well, here’s how: It’s a **self-service tool!** Create a **workload**, **run the tool against your AWS account**, and a **report** is **generated** that shows areas that should be addressed. Apart from the tool showing you where it has detected potential issues, it **shows you how to remedy them**. These remediations are determined using **established best practices**. But it should be noted that you can always override these settings if the questions don't apply to your specific scenario. It's very **customizable**, so don’t stress. Take the **advice** and do the best remediation possible.

You can see the workload name, pillars, and drop-down menus with questions for each one. You can also change the toggle to indicate whether the question is applicable or not. Lastly, there are resources to help you understand how to answer each question.

Anyhow, that's the Well-Architected Framework and tool. Hope you have enjoyed learning how to evaluate your workloads.

1. **Operational Excellence:
​**Focuses on operations, monitoring, automation, and continuous improvement

2. **Security:
​**Protects systems and data through best practices like least privilege and data integrity

3. **Reliability:
​**​Emphasizes recovery planning and system adaptability to meet changing demands

4. **Performance Efficiency:** ​Encourages using the right resources for the job and adjusting as needs evolve

5. **Cost Optimization:** ​Helps control and reduce costs through smart provisioning and resource management

6. **Sustainability**:
​Promotes energy-efficient design and environmentally conscious resource usage

**AWS Well-Architected Tool**

**The AWS Well-Architected Tool** (AWS WA Tool) is a **free service** that helps **assess** and **improve cloud workloads** based on the six key pillars: **Operational Excellence, Security, Reliability, Performance Efficiency, Cost Optimization, and Sustainability.** It offers workload **reviews**, **milestone tracking,** and **custom lenses** for tailored **evaluations** and **improvement plans**. Integrated with AWS services like **AWS Identity and Access Management (IAM)** and **APIs**, it supports **team collaboration** and **continuous progress tracking.** The **AWS WA Tool** is ideal for **architects**, **engineers**, and **compliance teams,** and it promotes **consistent**, **actionable**, and **well-documented architecture reviews.**

#### **Optimizing a cloud architecture**

Imagine you own a bustling online florist business, with orders flowing in during peak times like Valentine’s Day or Mother’s Day. Behind the scenes, the cloud **architecture** needs to be just as **resilient** and **efficient** as the **operations**. Let’s use the Well-Architected Framework to optimize the system for **reliability, performance, security, cost savings, and sustainability.**

**Starting architecture**

![image](../Images/Media/image%20(116).png)
[image](../Images/image%20(116).md)

Let’s look at your current setup. You have a **classic ecommerce architecture**. It includes Amazon Elastic Compute Cloud (Amazon **EC2**) instances for the **website** and Amazon Relational Database Service (Amazon **RDS**) **databases** to handle **orders** and **customer data**. It also has an Amazon Simple Storage Service (Amazon **S3**) bucket **full of product images.** It’s functional, but let's evaluate how well it's **scaling** and handling traffic—especially during busy times.

**Operational Excellence**

![image](../Images/Media/image%20(117).png)
[image](../Images/image%20(117).md)

Your business is running smoothly, but what happens if an **EC2** instance **crashes** during a rush of orders? To be truly **resilient**, you can **automate scaling with EC2 Auto Scaling**. Additionally, to make day to day operations more **reliable** and **efficient**, you can use **infrastructure as code** and implement **self healing mechanisms** like **auto-rollback**. These practices help your system **adapt** during **high-demand** periods as well as **operate efficiently over time.**

Enhancement: EC2 Auto Scaling

**Security**

![image](../Images/Media/image%20(118).png)
[image](../Images/image%20(118).md)

You’ve already got a secure foundation with an Amazon Virtual Private Cloud (Amazon **VPC**), but there’s more to do. Ask yourself: Are your **EC2** instances regularly patched? Do your IAM policies follow the principle of **least privilege**? **Protecting** customer **data**—like names, addresses, and payment info—requires strong **encryption** for **data at rest** and **in transit**, along with **fine-grained access controls**. Strengthening these layers builds trust with your customers and safeguards sensitive information.

Enhancement: Strengthening encryption and IAM policies

**Reliability**

![image](../Images/Media/image%20(119).png)
[image](../Images/image%20(119).md)

During busy seasons, **availability** is everything. You’ve already taken a great step by deploying resources across **multiple Availability Zones**, but you can increase reliability even further. Use **Amazon CloudWatch** to **monitor** your system’s **health** and set up **automated recovery actions.**

Enhancement: Amazon CloudWatch

**Performance Efficiency**

![image](../Images/Media/image%20(120).png)
[image](../Images/image%20(120).md)

As your business **scales**, your system should scale with it. Are your **EC2** instances and **RDS** instances **rightsized** for your workload? **AWS Compute Optimizer** can help make sure you’re not wasting resources or under **provisioning** your infrastructure. You’re already using **AWS Lambda** for **event-driven tasks** like **image processing**, which is great for **flexible scaling**. Make sure those **functions** are **rightsized**, too. And with **Amazon CloudFront**, you can already **deliver product images quickly** to global customers for a smooth, fast shopping experience.

Enhancement: AWS Compute Optimizer

**Cost Optimization**

![image](../Images/Media/image%20(121).png)
[image](../Images/image%20(121).md)

You're currently using **On-Demand EC2 instances**, which are great to start with, but switching to **Spot Instances** for variable traffic and **Savings Plans** for steady workloads can **cut costs** significantly. **Track** and **manage** your cloud **spending** in **real time** with **AWS Budgets and AWS Cost** Explorer. These tools help you make smart, cost-effective decisions while maintaining performance and reliability.

Enhancement: Savings Plans, AWS Budgets, AWS Cost Explorer

Sustainability

![image](../Images/Media/image%20(122).png)
[image](../Images/image%20(122).md)

Your use of **serverless** and **elastic resources** already reduces your environmental footprint. To go further, continue optimizing workloads to **minimize resource waste.** Doing so benefits both the planet and your bottom line—proving that environmentally conscious decisions can also be business-smart.

Enhancement: AWS Cost & Usage Report



### Specialized Use Cases

**Alan:** Welcome back to Cloud in Real Life. Let's take a look at some really interesting **serverless architectures**. Who wants to kick us off?

**Morgan:** I do! Okay, I'm gonna start. I love talking about serverless. What if we begin by thinking about a **typical serverless web backend setup**. I’m thinking something like Amazon **API Gateway,** AWS **Lambda**, Amazon **DynamoDB**, and AWS **X-Ray** for tracing. As someone with a developer background, like myself, this is basically the dream team of AWS services for me.

**Rudy:** This setup makes it possible for you to host your backend services and make them **consumable** for **frontends** using **API Gateway**. **Data** is **stored** in **DynamoDB**, and **X-Ray** helps with **troubleshooting**. Morgan, can you explain how consumers typically interact with these services?

**Morgan:** Yes. So, **customers invoke the APIs** exposed by **API Gateway** by using **HTTP**. **API Gateway** **receives** and **validates** the **request** then **invokes the Lambda function** and then **returns** that **response** to the **user**.

![image](../Images/Media/image%20(123).png)
[image](../Images/image%20(123).md)

**Alan:** I really like how this is **entirely serverless**. X-Ray is really cool here because with an architecture like this it's not just a single component like a traditional web server. X-Ray is made to work well in these **distributed environments**, because **X-Ray traces the request through API Gateway, to Lambda, to DynamoDB**, all the way back to the **client**. So, if anything goes wrong, you can use it to determine where the problem is coming from.

**Rudy:** Ah, sticking with the serverless theme, check this one out. A **static website** **hosted directly** on Amazon **S3**. Drag. Drop. Choose Enable. And voila. Static website time. Even better, we have a Contact Us form over here. Before you think we are going to need a server—no, no, no. When the **form** is **submitted**, it sends a **request** to **API Gateway**. That **invokes** a **Lambda function** which, in turn, **sends** an **email** using **Amazon SES**. Hey, what do you say to that, Morgan?

![image](../Images/Media/image%20(124).png)
[image](../Images/image%20(124).md)

**Morgan:** Well, so, this is very similar to the architecture that we just talked about. It's a serverless architecture hosting a web backend using Lambda and API Gateway. But, instead of storing data, this makes an API call to send emails. This is a great example to show how two architectures we covered are similar in the services used but totally different in use case. That's because the code running in a **Lambda function** is just that--**code**. It can be **whatever you need it to be.**

**Alan:** I have another one. Have you seen this architecture using **Amazon Connect?** It's a bit different from the last use case. But, this is an architecture showing how to use Amazon Connect to provide an alternate channel and **callback option** for **customer suppor**t. Because if there are long wait times for people calling, customers can have the **option** to **transition** from **voice** to **chat** or even **email**.

![image](../Images/Media/image%20(125).png)
[image](../Images/image%20(125).md)

**Rudy:** Hey, look, as someone who has been on hold with customer support long enough to memorize the song that's playing...

[MUSIC PLAYING]

I'm extremely excited for this solution. It's a great example of how **AWS services** can be **connected** to create **complex**, **intelligent systems**. In this case, Amazon Connect, Lambda, and Amazon CloudFront. Connect them together, and you have a **smart customer service solution.** Customers can select callback and then hang up. Sign me up, please.

**Morgan:** Yeah, I really couldn't agree more. Okay, well, this has been a great chat. From serverless websites to smart customer support, we've seen how with just a few managed services, you can tackle a range of complex challenges.

### Module Summary

**Morgan**: Hey there, friends! Great news, you've made it to the end of the course!! Now that you've reached the end, there's only a few things left to say.

**Alan**: First off, congratulations!! You've stuck with us through a lot of learning, from regions and AZs, to EC2, database migration, and everything in between. With AWS, the possibilities are endless and there's always something new to learn.




**Rudy**: Yeah, the thing to remember here, is that no one expects you to be a walking AWS encyclopedia. So don't worry. You've learned the basics, and now you can continue your AWS learning journey with confidence.

**Morgan**: You know, I’m just excited for all of you to dive further into the world of AWS. Everyone starts somewhere, so just be positive, and try it out. Even if it’s studying and building for just five minutes of your day.

**Alan**: Totally. And remember, folks, don't be intimidated by the vast AWS landscape. Start with the basics, and build from there. The more you start to build, the more you'll learn. And you'll figure out that with many of the rad options in the architecture, the sky's the limit.

**Rudy**: Exactly, and please, please, for me, take the survey at the end of the course, and let us know what you thought of it! Now, cheers Morgan, cheers Alan, and last but not least, cheers to you, cloud practitioners.



























[AWS Shared Responsibility Model - SRM](../Concepts/AWS%20Shared%20Responsibility%20Model%20-%20SRM.md)

[AWS Monitoring Services (Dashboards, Logs, Metrics)](../Concepts/AWS%20Monitoring%20Services%20(Dashboards,%20Logs,%20Metrics).md)


# Summaries  - From AWS skill builder + Links  

### Module 1 - Introduction to the Cloud 

### Module 2 - Compute in the Cloud 

| Resource link                                                                                                                                                                                                  | Description                                                                                                                                                                                                                                                                    |
| :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Compute on AWS(opens in a new tab)](https://aws.amazon.com/products/compute)                                                                                                                                  | This resource provides an overview of the different cloud computing services offered by AWS.                                                                                                                                                                                   |
| [AWS Compute Blog(opens in a new tab)](https://aws.amazon.com/blogs/compute/)                                                                                                                                  | This blog provides updates, tutorials, and best practices for using AWS compute services, such as Amazon EC2, AWS Lambda, Amazon ECS, and more.                                                                                                                                |
| [AWS Compute Services(opens in a new tab)](https://docs.aws.amazon.com/whitepapers/latest/aws-overview/compute-services.html)                                                                                  | This reference provides an in-depth introduction to the compute services available within the AWS Cloud.                                                                                                                                                                       |
| [Hands-On Tutorials: Compute(opens in a new tab)](https://aws.amazon.com/getting-started/hands-on/?awsf.getting-started-category=category%23compute&awsf.getting-started-content-type=content-type%23hands-on) | This resource provides practical, step-by-step tutorials designed to help users gain hands-on experience with AWS compute services. It is ideal for beginners and those new to cloud computing.                                                                                |
| [Amazon EC2(opens in a new tab)](https://aws.amazon.com/ec2/)                                                                                                                                                  | Amazon EC2 runs virtual servers in the cloud with flexible computing capacity.                                                                                                                                                                                                 |
| [Amazon EC2 Instance Types(opens in a new tab)](https://aws.amazon.com/ec2/instance-types/)                                                                                                                    | This guide provides detailed information about the different types of EC2 instances, including their specifications, capabilities, and use cases. It helps you choose the right instance type based on your workload needs, such as compute, memory, and storage requirements. |
| [Amazon EC2 Pricing(opens in a new tab)](https://aws.amazon.com/ec2/pricing/)                                                                                                                                  | This guide explains the different pricing models for EC2 instances, including On-Demand, Reserved Instances, and Spot Instances, so you can choose the best option based on your usage.                                                                                        |
| [Amazon EC2 Auto Scaling(opens in a new tab)](https://aws.amazon.com/ec2/autoscaling/)                                                                                                                         | Amazon EC2 Auto Scaling automatically adjusts instance count based on demand for high availability and cost-efficiency.                                                                                                                                                        |
| [Elastic Load Balancing(opens in a new tab)](https://aws.amazon.com/elasticloadbalancing/)                                                                                                                     | Elastic Load Balancing automatically distributes incoming application traffic across multiple EC2 instances for high availability and fault tolerance.                                                                                                                         |
| [Amazon Simple Notification Service(opens in a new tab)](https://aws.amazon.com/sns/)                                                                                                                          | Amazon SNS is a messaging service for sending notifications to users or other applications through SMS, email, or mobile push notifications.                                                                                                                                   |
| [Amazon Simple Queue Service(opens in a new tab)](https://aws.amazon.com/sqs/)                                                                                                                                 | Amazon SQS decouples application components through message queuing, storing and processing messages reliably.                                                                                                                                                                 |

### Module 3 - Exploring Compute Services 

| Resource link                                                                                                                                                                                                                                                                                                                                                     | Description                                                                                                                                                                                                                                                               |
| :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| [Containers on AWS(opens in a new tab)](https://aws.amazon.com/containers/services/)                                                                                                                                                                                                                                                                              | The AWS Containers Services page provides an overview of the AWS container offerings, including services for container image storage, orchestration, and compute. These offerings are designed to streamline the deployment and management of containerized applications. |
| [Amazon Elastic Container Registry(opens in a new tab)](https://aws.amazon.com/ecr/)                                                                                                                                                                                                                                                                              | The Amazon ECR is a fully managed service for storing, managing, and deploying container images securely at scale.                                                                                                                                                        |
| [Amazon Elastic Container Service(opens in a new tab)](https://aws.amazon.com/ecs/)                                                                                                                                                                                                                                                                               | Amazon ECS is a fully managed service that streamlines the deployment, management, and scaling of containerized applications on AWS.                                                                                                                                      |
| [Amazon Elastic Kubernetes Service(opens in a new tab)](https://aws.amazon.com/eks/)                                                                                                                                                                                                                                                                              | Amazon EKS is a fully managed Kubernetes service that streamlines running Kubernetes clusters on AWS and on premises. It automates infrastructure management and integrates with AWS networking, security, and storage services.                                          |
| [AWS Fargate(opens in a new tab)](https://aws.amazon.com/fargate/)                                                                                                                                                                                                                                                                                                | Fargate is a serverless compute engine for running containers without managing servers. It is integrated with Amazon ECS and Amazon EKS.                                                                                                                                  |
| [AWS Elastic Beanstalk(opens in a new tab)](https://aws.amazon.com/elasticbeanstalk/?gclid=EAIaIQobChMIpb-UsKDfjAMVfWJHAR2d6xQ1EAAYASAAEgLN5PD_BwE&trk=b1c3dd7d-1b94-4b82-99e3-c1505e3a55fb&sc_channel=ps&ef_id=EAIaIQobChMIpb-UsKDfjAMVfWJHAR2d6xQ1EAAYASAAEgLN5PD_BwE:G:s&s_kwcid=AL!4422!3!651737511569!e!!g!!elastic%20bean%20stalk!19845796021!146736269029) | Elastic Beanstalk is a fully managed service for deploying and scaling web applications without managing infrastructure.                                                                                                                                                  |
| [AWS Batch(opens in a new tab)](https://aws.amazon.com/batch/)                                                                                                                                                                                                                                                                                                    | AWS Batch is a fully managed service for efficiently running large-scale batch computing jobs on AWS.                                                                                                                                                                     |
| [What is Amazon Lightsail?(opens in a new tab)](https://docs.aws.amazon.com/lightsail/latest/userguide/what-is-amazon-lightsail.html)                                                                                                                                                                                                                             | Lightsail is a simplified cloud platform offering VPS, containers, and databases with predictable pricing.                                                                                                                                                                |
| [What is AWS Outposts?(opens in a new tab)](https://docs.aws.amazon.com/outposts/latest/server-userguide/what-is-outposts.html)                                                                                                                                                                                                                                   | AWS Outposts extends AWS infrastructure and services to on-premises locations for low-latency, local data processing.                                                                                                                                                     |
| [Choosing a modern application strategy(opens in a new tab)](https://docs.aws.amazon.com/decision-guides/latest/modern-apps-strategy-on-aws-how-to-choose/modern-apps-strategy-on-aws-how-to-choose.html)                                                                                                                                                         | The AWS Decision Guide for Modern Application Strategy helps organizations determine the most suitable development approach—serverless or Kubernetes—based on their operational model, team structure, and workload requirements.                                         |

### Module 4 - Going Global

| [AWS Global Infrastructure(opens in a new tab)](https://aws.amazon.com/about-aws/global-infrastructure/) | Learn more about the AWS Global Infrastructure.                      |
| :------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------- |
| [AWS for the Edge(opens in a new tab)](https://aws.amazon.com/edge/?nc2=type_a)                          | Learn more about AWS edge locations and edge networking.             |
| [AWS CloudFormation(opens in a new tab)](https://aws.amazon.com/cloudformation/)                         | Learn more about the infrastructure as code service, CloudFormation. |

### Module 5 - Networking

| Resource link                                                                                                                           | Description                                                                                                                                                                                                                                                                |
| :-------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Amazon Virtual Private Cloud(opens in a new tab)](https://aws.amazon.com/vpc/)                                                         | Amazon VPC is a service to provision a logically isolated section of the AWS Cloud where you can launch AWS resources in a virtual network that you define.                                                                                                                |
| [Subnet(opens in a new tab)](https://docs.aws.amazon.com/vpc/latest/userguide/configure-subnets.html)                                   | A subnet is a section of a VPC that can contain resources and is used to organize your resources. They can contain be either public or private.                                                                                                                            |
| [Internet gateway(opens in a new tab)](https://docs.aws.amazon.com/vpc/latest/userguide/VPC_Internet_Gateway.html)                      | An internet gateway is a connection between a VPC and the internet. It allows public traffic from the internet to access your VPC.                                                                                                                                         |
| [Virtual private gateway(opens in a new tab)](https://docs.aws.amazon.com/vpn/latest/s2svpn/how_it_works.html#VPNGateway)               | A virtual private gateway is the component that allows protected internet traffic to enter into the VPC. It allows a connection between your VPC and a private network only if it is coming from an approved network.                                                      |
| [AWS Client VPN(opens in a new tab)](https://aws.amazon.com/vpn/client-vpn/)                                                            | Amazon Client VPC is a networking service you can use to connect your remote workers and on-premises networks to the cloud. It is a fully managed, elastic VPN service that automatically scales up or down based on user demand.                                          |
| [AWS Site-to-Site VPN(opens in a new tab)](https://aws.amazon.com/vpn/site-to-site-vpn/)                                                | AWS Site-to-Site VPN creates a secure connection between your data center or branch offices and your AWS Cloud resources.                                                                                                                                                  |
| [AWS PrivateLink(opens in a new tab)](https://docs.aws.amazon.com/vpc/latest/privatelink/what-is-privatelink.html)                      | AWS PrivateLink is a highly available, scalable technology that you can use to privately connect your VPC to services and resources as though they were in your VPC.                                                                                                       |
| [AWS Direct Connect(opens in a new tab)](https://aws.amazon.com/directconnect/)                                                         | AWS Direct Connect is a service that provides a dedicated private connection between your data center and a VPC.                                                                                                                                                           |
| [Network Access Control List (network ACL)(opens in a new tab)](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-network-acls.html) | A network ACL allows or denies specific inbound or outbound traffic at the subnet level using stateless packet filtering.                                                                                                                                                  |
| [Security groups(opens in a new tab)](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-security-groups.html)                        | Security groups control the inbound and outbound traffic for a resource at the instance level using stateful packet filtering.                                                                                                                                             |
| [Domain Name System (DNS)(opens in a new tab)](https://aws.amazon.com/route53/what-is-dns/)                                             | DNS translates human readable domain names to machine readable IP addresses (for example, 192.0.2.0).                                                                                                                                                                      |
| [Amazon Route 53(opens in a new tab)](https://aws.amazon.com/route53/)                                                                  | Route 53 is a scalable and reliable DNS web service that helps developers and businesses route end users to internet applications, whether they’re hosted in AWS or elsewhere. It also supports domain registration, health checks, and advanced traffic routing policies. |
| [Amazon CloudFront(opens in a new tab)](https://aws.amazon.com/cloudfront/)                                                             | CloudFront is a web service that speeds up distribution of your web content to your users through a worldwide network of data centers called edge locations. It securely delivers content with low latency and high transfer speeds.                                       |
| [AWS Global Accelerator(opens in a new tab)](https://aws.amazon.com/global-accelerator/)                                                | Global Accelerator is a networking service that helps improve the availability and performance of applications for global users by routing traffic through the AWS global network. It helps improve application availability, performance, and security.                   |
| [Amazon Transit Gateway(opens in a new tab)](https://aws.amazon.com/transit-gateway/)                                                   | Amazon VPC Transit Gateways is a network transit hub used to interconnect VPCs and on-premises networks.                                                                                                                                                                   |
| [NAT Gateway(opens in a new tab)](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-nat-gateway.html)                                | Network Address Translation (NAT) gateway allows instances in a private subnet to connect with services outside your VPC. External services can't initiate a connection with those instances.                                                                              |
| [API Gateway(opens in a new tab)](https://aws.amazon.com/api-gateway/)                                                                  | The Amazon API Gateway is an AWS service for creating, publishing, maintaining, monitoring, and securing APIs at any scale. It handles all the tasks involved in accepting and processing up to hundreds of thousands of concurrent API calls.                             |

### Module 6 - Storage 

| Resource link                                                                                                                            | Description                                                                                                                                                                            |
| :--------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Amazon EC2 Instance Store User Guide(opens in a new tab)](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/InstanceStorage.html)     | A temporary storage option that is directly attached to the host computer of an EC2 instance, providing high-performance but non-persistent storage.                                   |
| [Amazon Elastic Block Store (Amazon EBS)(opens in a new tab)](https://aws.amazon.com/ebs/)                                               | A scalable block storage service that provides persistent, high-performance volumes you can attach to your EC2 instances for data storage and applications.                            |
| [Amazon Elastic Block Store (Amazon EBS) FAQ(opens in a new tab)](https://aws.amazon.com/ebs/faqs/)                                      | Frequently asked questions about Amazon EBS.                                                                                                                                           |
| [Amazon EBS Snapshots User Guide(opens in a new tab)](https://docs.aws.amazon.com/ebs/latest/userguide/ebs-snapshots.html)               | EBS Snapshots are point-in-time backups of your cloud storage volumes, making it possible to protect data and restore it when needed.                                                  |
| [Amazon Data Lifecycle Manager User Guide(opens in a new tab)](https://docs.aws.amazon.com/ebs/latest/userguide/snapshot-lifecycle.html) | A service that streamlines the creation, retention, and deletion of Amazon EBS snapshots.                                                                                              |
| [Amazon Simple Storage Service (Amazon S3)(opens in a new tab)](https://aws.amazon.com/s3/)                                              | A scalable cloud storage service that can store and retrieve any amount of data from anywhere on the web.                                                                              |
| [Amazon Simple Storage Service (Amazon S3) FAQ(opens in a new tab)](https://aws.amazon.com/s3/faqs/)                                     | Frequently asked questions about Amazon S3.                                                                                                                                            |
| [Amazon S3 Storage Classes(opens in a new tab)](https://aws.amazon.com/s3/storage-classes/)                                              | Amazon S3 offers various storage classes, from high-performance frequent access to cost-effective archival options, tailored to different data retrieval needs and budget constraints. |
| [Amazon S3 Versioning User Guide(opens in a new tab)](https://docs.aws.amazon.com/AmazonS3/latest/userguide/Versioning.html)             | Amazon S3 versioning keeps multiple variants of objects, offering recovery from unintended deletions or modifications by preserving every update to your files.                        |
| [Amazon S3 Buckets User Guide(opens in a new tab)](https://docs.aws.amazon.com/AmazonS3/latest/userguide/creating-buckets-s3.html)       | S3 buckets are cloud storage containers that securely hold various types of data, allowing convenient access and management through the AWS online infrastructure.                     |
| [Amazon Elastic File System (Amazon EFS)(opens in a new tab)](https://aws.amazon.com/efs/)                                               | A scalable, fully-managed file storage service that lets multiple AWS resources access shared data simultaneously without capacity planning.                                           |
| [Amazon Elastic File System (Amazon EFS) FAQ(opens in a new tab)](https://aws.amazon.com/efs/faq/)                                       | Frequently asked questions about Amazon EFS.                                                                                                                                           |
| [Amazon FSx(opens in a new tab)](https://aws.amazon.com/fsx/)                                                                            | A fully managed file storage service that lets you launch and run file systems like Windows File Server, Lustre, NetApp ONTAP, and OpenZFS in the AWS cloud.                           |
| [Amazon FSx for Windows File Server(opens in a new tab)](https://aws.amazon.com/fsx/windows/)                                            | An Amazon FSx option providing reliable, high-performance file storage compatible with Windows applications in the AWS Cloud.                                                          |
| [Amazon FSx for NetApp ONTAP(opens in a new tab)](https://aws.amazon.com/fsx/netapp-ontap/)                                              | An Amazon FSx option providing file storage with advanced data management capabilities and compatibility with both Windows and Linux workloads on AWS.                                 |
| [Amazon FSx for OpenZFS(opens in a new tab)](https://aws.amazon.com/fsx/openzfs/)                                                        | An Amazon FSx option that provides high-performance, scalable storage using the popular open-source ZFS file system.                                                                   |
| [Amazon FSx for Lustre(opens in a new tab)](https://aws.amazon.com/fsx/lustre/)                                                          | An Amazon FSx option designed to accelerate workloads by providing fast data access for compute-intensive applications in AWS.                                                         |
| [AWS Storage Gateway(opens in a new tab)](https://aws.amazon.com/storagegateway)                                                         | A hybrid cloud storage service that provides seamless and secure integration between on-premises environment and AWS cloud storage services.                                           |
| [Amazon S3 File Gateway(opens in a new tab)](https://aws.amazon.com/storagegateway/file/s3/)                                             | A Storage Gateway configuration that provides local file access to S3 objects while caching frequently accessed data locally for faster retrieval.                                     |
| [Tape Gateway(opens in a new tab)](https://aws.amazon.com/storagegateway/vtl/)                                                           | A Storage Gateway configuration used for backing up data to Amazon S3 while maintaining compatibility with existing tape-based backup applications.                                    |
| [Volume Gateway(opens in a new tab)](https://aws.amazon.com/storagegateway/volume/)                                                      | A Storage Gateway configuration that provides iSCSI block storage volumes to on-premises applications, offering both cached and stored modes.                                          |

### Module 7 - Databases 

| Resource link                                                                                                         | Description                                                                                                                                                                                                 |
| :-------------------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Amazon Relational Database Service (Amazon RDS)(opens in a new tab)](https://aws.amazon.com/rds/)                    | A relational database service supporting multiple engines like MySQL, PostgreSQL, and Microsoft SQL Server with automated maintenance and backups                                                           |
| [Amazon RDS Security(opens in a new tab)](https://aws.amazon.com/rds/features/security/)                              | Detailed information about security configurations in Amazon RDS                                                                                                                                            |
| [Amazon Aurora(opens in a new tab)](https://aws.amazon.com/rds/aurora/)                                               | A cloud-native database offering superior performance and availability over traditional databases while maintaining MySQL and PostgreSQL compatibility                                                      |
| [AWS Database Migration Service (AWS DMS)(opens in a new tab)](https://aws.amazon.com/dms/)                           | A service that provides seamless database migration between source and target databases while keeping the source database operational                                                                       |
| [Amazon DynamoDB(opens in a new tab)](https://aws.amazon.com/dynamodb/)                                               | A NoSQL database service providing single-digit millisecond performance at any scale with built-in security                                                                                                 |
| [Amazon ElastiCache(opens in a new tab)](https://aws.amazon.com/elasticache/)                                         | An in-memory caching service that supports Redis, Valkey, or Memcached to improve application performance through faster data retrieval                                                                     |
| [Amazon DocumentDB(opens in a new tab)](https://aws.amazon.com/documentdb/)                                           | A MongoDB-compatible document database service designed for mission-critical workloads with automatic scaling                                                                                               |
| [Amazon Backup(opens in a new tab)](https://aws.amazon.com/backup/)                                                   | A centralized service for automating and managing data backups across AWS services and on-premises resources                                                                                                |
| [Amazon Neptune(opens in a new tab)](https://aws.amazon.com/neptune/)                                                 | A graph database service optimized for storing and querying highly connected data relationships                                                                                                             |
| [What Is a Relational Database?(opens in a new tab)](https://aws.amazon.com/relational-database/)                     | A structured database using tables with predefined schemas, supporting complex queries and transactions through SQL for consistent data relationships                                                       |
| [What Is a NoSQL Database?(opens in a new tab)](https://aws.amazon.com/nosql/)                                        | A nonrelational database offering flexible schemas and high scalability for varied data types, optimized for specific data models and patterns                                                              |
| [What Is an In-Memory Caching Service?(opens in a new tab)](https://aws.amazon.com/caching/aws-caching/)              | A high-speed data storage layer using RAM instead of disk storage, delivering microsecond latency for frequently accessed data                                                                              |
| [AWS Shared Responsibility Model(opens in a new tab)](https://aws.amazon.com/compliance/shared-responsibility-model/) | AWS is responsible for security **of** the cloud (infrastructure, hardware, networking, facilities) while customers are responsible for security **in** the cloud (data, configuration, access management). |

### Module 8 - AI/ML and Data Analytics

| [Amazon Comprehend(opens in a new tab)](https://aws.amazon.com/comprehend/)                                                                              | Use natural language processing to extract key insights from documents.                                                                                        |
| :------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Amazon Polly(opens in a new tab)](https://aws.amazon.com/polly/)                                                                                        | Convert text into lifelike speech.                                                                                                                             |
| [Amazon Transcribe(opens in a new tab)](https://aws.amazon.com/transcribe/)                                                                              | Convert speech into text.                                                                                                                                      |
| [Amazon Translate(opens in a new tab)](https://aws.amazon.com/translate/)                                                                                | Translate text into multiple languages.                                                                                                                        |
| [Amazon Kendra(opens in a new tab)](https://aws.amazon.com/kendra/)                                                                                      | Use natural language processing to intelligently query enterprise content.                                                                                     |
| [Amazon Rekognition(opens in a new tab)](https://aws.amazon.com/rekognition/)                                                                            | Identify objects and activities in images and videos.                                                                                                          |
| [Amazon Textract(opens in a new tab)](https://aws.amazon.com/textract/)                                                                                  | Detect and extract typed and handwritten text in documents.                                                                                                    |
| [Amazon Lex(opens in a new tab)](https://aws.amazon.com/lex/)                                                                                            | Add voice and text conversational interfaces to applications.                                                                                                  |
| [Amazon Personalize(opens in a new tab)](https://aws.amazon.com/personalize/)                                                                            | Add personalized customer recommendations to applications.                                                                                                     |
| [Amazon SageMaker AI(opens in a new tab)](https://aws.amazon.com/sagemaker-ai/)                                                                          | Build, train, and deploy your own ML models without worrying about infrastructure.                                                                             |
| [Amazon SageMaker JumpStart(opens in a new tab)](https://aws.amazon.com/sagemaker-ai/jumpstart/)                                                         | Deploy pre-trained ML solutions, like computer vision, NLP, and tabular data, with just a few clicks.                                                          |
| [Amazon Bedrock(opens in a new tab)](https://aws.amazon.com/bedrock/)                                                                                    | Fine-tune and seamlessly integrate large FMs from Amazon and leading AI startups into your AWS applications with a single API.                                 |
| [Amazon Q Business(opens in a new tab)](https://aws.amazon.com/q/business/)                                                                              | Answer questions and solve problems using the data and expertise found in your company's information repositories.                                             |
| [Amazon Q Developer(opens in a new tab)](https://aws.amazon.com/q/developer/)                                                                            | Accelerate development with code recommendations.                                                                                                              |
| [Amazon Kinesis Data Streams(opens in a new tab)](https://aws.amazon.com/kinesis/data-streams/)                                                          | Ingest terabytes of streaming data in real time.                                                                                                               |
| [Amazon Data Firehose(opens in a new tab)](https://aws.amazon.com/firehose/)                                                                             | Ingest and deliver data within seconds to multiple consumers, such as data lakes and warehouses.                                                               |
| [Amazon S3(opens in a new tab)](https://aws.amazon.com/s3/)                                                                                              | Store virtually limitless amounts of all types of data using this popular data lake choice.                                                                    |
| [Amazon Redshift(opens in a new tab)](https://aws.amazon.com/redshift/)                                                                                  | Store petabytes of structured or semistructured data in this data warehouse service. Analyze large datasets stored in the warehouse using complex SQL queries. |
| [AWS Glue Data Catalog(opens in a new tab)](https://docs.aws.amazon.com/prescriptive-guidance/latest/serverless-etl-aws-glue/aws-glue-data-catalog.html) | Provide metadata to various analytics services with this centralized repository.                                                                               |
| [AWS Glue(opens in a new tab)](https://aws.amazon.com/glue/)                                                                                             | Process data by using the AWS Glue Data Catalog as a reference.                                                                                                |
| [Amazon EMR(opens in a new tab)](https://aws.amazon.com/emr/)                                                                                            | Process big data workloads by using popular frameworks like Apache Spark.                                                                                      |
| [Amazon Athena(opens in a new tab)](https://aws.amazon.com/athena/)                                                                                      | Analyze various data sources hosted anywhere with a single SQL query.                                                                                          |
| [Amazon QuickSight(opens in a new tab)](https://aws.amazon.com/quicksight/)                                                                              | Visualize data by creating interactive dashboards with or without expertise.                                                                                   |
| [Amazon OpenSearch Service(opens in a new tab)](https://aws.amazon.com/opensearch-service/)                                                              | Visualize and monitor real-time data analytics with keyword or NLP searches.                                                                                   |

### Module 9 - Security

| Resource link                                                                                    | Description                                                                                             |
| :----------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------ |
| [AWS Identity and Access Management (IAM)(opens in a new tab)](https://aws.amazon.com/iam/)      | Securely manage identities and access to AWS services and resources.                                    |
| [AWS IAM Identity Center(opens in a new tab)](https://aws.amazon.com/iam/identity-center/)       | Connect your existing workforce identity source and centrally manage access to AWS with single sign-on. |
| [AWS Secrets Manager(opens in a new tab)](https://aws.amazon.com/secrets-manager/)               | Centrally store and manage credentials, API keys, and other secrets.                                    |
| [AWS Systems Manager(opens in a new tab)](https://aws.amazon.com/systems-manager/)               | Manage nodes, or connection points, at scale on AWS and in multi-cloud and hybrid environments.         |
| [AWS Shield(opens in a new tab)](https://aws.amazon.com/shield/)                                 | Protect your network and applications from the most common, frequently occurring types of DDoS attacks. |
| [AWS WAF(opens in a new tab)](https://aws.amazon.com/waf/)                                       | Protect your network and applications from blocked IP addresses defined by a web ACL.                   |
| [AWS Key Management Service (AWS KMS)(opens in a new tab)](https://aws.amazon.com/kms/)          | Create and manage cryptographic keys to encrypt and decrypt your data.                                  |
| [Amazon Macie(opens in a new tab)](https://aws.amazon.com/macie/)                                | Certify that sensitive data is discovered and protected in Amazon S3.                                   |
| [AWS Certificate Manager (ACM)(opens in a new tab)](https://aws.amazon.com/certificate-manager/) | Create and manage SSL/TLS certificates that provide data encryption in transit.                         |
| [Amazon Inspector(opens in a new tab)](https://aws.amazon.com/inspector/)                        | Check applications for security vulnerabilities and deviations from security best practices.            |
| [Amazon GuardDuty(opens in a new tab)](https://aws.amazon.com/guardduty/)                        | Continuously monitor the AWS environment with intelligent threat detection.                             |
| [Amazon Detective(opens in a new tab)](https://aws.amazon.com/detective/)                        | Analyze threats with interactive visualizations contained in a unified view.                            |
| [AWS Security Hub(opens in a new tab)](https://aws.amazon.com/security-hub/)                     | Aggregate security findings and organize them into actionable insights.                                 |

### Module 10 - Monitoring, Compliance, and Governance in the AWS Cloud

| Resource link                                                                                                         | Description                                                                                                                                                                                                                                                                                               |
| :-------------------------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Amazon CloudWatch(opens in a new tab)](https://aws.amazon.com/cloudwatch/)                                           | CloudWatch monitors your AWS resources and the applications you run on AWS in real time. With CloudWatch, you gain system-wide visibility into resource utilization, application performance, and operational health.                                                                                     |
| [AWS CloudTrail(opens in a new tab)](https://aws.amazon.com/cloudtrail/)                                              | CloudTrail enables auditing, security monitoring, and operational troubleshooting. CloudTrail records user activity and API calls across AWS services as events. CloudTrail events help you answer the question of "Who did what, where, and when?"                                                       |
| [AWS Artifact(opens in a new tab)](https://aws.amazon.com/artifact/)                                                  | AWS Artifact a self-service portal that provides on-demand access to AWS security and compliance documentation, including reports, certifications, and agreements.                                                                                                                                        |
| [AWS Config(opens in a new tab)](https://aws.amazon.com/config/)                                                      | AWS Config is a service to assess, audit, and evaluate the configurations of your AWS resources.                                                                                                                                                                                                          |
| [AWS Audit Manager(opens in a new tab)](https://aws.amazon.com/audit-manager/)                                        | Audit Manager is a service to continually audit your AWS usage to streamline risk and compliance assessment.                                                                                                                                                                                              |
| [AWS Organizations(opens in a new tab)](https://aws.amazon.com/organizations/)                                        | Organizations helps you centrally manage and govern your environment as you grow and scale your AWS resources. It helps you manage policies for groups of accounts and automate account creation.                                                                                                         |
| [AWS Control Tower(opens in a new tab)](https://aws.amazon.com/controltower/)                                         | With AWS Control Tower, you can enforce and manage governance rules for security, operations, and compliance at scale across all your organizations and accounts in the AWS Cloud.                                                                                                                        |
| [AWS Service Catalog(opens in a new tab)](https://aws.amazon.com/servicecatalog/)                                     | With Service Catalog, you can create, share, and organize from a curated catalog of AWS resources. You can deploy baseline networking resources and security tools for new AWS accounts so you can govern consistently.                                                                                   |
| [AWS License Manager(opens in a new tab)](https://aws.amazon.com/license-manager/)                                    | License Manager is a service that helps you manage your software licenses and fine-tune your licensing costs.                                                                                                                                                                                             |
| [AWS Trusted Advisor(opens in a new tab)](https://aws.amazon.com/premiumsupport/technology/trusted-advisor/)          | Trusted Advisor helps you optimize costs, increase performance, improve security and resilience, and operate at scale in the cloud. It continuously evaluates your AWS environment using best practice checks across those categories and recommends actions to remediate deviations from best practices. |
| [AWS Health(opens in a new tab)](https://aws.amazon.com/premiumsupport/technology/aws-health/)                        | AWS Health is the data source for events and changes affecting your AWS Cloud resources. AWS Health notifies you about service events, planned changes, and account notifications to help you manage and take actions.                                                                                    |
| [AWS Identity and Access Management Access Analyzer(opens in a new tab)](https://aws.amazon.com/iam/access-analyzer/) | IAM Access Analyzer provides capabilities to set, verify, and refine security permissions to achieve least privilege security standards.                                                                                                                                                                  |

### Module 11 - Pricing and Support

| Resource link                                                                                                                                                                                                                                                                                  | Description                                                                                                                                                                                                                            |
| :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Amazon S3 Pricing(opens in a new tab)](https://aws.amazon.com/s3/pricing/?nc=sn&loc=4)                                                                                                                                                                                                        | The Amazon S3 Pricing page outlines costs for storage, requests, data transfer, and additional features, along with details on AWS Free Tier for new customers.                                                                        |
| [Amazon EC2 On-Demand Pricing(opens in a new tab)](https://aws.amazon.com/ec2/pricing/on-demand/)                                                                                                                                                                                              | The Amazon EC2 On-Demand Pricing page details the costs for EC2 instances, including pricing for instance types, data transfer, and additional features with no long-term commitments.                                                 |
| [What is AWS Organizations?(opens in a new tab)](https://docs.aws.amazon.com/organizations/latest/userguide/orgs_introduction.html)                                                                                                                                                            | The AWS Organizations User Guide explains how to centrally manage multiple AWS accounts, automate account creation, apply governance policies, and simplify billing and resource sharing.                                              |
| [AWS Billing Console(opens in a new tab)](https://aws.amazon.com/aws-cost-management/aws-billing/)                                                                                                                                                                                             | The AWS Billing Console provides a centralized platform for managing and understanding AWS charges, offering tools to view and download invoices, monitor discounts and credits, and analyze spending trends across multiple accounts. |
| [AWS Budgets(opens in a new tab)](https://aws.amazon.com/aws-cost-management/aws-budgets/)                                                                                                                                                                                                     | AWS Budgets provides tools to create custom budgets for tracking and managing AWS costs, usage, and Reserved Instance or Savings Plan use. It also helps prevent overspending by offering alerts and automated actions.                |
| [AWS Cost Explorer(opens in a new tab)](https://aws.amazon.com/aws-cost-management/aws-cost-explorer/)                                                                                                                                                                                         | AWS Cost Explorer provides tools to visualize, analyze, and manage AWS costs and usage, with customizable reports and cost forecasting to optimize cloud spending.                                                                     |
| [AWS Pricing Calculator Documentation(opens in a new tab)](https://docs.aws.amazon.com/pricing-calculator/)                                                                                                                                                                                    | The AWS Pricing Calculator is a free, web-based tool that helps customers create detailed cost estimates for AWS services, so they can plan and manage their cloud expenditures effectively.                                           |
| [AWS re:Post(opens in a new tab)](https://repost.aws/)                                                                                                                                                                                                                                         | AWS re:Post is a community-driven, question-and-answer platform provided where users can seek help, share knowledge, and find solutions related to AWS services and technologies.                                                      |
| [AWS Trust and Safety Center(opens in a new tab)](https://repost.aws/aws-trust-and-safety)                                                                                                                                                                                                     | The AWS Trust and Safety Center offers guidance on reporting abuse, protecting applications, and following best practices for digital messaging on AWS.                                                                                |
| [AWS Professional Services(opens in a new tab)](https://aws.amazon.com/professional-services/)                                                                                                                                                                                                 | The AWS Professional Services page highlights how AWS experts help organizations accelerate cloud adoption with tailored guidance across industries and technologies.                                                                  |
| [Welcome to AWS Documentation(opens in a new tab)](https://docs.aws.amazon.com/index.html)                                                                                                                                                                                                     | The AWS Documentation page provides comprehensive technical resources, including guides, API references, tutorials, and best practices across AWS services.                                                                            |
| [AWS Marketplace(opens in a new tab)](https://aws.amazon.com/marketplace)                                                                                                                                                                                                                      | The AWS Marketplace is a digital catalog where customers can discover, purchase, and manage third-party software, data, and services with flexible pricing options.                                                                    |
| [Engage with AWS Partners(opens in a new tab)](https://partners.amazonaws.com/)                                                                                                                                                                                                                | The AWS Partners page helps you discover how AWS Partners can help you accelerate your cloud journey.                                                                                                                                  |
| [Funding Benefits for AWS Partners(opens in a new tab)](https://aws.amazon.com/partners/funding/)                                                                                                                                                                                              | The AWS Partner Funding page outlines funding benefits, including credits and discounts, to support AWS partners in developing, marketing, and selling solutions based in AWS.                                                         |
| [AWS Partner Events(opens in a new tab)](https://aws.amazon.com/events/aws-partner-events/?events-master-all.sort-by=item.additionalFields.startDateTime&events-master-all.sort-order=asc&awsf.events-master-type=*all&awsf.events-master-tech-category=*all&awsf.events-master-location=*all) | The AWS Partner Events page lists upcoming webinars, workshops, and in-person events for IT professionals, developers, and business leaders, with options to filter by date, location, and topic.                                      |
| [AWS Partner Training and Certification(opens in a new tab)](https://aws.amazon.com/partners/training/?nc2=sb_pt_pto)                                                                                                                                                                          | The AWS Partner Training page offers courses, certifications, and resources to help AWS Partners build cloud skills across various roles and enhance their expertise.                                                                  |

### Module 12 - Migrating to the AWS Cloud 

| Resource link                                                                                                                                                     | Description                                                                                                                                                                                                                                                                                                                              |
| :---------------------------------------------------------------------------------------------------------------------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Three Phases of Migration(opens in a new tab)](https://docs.aws.amazon.com/prescriptive-guidance/latest/strategy-migration/overview.html)                        | In performing a large-scale migration, there are typically three phases: assess, mobilize, and the last phase, migrate and modernize.                                                                                                                                                                                                    |
| [AWS Cloud Adoption Framework(opens in a new tab)](https://aws.amazon.com/cloud-adoption-framework/)                                                              | AWS CAF is a framework that brings AWS experience and best practices to companies preparing to migrate to the AWS Cloud. The framework provides tools to help accelerate the migration journey, organize resources, and align management during the transition.                                                                          |
| [Seven Migration Strategies (7 Rs)(opens in a new tab)](https://docs.aws.amazon.com/prescriptive-guidance/latest/large-migration-guide/migration-strategies.html) | When migrating to the cloud, there are seven common migration strategies that customers can choose to implement. They are relocate, rehost, replatform, refactor, repurchase, retain, and retire.                                                                                                                                        |
| [Migration Evaluator(opens in a new tab)](https://aws.amazon.com/migration-evaluator/)                                                                            | The Migration Evaluator is a migration assessment service that helps you create a business case for AWS Cloud planning and migration. It does this with a data-driven approach, analyzing your current state and target state, and developing a migration readiness plan with projected cloud costs.                                     |
| [AWS Application Discovery Service(opens in a new tab)](https://aws.amazon.com/application-discovery/)                                                            | Application Discovery Service discovers on-premises server inventory and connections. It gathers configuration, performance, and connection details for both servers and databases to create a detailed migration plan.                                                                                                                  |
| [AWS Application Migration Service(opens in a new tab)](https://aws.amazon.com/application-migration-service/)                                                    | Application Migration Service is a tool to migrate and improve your on-premises and cloud-based applications. It helps customers simplify, expedite, and reduce the cost of migrating and modernizing applications.                                                                                                                      |
| [AWS Migration Hub(opens in a new tab)](https://aws.amazon.com/migration-hub/)                                                                                    | Migration Hub is a centralized hub to take you from discovery to assessment, planning, and implementation of your migration. It provides tools, guidance, and automated recommendations to collaborate with your team and track your migration.                                                                                          |
| [AWS Database Migration Service (AWS DMS)(opens in a new tab)](https://aws.amazon.com/dms/?nc=sn&loc=1)                                                           | AWS DMS makes it possible to quickly and securely migrate databases to the AWS Cloud. It provides a way to plan, assess, convert, and migrate databases even with data warehouses in one central tool.                                                                                                                                   |
| [AWS Schema Conversion Tool (AWS SCT)(opens in a new tab)](https://docs.aws.amazon.com/SchemaConversionTool/latest/userguide/CHAP_Welcome.html)                   | AWS SCT is a service that makes it possible to convert database schemas and code objects (like stored procedures, views, and functions) from one database engine to another.                                                                                                                                                             |
| [AWS DataSync(opens in a new tab)](https://aws.amazon.com/datasync/)                                                                                              | DataSync is specifically designed for automating and accelerating secure data migrations. DataSync manages data movement workloads with bandwidth throttling, migration scheduling, task filtering, and task reporting. It also provides rapid data replication.                                                                         |
| [AWS Transfer Family(opens in a new tab)](https://aws.amazon.com/aws-transfer-family/)                                                                            | Transfer family makes it possible to seamlessly manage and share data with simple, secure, and scalable file transfers. This service provides fully managed support for secure file transfers over SFTP, FTPS, FTP, and others. It helps you transfer files directly into and out of AWS storage services like Amazon S3 and Amazon EFS. |
| [AWS Direct Connect(opens in a new tab)](https://aws.amazon.com/directconnect/)                                                                                   | Direct Connect is a cloud service that you can use to establish a private, dedicated network connection between your on-premises network and AWS.                                                                                                                                                                                        |
| [AWS Snow Family(opens in a new tab)](https://docs.aws.amazon.com/snowball/latest/developer-guide/device-differences.html)                                        | AWS Snowball Edge Storage Optimized devices are a great solution for offline data migration where connecting to the internet might not be an option. Snowball Edge Storage Optimized devices deliver high performance storage, and make it possible to simplify multi-petabyte data migrations from on-premises locations to AWS.        |

### Module 13 - Well-Architected Solution 

| Resource link                                                                                                                                                                                                                                                                        | Description                                                                                                                                                                                                                     |
| :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| [AWS CodeBuild(opens in a new tab)](https://aws.amazon.com/codebuild/)                                                                                                                                                                                                               | Build scripts for compiling, testing, and packaging your code.                                                                                                                                                                  |
| [AWS CodePipeline(opens in a new tab)](https://aws.amazon.com/codepipeline/)                                                                                                                                                                                                         | Automate and monitor CI/CD pipelines.                                                                                                                                                                                           |
| [AWS X-Ray(opens in a new tab)](https://aws.amazon.com/xray/)                                                                                                                                                                                                                        | Monitor and debug applications.                                                                                                                                                                                                 |
| [AWS AppSync(opens in a new tab)](https://aws.amazon.com/appsync/)                                                                                                                                                                                                                   | Connect applications to multiple data sources using a single GraphQL API request.                                                                                                                                               |
| [AWS Amplify(opens in a new tab)](https://aws.amazon.com/amplify/)                                                                                                                                                                                                                   | Quickly develop, deploy, and manage full-stack applications on AWS.                                                                                                                                                             |
| [Amazon Connect(opens in a new tab)](https://aws.amazon.com/connect/)                                                                                                                                                                                                                | Manage customer service operations with artificial intelligence.                                                                                                                                                                |
| [Amazon SES(opens in a new tab)](https://aws.amazon.com/ses/)                                                                                                                                                                                                                        | Use automation to send large volumes of transactional and marketing emails.                                                                                                                                                     |
| [Amazon AppStream 2.0(opens in a new tab)](https://aws.amazon.com/appstream2/)                                                                                                                                                                                                       | Stream cloud-based and desktop applications to users on compatible devices.                                                                                                                                                     |
| [Amazon WorkSpaces(opens in a new tab)](https://aws.amazon.com/workspaces-family/workspaces/)                                                                                                                                                                                        | Provide employees with secure virtual desktops.                                                                                                                                                                                 |
| [Amazon WorkSpaces Secure Browser(opens in a new tab)](https://aws.amazon.com/workspaces-family/secure-browser/)                                                                                                                                                                     | Provide employees with secure access to web-based applications and sites.                                                                                                                                                       |
| [AWS IoT Core(opens in a new tab)](https://aws.amazon.com/iot-core/)                                                                                                                                                                                                                 | Securely connect devices with cloud applications to create IoT solutions.                                                                                                                                                       |
| [AWS Well-Architected(opens in a new tab)](https://aws.amazon.com/architecture/well-architected/)                                                                                                                                                                                    | The AWS Well-Architected Framework provides a structured approach to designing and operating secure, high performing, resilient, and efficient infrastructure for applications and workloads on AWS, guided by six key pillars. |
| [AWS Well-Architected Framework(opens in a new tab)](https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html)                                                                                                                                                      | This website is the official documentation for the AWS Well-Architected Framework.                                                                                                                                              |
| [What is AWS Well-Architected Tool?(opens in a new tab)](https://docs.aws.amazon.com/wellarchitected/latest/userguide/intro.html)                                                                                                                                                    | The AWS Well-Architected Tool provides a consistent process for measuring your architecture using AWS best practices.                                                                                                           |
| [AWS Architecture Center(opens in a new tab)](https://aws.amazon.com/architecture/?cards-all.sort-by=item.additionalFields.sortDate&cards-all.sort-order=desc&awsf.content-type=*all&awsf.methodology=*all&awsf.tech-category=*all&awsf.industries=*all&awsf.business-category=*all) | The AWS Architecture Center provides reference architectures and best practices for building secure, efficient, and scalable solutions on AWS.                                                                                  |
| [AWS Architecture Blog(opens in a new tab)](https://aws.amazon.com/blogs/architecture/)                                                                                                                                                                                              | The AWS Architecture Blog shares technical insights and best practices for building effective solutions on AWS.                                                                                                                 |







## Useful Links:

195 flashcards 

[https://quizlet.com/392359849/aws-cloud-practitioner-exam-questions-flash-cards/?i=2u6uqa&x=1jqY](https://quizlet.com/392359849/aws-cloud-practitioner-exam-questions-flash-cards/?i=2u6uqa&x=1jqY)

Free content 

[https://www.w3schools.com/aws/index.php](https://www.w3schools.com/aws/index.php)

A summary

[https://sathittham.medium.com/aws-cloud-practitioner-certification-cheat-sheet-1191b36137a8](https://sathittham.medium.com/aws-cloud-practitioner-certification-cheat-sheet-1191b36137a8)

Exam samples Github

[https://github.com/kananinirav/AWS-Certified-Cloud-Practitioner-Notes/tree/master#](https://github.com/kananinirav/AWS-Certified-Cloud-Practitioner-Notes/tree/master#)

Architecture Diagramming

[https://icepanel.io/software-architecture-diagramming](https://icepanel.io/software-architecture-diagramming)

