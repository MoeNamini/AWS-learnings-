---
type: Project
title: AWS Cloud Quest
description: null
tags: [AWS]
status: null
timeFrame: null
collaborators: null
toDoLists: []
ideas: []
---




# Resources 

## Storage 

### S3

First quest, s3 for static website 

website-bucket-b1ee71d0-c6f0

Bucket website Endpoint: [http://website-bucket-b1ee71d0-c6f0.s3-website-us-east-1.amazonaws.com](http://website-bucket-b1ee71d0-c6f0.s3-website-us-east-1.amazonaws.com)



















