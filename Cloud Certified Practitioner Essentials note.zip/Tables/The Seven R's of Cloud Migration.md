---
type: Table
title: The Seven R's of Cloud Migration
description: null
icon: null
tags: []
coverImage: null
---

| **Strategy (The R)** | **Simple Action**           | **Description**                                                                                                                                                   | **Real-World Example**                                                                                                                                                                           |
| :------------------- | :-------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Rehost**           | **Lift and Shift**          | Moving an application **as-is** from an on-premises server to an EC2 instance. No code changes are made.                                                          | Using **AWS Application Migration Service (AWS MGN)** to move a legacy **Windows CRM application** directly onto an **EC2 VM** to quickly exit a data center.                                    |
| **Relocate**         | **Hypervisor Shift**        | Moving virtual machines or containers from an on-premises virtualization platform to a compatible managed service in AWS.                                         | Moving a fleet of virtual servers running on **VMware vSphere** in a company data center to **VMware Cloud on AWS (VMC)**, maintaining all existing operational tools.                           |
| **Replatform**       | **Lift, Tinker, and Shift** | Moving an application but making **minor cloud optimizations** to gain some benefits without touching core code.                                                  | Migrating an **on-premises MySQL database** to **Amazon RDS for MySQL**. The application code stays the same, but the operations team no longer manages patching, backups, or high availability. |
| **Refactor**         | **Rearchitect**             | **Writing new code** and fundamentally changing the application's architecture to fully utilize cloud-native features.                                            | Breaking down a **monolithic application** into separate **microservices** using containers (**Amazon ECS/EKS**) or serverless functions (**AWS Lambda**) to enable agility and scale.           |
| **Repurchase**       | **Drop and Shop**           | **Ending a license** for an existing software application and **replacing it** with a new cloud-native SaaS solution.                                             | Replacing an outdated, on-premises **Exchange email server** with a subscription to a cloud-based service like **Microsoft 365** or **Google Workspace**.                                        |
| **Retain**           | **Stay Where It Lays**      | Deciding **not to migrate** an application because it is not strategic, will be decommissioned soon, or requires a critical hardware dependency that cannot move. | An application is scheduled to be **retired in six months** after a new system is fully launched, so the business decides to **leave it on-premises** until the final sunset date.               |
| **Retire**           | **Turn Off**                | Decommissioning applications that are no longer being used or are redundant.                                                                                      | Discovering that **15% of the IT portfolio** consists of unused "zombie" servers and applications from old projects, which are then **permanently shut down** to realize immediate cost savings. |


### Notes


