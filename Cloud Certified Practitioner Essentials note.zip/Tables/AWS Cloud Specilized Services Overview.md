---
type: Table
title: AWS Cloud Specilized Services Overview
description: null
icon: null
tags: []
coverImage: null
---

| **Service Name**                      | **Category / Focus**        | **Primary Function**                                                                                         | **Key Benefit / Distinction**                                                                                                       |
| :------------------------------------ | :-------------------------- | :----------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------- |
| **AWS CodePipeline**                  | **CI/CD Automation**        | Fully managed service that **automates and orchestrates** the entire release workflow (build, test, deploy). | It is the **orchestrator** that streamlines the software release process without managing servers.                                  |
| **AWS CodeBuild**                     | **CI/CD Automation**        | Compiles source code, runs tests, and produces deployable software packages.                                 | It is the **executor** that automatically scales to run the build task, and you only pay for the time used.                         |
| **AWS X-Ray**                         | **Monitoring & Debugging**  | Provides **tracing, debugging, and performance analysis** across distributed applications.                   | Helps developers quickly identify **performance bottlenecks** and optimize application behavior.                                    |
| **AWS AppSync**                       | **API Development**         | Fully managed **GraphQL service** for creating a single API endpoint.                                        | Securely accesses, manipulates, and **combines data from multiple data sources** in one query.                                      |
| **AWS Amplify**                       | **Application Development** | Streamlines the process of **developing, deploying, and managing** secure, scalable full-stack applications. | Quick way to add features like authentication, storage, and hosting with **minimal infrastructure management**.                     |
| **Amazon Connect**                    | **Business Application**    | AI-powered **contact center service** that is easily set up and scaled.                                      | Provides call routing, recording, analytics, and seamless integration for **customer service operations**.                          |
| **Amazon Simple Email Service (SES)** | **Business Application**    | Scalable and cost-effective **email service provider** for high-volume automation.                           | Optimizes the delivery of transactional and marketing emails to enhance **customer engagement**.                                    |
| **Amazon AppStream 2.0**              | **End-User Computing**      | Fully managed service that **streams applications** from the cloud to any compatible device.                 | Provides instant access to powerful software (including converted SaaS) **without the need for high-end local hardware**.           |
| **Amazon WorkSpaces**                 | **End-User Computing**      | Fully managed **cloud-based desktop computing service**.                                                     | Provides employees with a secure, managed virtual **work environment** accessible from any device.                                  |
| **WorkSpaces Secure Browser**         | **End-User Computing**      | Fully managed **remote enterprise browser** for employees.                                                   | Provides a protected environment to access private websites and SaaS apps **without managing VPNs or specialized client software**. |
| **AWS IoT Core**                      | **IoT Services**            | Managed cloud service to **securely connect physical devices** with cloud applications.                      | Streamlines the complex process of **ingesting, processing, and acting on device data** (e.g., smart cameras, feeders, irrigation). |


### Notes


