---
type: Table
title: AWS CloudTrail vs. Amazon CloudWatch
description: null
icon: null
tags: [AWS]
coverImage: null
---

| **Feature**               | **AWS CloudTrail**                                                                                               | **Amazon CloudWatch**                                                                                                     |
| :------------------------ | :--------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------ |
| **Primary Focus**         | **Governance, Auditing, and Compliance**                                                                         | **Operational Health, Performance, and Monitoring**                                                                       |
| **Data Collected**        | **API Activity Logs** (User actions, console sign-ins, service calls).                                           | **Metrics** (CPU, latency, disk I/O), **Application Logs**, and **Events**.                                               |
| **Key Question Answered** | **Who** made the call? **When** did they do it? **What** resource was changed?                                   | **What** is the CPU utilization? **How fast** is the application responding? **Are there errors?**                        |
| **Data Granularity**      | Detailed log of **every action** (not aggregated).                                                               | **Aggregated Metrics** (e.g., 1-minute or 5-minute intervals).                                                            |
| **Data Latency**          | **Higher Latency** (Events delivered typically within a few minutes, suitable for historical analysis/auditing). | **Near Real-time** (Metrics as frequently as every minute or second, critical for instantaneous alerting).                |
| **Core Use Cases**        | Forensic analysis, security incident investigation, regulatory compliance reporting (HIPAA, SOC 2).              | Setting performance alarms, auto-scaling triggers, dashboard visualization, and application troubleshooting.              |
| **Default Retention**     | Event history retained for **90 days**; infinite retention requires custom **S3 Trail**.                         | Metrics retained for **15 months**; Logs retained for a configurable period (default is often "Never Expire" or 30 days). |


### Notes


