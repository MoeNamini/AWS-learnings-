---
type: Image
title: CodeBuild
description: null
createdAt: '2025-11-19T17:36:28.850Z'
creationDate: 2025-11-19 21:06
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 16871
width: 512
height: 512
---


Media: ![Image](Images/Media/CodeBuild.png)


