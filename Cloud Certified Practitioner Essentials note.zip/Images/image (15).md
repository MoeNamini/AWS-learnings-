---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:31:25.506Z'
creationDate: 2025-11-11 14:01
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 177834
width: 1680
height: 576
---


Media: ![Image](Images/Media/image%20(15).png)


