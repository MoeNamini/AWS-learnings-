---
type: Image
title: icon_AmazonDynamoDB
description: null
createdAt: '2025-11-15T09:47:56.497Z'
creationDate: 2025-11-15 13:17
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 4794
width: 481
height: 481
---


Media: ![Image](Images/Media/icon_AmazonDynamoDB.svg)


