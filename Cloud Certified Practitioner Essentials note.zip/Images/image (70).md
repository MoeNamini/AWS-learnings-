---
type: Image
title: image
description: null
createdAt: '2025-11-17T12:57:15.503Z'
creationDate: 2025-11-17 16:27
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 89656
width: 512
height: 512
---


Media: ![Image](Images/Media/image%20(70).png)


