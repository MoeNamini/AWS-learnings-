---
type: Image
title: image
description: null
createdAt: '2025-11-09T11:58:26.815Z'
creationDate: 2025-11-09 15:28
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 367522
width: 1148
height: 720
---


Media: ![Image](Images/Media/image%20(1).png)


