---
type: Image
title: image
description: null
createdAt: '2025-11-19T15:25:08.458Z'
creationDate: 2025-11-19 18:55
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 14602
width: 479
height: 479
---


Media: ![Image](Images/Media/image%20(114).png)


