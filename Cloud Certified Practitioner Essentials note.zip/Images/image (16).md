---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:39:15.371Z'
creationDate: 2025-11-11 14:09
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 451994
width: 1680
height: 1273
---


Media: ![Image](Images/Media/image%20(16).png)


