---
type: Image
title: icon_AWSBackup
description: null
createdAt: '2025-11-15T15:26:09.937Z'
creationDate: 2025-11-15 18:56
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 4553
width: 486
height: 481
---


Media: ![Image](Images/Media/icon_AWSBackup.svg)


