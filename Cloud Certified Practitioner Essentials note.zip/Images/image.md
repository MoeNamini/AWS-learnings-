---
type: Image
title: image
description: null
createdAt: '2025-11-17T08:09:39.719Z'
creationDate: 2025-11-17 11:39
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 531869
width: 1680
height: 870
---


Media: ![Image](Images/Media/image.png)


