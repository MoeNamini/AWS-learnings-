---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:19:59.698Z'
creationDate: 2025-11-11 13:49
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 370813
width: 2331
height: 1034
---


Media: ![Image](Images/Media/image%20(13).png)


