---
type: Image
title: image
description: null
createdAt: '2025-11-19T09:29:34.523Z'
creationDate: 2025-11-19 12:59
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 238909
width: 1680
height: 683
---


Media: ![Image](Images/Media/image%20(103).png)


