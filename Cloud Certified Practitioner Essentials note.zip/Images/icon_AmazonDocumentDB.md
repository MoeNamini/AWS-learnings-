---
type: Image
title: icon_AmazonDocumentDB
description: null
createdAt: '2025-11-15T15:20:06.197Z'
creationDate: 2025-11-15 18:50
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 4234
width: 481
height: 481
---


Media: ![Image](Images/Media/icon_AmazonDocumentDB.svg)


