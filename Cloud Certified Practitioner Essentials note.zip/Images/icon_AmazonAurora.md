---
type: Image
title: icon_AmazonAurora
description: null
createdAt: '2025-11-14T17:59:32.666Z'
creationDate: 2025-11-14 21:29
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 3257
width: 481
height: 481
---


Media: ![Image](Images/Media/icon_AmazonAurora.svg)


