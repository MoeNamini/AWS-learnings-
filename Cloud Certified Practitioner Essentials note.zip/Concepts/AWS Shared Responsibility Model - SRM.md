---
type: Concept
title: AWS Shared Responsibility Model - SRM
modificationDate: 2025-11-18 14:29
tags: [AWS]
relatedProject: []
relatedIdeas: []
---







## Databases

**Fully managed services**

---

For fully managed services, AWS handles nearly all operational tasks like provisioning, scaling, patching, backups, performance optimization, and security patches. AWS also provides built-in monitoring and metrics. Fully managed AWS database services only require customers to be responsible for designing data structures and managing access controls.


---

![infographic_servicesFullyManaged-crop](Images/Media/infographic_servicesFullyManaged-crop.png)
[infographic_servicesFullyManaged-crop](Images/infographic_servicesFullyManaged-crop.md)

---

**Managed services**

---

With managed database services, AWS handles routine tasks like backups, patching, and hardware provisioning while customers are responsible for database configuration, query optimization, and performance tuning decisions.


---

![infographic_servicesManaged-crop](Images/Media/infographic_servicesManaged-crop.png)
[infographic_servicesManaged-crop](Images/infographic_servicesManaged-crop.md)

---



**Unmanaged services**

---

With unmanaged databases, customers are responsible for installation, configuration, patching, maintenance tasks, database security, backups, high availability setup, and performance optimization. An example of an unmanaged database in AWS would be a database management system like MySQL installed directly on an Amazon Elastic Compute Cloud (Amazon EC2) instance.


---

![infographic_servicesUnmanaged-crop](Images/Media/infographic_servicesUnmanaged-crop.png)
[infographic_servicesUnmanaged-crop](Images/infographic_servicesUnmanaged-crop.md)

---

## Security 

### AWS shared responsibility model

Cloud security is a shared responsibility between customers and AWS. Let's examine this relationship using the AWS shared responsibility model.

**Customers: Security** ***in*** **the cloud**

When using AWS services, customers maintain complete control over their content. As a result, customers are responsible for securing everything they create and manage in the AWS Cloud. This includes the following:

- Managing the security of data, systems, and applications

- Deciding what data and workloads to store or run in AWS

- Determining which AWS services to use

- Controlling who has access to environments and resources

**AWS: Security** ***of*** **the cloud**

AWS is responsible for security *of* the cloud. AWS operates, manages, and controls the components at all layers of the infrastructure. This includes securing the following:

- The foundational software that powers AWS services

- The virtualization layer

- The hardware and global infrastructure that supports the data centers from which services operate. This includes protection for AWS Regions, Availability Zones, and edge locations.

![image](Images/Media/image.png)
[image](Images/image.md)

### AWS security controls

AWS offers multiple security mechanisms to protect your cloud resources. These controls can help you do the following:

- *Prevent* security incidents through proper permission and access management.

- *Protect* networks, applications, and data.

- *Detect and respond* to security incidents as they occur.

