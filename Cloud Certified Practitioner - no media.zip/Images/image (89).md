---
type: Image
title: image
description: null
createdAt: '2025-11-18T10:17:14.053Z'
creationDate: 2025-11-18 13:47
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 78357
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/bb331f7d-0562-4f72-8942-9736913e6e8c/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101715Z&X-Amz-Expires=43200&X-Amz-Signature=1d8c86bf8a2acf1da8c121c9ed59c883709987328ac516bcfeae5511646120a1&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


