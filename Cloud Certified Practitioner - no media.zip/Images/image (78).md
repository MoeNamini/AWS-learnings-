---
type: Image
title: image
description: null
createdAt: '2025-11-17T16:31:46.095Z'
creationDate: 2025-11-17 20:01
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 89758
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/60bf39c4-749b-4b0b-9584-4033ff796f1d/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T163146Z&X-Amz-Expires=43200&X-Amz-Signature=91e36496c29cd1895d6db10be30fe2c5796d3ecc8393521edaed6cec2a56e3b5&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


