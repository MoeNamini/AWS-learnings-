---
type: Image
title: infographic_servicesUnmanaged-crop
description: null
createdAt: '2025-11-12T09:52:17.233Z'
creationDate: 2025-11-12 13:22
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 31013
width: 764
height: 606
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/d8cee99c-8cd3-48b8-ac51-3608e0ebb415/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=2ad735166b13fdd1d78e4525bd73a831e4d1830daa2b853442bb6f73e2906cc2&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


