---
type: Image
title: image
description: null
createdAt: '2025-11-17T08:26:08.365Z'
creationDate: 2025-11-17 11:56
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 82922
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/a264c391-64f2-42c7-ab06-8e1a61e27676/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T082609Z&X-Amz-Expires=43200&X-Amz-Signature=ed1f85999316400bb48d3940f6822182fcdc97d62a4afc2843d21bab4ccde0bc&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


