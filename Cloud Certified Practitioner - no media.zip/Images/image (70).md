---
type: Image
title: image
description: null
createdAt: '2025-11-17T12:57:15.503Z'
creationDate: 2025-11-17 16:27
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 89656
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/8d46c9ec-b4ea-433b-b5bb-63253f0d21a4/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T125716Z&X-Amz-Expires=43200&X-Amz-Signature=49300e835d2e6b89da10d9ec6c86b69c03b783653c1be5f597129ce33edec1b7&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


