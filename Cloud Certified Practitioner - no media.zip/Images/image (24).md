---
type: Image
title: image
description: null
createdAt: '2025-11-12T12:54:37.811Z'
creationDate: 2025-11-12 16:24
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 612001
width: 1663
height: 772
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/3a31e3b6-cc82-4644-9e4d-f19e34c8567f/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=e74fe98389296f92ac9954b7f2ab780bf5d44a9ea14deef462ca7d8c403d97d9&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


