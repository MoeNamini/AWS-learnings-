---
type: Image
title: image
description: null
createdAt: '2025-11-18T16:51:32.648Z'
creationDate: 2025-11-18 20:21
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 69589
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/1889e974-a834-486d-950f-d756aa3e43be/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T165133Z&X-Amz-Expires=43200&X-Amz-Signature=48d2d8d3a0c4a0939dee4bc87eef6ee7c07b7299fa46a0b8c26062af16b54d50&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


