---
type: Image
title: image
description: null
createdAt: '2025-11-16T11:29:12.048Z'
creationDate: 2025-11-16 14:59
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 89658
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/36bf3a5c-dee0-4ade-8c9f-8171802205d7/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080157Z&X-Amz-Expires=43200&X-Amz-Signature=ca288aa4fb334005f37cf88e9754991e9835b3d3a8497c4f965507e11f431088&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


