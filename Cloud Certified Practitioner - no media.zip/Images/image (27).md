---
type: Image
title: image
description: null
createdAt: '2025-11-12T17:07:04.435Z'
creationDate: 2025-11-12 20:37
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 1307699
width: 2558
height: 1252
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/ea4d7b3a-444c-4624-85e9-4988260c5983/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=01b25419c0adc6c23f71baea8add2ed23ca52586c1bbda3a6d2dcd60a2df839a&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


