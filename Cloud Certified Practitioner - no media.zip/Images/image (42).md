---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:44:32.118Z'
creationDate: 2025-11-15 22:14
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 82567
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/d90995c7-7d6f-4c89-b3de-5fb378731cf4/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080156Z&X-Amz-Expires=43200&X-Amz-Signature=2e6fe5fb836b21af60fd1107846eeae0e809a81bea1dbb7b752d532c55250dd6&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


