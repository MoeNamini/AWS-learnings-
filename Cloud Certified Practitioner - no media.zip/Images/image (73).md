---
type: Image
title: image
description: null
createdAt: '2025-11-17T13:19:50.529Z'
creationDate: 2025-11-17 16:49
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 77855
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/70895bed-149d-463d-9245-ee1b3020ec91/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T131951Z&X-Amz-Expires=43200&X-Amz-Signature=cd5a8375c5c6892b3941c3ffb44b086f7336c554a861654df505ca660fb013cc&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


