---
type: Image
title: icon_AmazonDocumentDB
description: null
createdAt: '2025-11-15T15:20:06.197Z'
creationDate: 2025-11-15 18:50
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 4234
width: 481
height: 481
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/3519bfdb-81fc-430f-b13d-c6224a144cc3/raw.svg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T081039Z&X-Amz-Expires=43200&X-Amz-Signature=182f7559ae6f9c1d9b90e0b6b9d5bf4c7b5fe56dc54c04d230388021eb268c5a&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


