---
type: Image
title: M05_L5 CIRL Direct Connect
description: null
createdAt: '2025-11-11T20:58:25.597Z'
creationDate: 2025-11-12 00:28
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 61206
width: 1680
height: 657
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/83b726c8-46bc-4619-8dc8-7b591dbcdd15/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=37305c086045405be8677e66377ae658fff73f0c8d9d821512f39b086cfb83e3&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


