---
type: Image
title: infographic_servicesManaged-crop
description: null
createdAt: '2025-11-14T17:12:09.346Z'
creationDate: 2025-11-14 20:42
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 24052
width: 764
height: 610
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/3954122c-43be-4b32-83f9-14c94910bbeb/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=eff3b8e29cb18ddc00c3e4d54396c8fc1ac61556f7818bd486ffe804b458d8a3&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


