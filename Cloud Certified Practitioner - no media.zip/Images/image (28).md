---
type: Image
title: image
description: null
createdAt: '2025-11-17T08:09:39.719Z'
creationDate: 2025-11-17 11:39
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 531869
width: 1680
height: 870
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/220bfb1b-ec8f-49db-aecc-a23ecc594b06/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T105924Z&X-Amz-Expires=43200&X-Amz-Signature=27eaced6d0398ee236e273d955b5c8344e76d0917ea15c394980523bb0f24c8f&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


