---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:22:00.208Z'
creationDate: 2025-11-11 13:52
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 459005
width: 2404
height: 1096
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/fca8b48e-cce0-4b42-a29c-de692ff04011/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251111%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251111T102201Z&X-Amz-Expires=43200&X-Amz-Signature=7d89780ca2768a68fac02f9447bfba53db7036fbc1b69b623185187b75160ec8&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


