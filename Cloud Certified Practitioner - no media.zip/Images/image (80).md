---
type: Image
title: image
description: null
createdAt: '2025-11-17T19:43:56.509Z'
creationDate: 2025-11-17 23:13
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 80537
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/4e340bd9-7aa0-4348-9f34-049311623e44/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T144740Z&X-Amz-Expires=43200&X-Amz-Signature=5c5f3b7dbd0eb139cbb595ce887fe7b46504a659f733d84033f2d102fd9238ba&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


