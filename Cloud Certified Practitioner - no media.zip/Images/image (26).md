---
type: Image
title: image
description: null
createdAt: '2025-11-12T16:28:00.846Z'
creationDate: 2025-11-12 19:58
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 36110
width: 803
height: 232
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/be182e72-c207-4190-85be-7a6c095d5c32/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=fa01f41260e87752c92b682cfe11d8ad6cea7462f7e091f01448a7ae392b0b3f&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


