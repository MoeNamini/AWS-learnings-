---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:25:10.436Z'
creationDate: 2025-11-16 21:55
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 16232
width: 400
height: 400
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/28c59498-22cc-4953-a841-61485c51c84a/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T182511Z&X-Amz-Expires=43200&X-Amz-Signature=6ba217f89573f5b60ea09ebdcb2b57107156aa3948fdc36ff1f27c123cff546f&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


