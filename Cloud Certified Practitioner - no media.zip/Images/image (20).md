---
type: Image
title: image
description: null
createdAt: '2025-11-11T15:55:27.034Z'
creationDate: 2025-11-11 19:25
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 262631
width: 1680
height: 699
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/02e283ef-aa57-4026-bc4a-96eda4474024/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=17035d85409d1cfa3e84a2db60095738174b0c2ae709b5f832f45627fd1fb8f0&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


