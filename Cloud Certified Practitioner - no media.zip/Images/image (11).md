---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:09:08.075Z'
creationDate: 2025-11-11 13:39
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 306386
width: 1680
height: 875
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/f2287ef0-723f-4161-b417-d0a7937e5817/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251111%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251111T100909Z&X-Amz-Expires=43200&X-Amz-Signature=8c2f982d25eddffb18017fee69fe9ecb88bf09df5fb6dbe59cc1ffd04d397723&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


