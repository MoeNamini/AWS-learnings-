---
type: Image
title: image
description: null
createdAt: '2025-11-15T10:24:04.387Z'
creationDate: 2025-11-15 13:54
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 132285
width: 627
height: 359
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/0c94763e-c775-4729-ab3e-e20ebc66354c/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101024Z&X-Amz-Expires=43200&X-Amz-Signature=d19765a2ab11bec4f71ce0f698347f585ef811de74e7def0b57fa11c2eceb907&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


