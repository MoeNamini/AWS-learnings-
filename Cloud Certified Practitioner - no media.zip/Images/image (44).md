---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:48:37.373Z'
creationDate: 2025-11-15 22:18
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 87898
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/c23a0b28-1444-4831-a767-79d143ada53a/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080157Z&X-Amz-Expires=43200&X-Amz-Signature=63e376b3a8f05ac69449e62457cdcea9d48bd10da389df6e7f749569b37d1d0d&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


