---
type: Image
title: image
description: null
createdAt: '2025-11-11T17:48:17.631Z'
creationDate: 2025-11-11 21:18
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 337853
width: 1027
height: 4096
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/e627ee4a-14b4-4958-9548-f34e6fc6b232/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=9ea21e1b96709d446d0274624da74bf40b939604f9ec2b9fa9e20687dcaf6038&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


