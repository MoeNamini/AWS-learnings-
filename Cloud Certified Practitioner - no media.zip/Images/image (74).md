---
type: Image
title: image
description: null
createdAt: '2025-11-17T13:22:34.014Z'
creationDate: 2025-11-17 16:52
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 69108
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/80cbb995-333b-4fb2-bbca-0b79516bac95/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T132234Z&X-Amz-Expires=43200&X-Amz-Signature=d4320e9eeca5eef4fa26cd28314f33460b2a4de8d7777553b25cd6101ec0ae56&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


