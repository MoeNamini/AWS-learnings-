---
type: Image
title: image
description: null
createdAt: '2025-11-17T12:49:42.303Z'
creationDate: 2025-11-17 16:19
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 95561
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/43e9ceb2-6f51-45c2-8b33-f6c1450a45e4/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T124943Z&X-Amz-Expires=43200&X-Amz-Signature=31ee429dee2e71c564d7c7686f3f7ec5cc1efce8eca9519684ccb36b65875696&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


