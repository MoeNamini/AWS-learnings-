---
type: Image
title: image
description: null
createdAt: '2025-11-09T13:11:24.674Z'
creationDate: 2025-11-09 16:41
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 34193
width: 774
height: 409
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/3544edcc-33f2-4285-8ec4-55215106977f/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251109%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251109T131125Z&X-Amz-Expires=43200&X-Amz-Signature=385f772880d21c5c50eec1a115bbaee5ad3848e09c02f86064b7cb3db6593192&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


