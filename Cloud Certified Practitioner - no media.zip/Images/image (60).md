---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:31:43.252Z'
creationDate: 2025-11-16 22:01
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 85201
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/5e5ee3d3-697d-4ea5-a2e6-d18da688781d/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T183143Z&X-Amz-Expires=43200&X-Amz-Signature=169ee8d544b1cbdf48c3d7a3cb8c61938ab1d17988148f11203a5044dbc34230&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


