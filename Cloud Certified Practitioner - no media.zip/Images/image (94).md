---
type: Image
title: image
description: null
createdAt: '2025-11-18T16:28:26.204Z'
creationDate: 2025-11-18 19:58
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 377710
width: 1642
height: 801
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/f7c6d846-be38-4f85-8799-9445dad3f282/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T162827Z&X-Amz-Expires=43200&X-Amz-Signature=2aa030eed2e0fefdd15a27ee177ad624e89fe35dc4cceba7d126f62735f19dc9&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


