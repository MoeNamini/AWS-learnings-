---
type: Image
title: image
description: null
createdAt: '2025-11-15T10:20:09.974Z'
creationDate: 2025-11-15 13:50
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 365368
width: 1641
height: 762
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/ea617844-7f9b-4e58-b4f5-aa0e68a03719/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101024Z&X-Amz-Expires=43200&X-Amz-Signature=21f07d229fc1c410476bfc14386b4a6ad1e5d4e8b69021957b9329221f2a0dcb&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


