---
type: Image
title: image
description: null
createdAt: '2025-11-16T11:27:49.354Z'
creationDate: 2025-11-16 14:57
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 15020
width: 400
height: 400
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/b977d4de-8d70-4f06-9fd3-31da9a5ac902/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080157Z&X-Amz-Expires=43200&X-Amz-Signature=37ba6490da3a7399c7ace6955cbde77e56d93713d1aa5a33b945e2021bee21a4&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


