---
type: Image
title: image
description: null
createdAt: '2025-11-17T16:27:23.403Z'
creationDate: 2025-11-17 19:57
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 91011
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/6384bf7c-2807-4a59-aa99-7fd3679a1efc/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T162723Z&X-Amz-Expires=43200&X-Amz-Signature=63cfa835fe0aa1deb8eb04d6fa544874a7114ced2d1bc796da0b31eb1d2a38e7&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


