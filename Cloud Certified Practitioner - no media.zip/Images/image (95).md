---
type: Image
title: image
description: null
createdAt: '2025-11-18T16:51:02.921Z'
creationDate: 2025-11-18 20:21
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 79888
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/60987935-ef2d-46bc-a2e4-3f2a675da9a7/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T165103Z&X-Amz-Expires=43200&X-Amz-Signature=16538bb5cb162ade8ef60054ac59e846a44c19ef58aeb2435e369f25bcf41373&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


