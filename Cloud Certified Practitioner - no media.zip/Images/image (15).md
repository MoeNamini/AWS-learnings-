---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:39:15.371Z'
creationDate: 2025-11-11 14:09
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 451994
width: 1680
height: 1273
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/0d90356f-a11a-420c-840e-1b2ed557681c/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251111%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251111T103916Z&X-Amz-Expires=43200&X-Amz-Signature=50d18ea34116e0c24d637cf7095066733be96923a7c48d99234eaf920c59334b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


