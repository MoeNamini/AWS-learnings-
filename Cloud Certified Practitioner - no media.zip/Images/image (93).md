---
type: Image
title: image
description: null
createdAt: '2025-11-18T16:28:53.591Z'
creationDate: 2025-11-18 19:58
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 502126
width: 1641
height: 811
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/8849ef34-30ea-470c-bcb0-508a0128a4d4/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T162854Z&X-Amz-Expires=43200&X-Amz-Signature=81f51f278cb4d587a2bbfa09e01fa00990044f3bc549da9b6931b58761140065&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


