---
type: Image
title: image
description: null
createdAt: '2025-11-17T13:18:33.644Z'
creationDate: 2025-11-17 16:48
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 72245
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/da0d9c79-ae82-4464-867f-9df397220f90/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T131834Z&X-Amz-Expires=43200&X-Amz-Signature=c8170378744c533814c481615663e6685079f3b00ddd058551643f8ca564d4a6&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


