---
type: Image
title: image
description: null
createdAt: '2025-11-11T20:36:11.380Z'
creationDate: 2025-11-12 00:06
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 184774
width: 1680
height: 625
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/1670bb59-72d8-400c-abdc-397a074e08d3/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=429a0106dcece2076ea5ce4ad630bb27789508bdec48319d5ee6b8c5ee7eabb8&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


