---
type: Image
title: infographic_servicesFullyManaged-crop
description: null
createdAt: '2025-11-12T09:51:39.498Z'
creationDate: 2025-11-12 13:21
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 17298
width: 762
height: 604
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/e806cde1-d9d8-4def-8e2a-409fdbaf2275/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=2a0c46823db3b73ce9575e7066f7903c2ae00730c762c3fd2899b21cb8ca11ca&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


