---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:07:36.190Z'
creationDate: 2025-11-16 21:37
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 98858
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/bbdc3a94-d422-4f65-96c2-ee5b7c84a6f2/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T180736Z&X-Amz-Expires=43200&X-Amz-Signature=be64ff99867d2fb1b0b95dea44deb0843054ca400407067a45600ac617f52ee4&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


