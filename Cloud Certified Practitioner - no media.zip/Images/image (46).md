---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:51:50.719Z'
creationDate: 2025-11-15 22:21
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 81531
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/0498b3d9-5fb6-46a3-b6f2-0a29c570396c/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080156Z&X-Amz-Expires=43200&X-Amz-Signature=69d74cb3023f58ef0e451b63ef73b9b0e12491573ec7c6dcfa410b8da9d85110&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


