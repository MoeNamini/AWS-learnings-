---
type: Image
title: image
description: null
createdAt: '2025-11-17T20:17:41.567Z'
creationDate: 2025-11-17 23:47
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 90181
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/207d7055-1b7f-4508-9dfa-71b735eace6f/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T084615Z&X-Amz-Expires=43200&X-Amz-Signature=8de17027ea4c41da900dd62ed18d778c5b1ecffa557e571edc152dbca72f536b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


