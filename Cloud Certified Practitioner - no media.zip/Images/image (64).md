---
type: Image
title: image
description: null
createdAt: '2025-11-17T08:26:54.069Z'
creationDate: 2025-11-17 11:56
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 118694
width: 1525
height: 675
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/0290afbc-b00c-40aa-a03e-979e05f39530/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T082655Z&X-Amz-Expires=43200&X-Amz-Signature=02de9dd3c3c9ec73e9a9cab55e856e9b9eeeb664014d87f2474959ca0f653f04&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


