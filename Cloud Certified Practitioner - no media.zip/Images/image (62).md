---
type: Image
title: image
description: null
createdAt: '2025-11-17T08:08:50.127Z'
creationDate: 2025-11-17 11:38
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 186780
width: 1299
height: 456
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/717c96fe-9e9e-4c5d-a755-881bf717ee81/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080851Z&X-Amz-Expires=43200&X-Amz-Signature=7692ea85f514ac16b0de10c7e2834563eb07d55c8a98fa803ee328fd31bea38d&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


