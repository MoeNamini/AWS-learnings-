---
type: Image
title: image
description: null
createdAt: '2025-11-15T11:00:53.764Z'
creationDate: 2025-11-15 14:30
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 94241
width: 1086
height: 633
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/bdf609d6-c219-4ac6-9f25-319c0b453b3e/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101024Z&X-Amz-Expires=43200&X-Amz-Signature=02bed53ed10ecba9e45316f036500869c909eef569c0182c03b44056dd4f6dc0&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


