---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:19:36.874Z'
creationDate: 2025-11-15 21:49
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 45286
width: 1330
height: 249
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/b4c486af-e5af-403f-bdd6-679a651e2ba9/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080156Z&X-Amz-Expires=43200&X-Amz-Signature=04522788b4cee49140bb785c4100609b391d9b0b55091155f75118a061223d90&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


