---
type: Image
title: image
description: null
createdAt: '2025-11-17T08:25:07.305Z'
creationDate: 2025-11-17 11:55
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 69864
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/1c7a3850-0b5c-4cf3-8feb-e30fa415108f/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T082508Z&X-Amz-Expires=43200&X-Amz-Signature=59099fa5fc34a1493e79970cf36eefd31c8c7b9a6fd9b63a9468a07d160249cb&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


