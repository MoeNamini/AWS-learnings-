---
type: Image
title: image
description: null
createdAt: '2025-11-15T10:22:35.095Z'
creationDate: 2025-11-15 13:52
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 179318
width: 761
height: 384
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/f8113027-bd2f-4eb6-b20d-00bed968c525/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101024Z&X-Amz-Expires=43200&X-Amz-Signature=4469904ab79d2763b9e614d75689950b7279d3bd651221eaf8f4ae8b30d71e7b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


