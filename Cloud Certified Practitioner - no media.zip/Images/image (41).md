---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:40:01.693Z'
creationDate: 2025-11-15 22:10
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 86067
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/2f5137fe-ce29-4d6f-bd1f-837a59f2c632/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080157Z&X-Amz-Expires=43200&X-Amz-Signature=ae299b3ca2a4eae72db2f67a620d45dbaf6eb0cb475efd3dcc1be7222fe31b7b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


