---
type: Image
title: image
description: null
createdAt: '2025-11-16T19:33:21.592Z'
creationDate: 2025-11-16 23:03
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 22999
width: 400
height: 400
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/d5f047e9-fadd-4567-985d-4c39cf920e4a/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080156Z&X-Amz-Expires=43200&X-Amz-Signature=bd6acf289c129655bb78cdf46e8b3b7014d1915efcd3402bacc99af6733ac99e&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


