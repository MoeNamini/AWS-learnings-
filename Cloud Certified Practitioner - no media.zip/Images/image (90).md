---
type: Image
title: image
description: null
createdAt: '2025-11-18T10:23:10.562Z'
creationDate: 2025-11-18 13:53
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 101841
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/86e17d4d-c831-47ed-b90f-05cfde252c25/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T102311Z&X-Amz-Expires=43200&X-Amz-Signature=696d4567f06134b4ff4462cecf1a29efa908222bed72ec0e910d7fec67937810&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


