---
type: Image
title: image
description: null
createdAt: '2025-11-10T15:53:29.916Z'
creationDate: 2025-11-10 19:23
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 63263
width: 1055
height: 351
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/47181b97-72b0-4c11-b640-efc375a45386/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251110%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251110T155330Z&X-Amz-Expires=43200&X-Amz-Signature=9d49f7aa166d52e5e5d80d2802f4403746578b39c2cae808a71ce25bb9dbdde5&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


