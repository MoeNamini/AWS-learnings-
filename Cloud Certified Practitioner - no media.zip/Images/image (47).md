---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:56:06.089Z'
creationDate: 2025-11-15 22:26
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 89658
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/252d6c61-e54b-4d9f-a87e-d058a951bc65/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080157Z&X-Amz-Expires=43200&X-Amz-Signature=7894b18838eb389212ade1f117218001ab07c0a8dc103016658476acb222ab3a&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


