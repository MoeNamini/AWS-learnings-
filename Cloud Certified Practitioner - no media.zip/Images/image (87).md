---
type: Image
title: image
description: null
createdAt: '2025-11-18T09:50:59.009Z'
creationDate: 2025-11-18 13:20
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 99782
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/fe9edb2c-89f5-44a8-8251-8c3537a7ba08/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T095100Z&X-Amz-Expires=43200&X-Amz-Signature=b137a9a4a90267fcb87bbff00b6d923785a216cecae070128dfedb08a75a4e25&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


