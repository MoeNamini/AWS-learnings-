---
type: Image
title: image
description: null
createdAt: '2025-11-16T19:18:52.120Z'
creationDate: 2025-11-16 22:48
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 268289
width: 1680
height: 1021
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/a99fc942-b6c5-4adf-93f2-3c4f1c1cabc7/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080313Z&X-Amz-Expires=43200&X-Amz-Signature=3cd4c5f38f065e32186dadfae3ca11c76e49275de144ed6b578f00ae679d1c99&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


