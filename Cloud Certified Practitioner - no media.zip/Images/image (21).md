---
type: Image
title: image
description: null
createdAt: '2025-11-11T17:13:20.875Z'
creationDate: 2025-11-11 20:43
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 461189
width: 2432
height: 1240
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/9d131be4-0f1d-4209-8057-e4861b105e17/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=dd19097c2560e81de8a0d74e7d26d02c8b30424b486ea526706ceb451d33acda&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


