---
type: Image
title: infographic_servicesFullyManaged-crop
description: null
createdAt: '2025-11-14T17:12:41.846Z'
creationDate: 2025-11-14 20:42
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 17298
width: 762
height: 604
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/cae5163c-29f0-4d18-934c-f6c4e75a956c/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=c8c173d7245adc11664c516df1d8fea7a2c18674e2e7c6d945e3f3939a3665f0&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


