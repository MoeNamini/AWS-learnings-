---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:23:58.081Z'
creationDate: 2025-11-16 21:53
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 25294
width: 400
height: 400
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/f7e63e46-31ac-415c-a758-e0f8ed879ac1/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T182358Z&X-Amz-Expires=43200&X-Amz-Signature=523743f260482ef63efba70249222b1691dbaaa0c631f1f3d101976dc577e341&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


