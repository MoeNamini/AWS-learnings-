---
type: Image
title: image
description: null
createdAt: '2025-11-18T16:50:52.696Z'
creationDate: 2025-11-18 20:20
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 76806
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/645fb410-9df5-4597-815b-e12df097a804/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T165053Z&X-Amz-Expires=43200&X-Amz-Signature=730dd687cb9a5edcd1c520e9e8e5262ac60188fa13913d31598812d29f304633&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


