---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:30:26.810Z'
creationDate: 2025-11-16 22:00
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 104656
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/62a2b585-ee4e-450d-8c30-1f9bbe534edb/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T183027Z&X-Amz-Expires=43200&X-Amz-Signature=15d2ec4dd2c32cd5df84bae3edec81911ffbd37f1fe2c038606296611e98453a&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


