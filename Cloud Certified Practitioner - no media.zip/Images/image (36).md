---
type: Image
title: image
description: null
createdAt: '2025-11-15T17:52:57.634Z'
creationDate: 2025-11-15 21:22
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 225889
width: 631
height: 517
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/822821bc-c6a6-4084-9933-0b374df89363/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=d1a36611e322bf923c276a5f372f489d515774870ffad8a3df4413a6cb73a6ac&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


