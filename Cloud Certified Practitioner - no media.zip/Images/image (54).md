---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:14:35.046Z'
creationDate: 2025-11-16 21:44
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 19833
width: 500
height: 490
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/a8f79d6a-bcff-479c-8282-2db8f30337a6/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T181435Z&X-Amz-Expires=43200&X-Amz-Signature=710d8ae8c837b441d0e72aec1a53e911028780c3b0508e378f432bcaf8034d43&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


