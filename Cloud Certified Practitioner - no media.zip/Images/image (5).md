---
type: Image
title: image
description: null
createdAt: '2025-11-09T18:00:18.688Z'
creationDate: 2025-11-09 21:30
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 243405
width: 1632
height: 1059
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/45671c25-d48b-4eee-b34c-67cf15291e33/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251109%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251109T180019Z&X-Amz-Expires=43200&X-Amz-Signature=b68fc4e0b6d52a56760eaac142f9df2db5b90194324c38b297e8e3e2398af002&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


