---
type: Image
title: infographic_servicesUnmanaged-crop
description: null
createdAt: '2025-11-14T17:12:58.562Z'
creationDate: 2025-11-14 20:42
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 31013
width: 764
height: 606
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/9c5ef7dd-2bd6-45ff-812f-74fdfb265326/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=b81c00d1add80f267c65453522b8e9a2257186288f18a6238714d7d56458e57f&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


