---
type: Image
title: image
description: null
createdAt: '2025-11-17T19:35:50.290Z'
creationDate: 2025-11-17 23:05
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 95961
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/3b036b0c-3298-4e3d-af1d-b746769c0a2a/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T144740Z&X-Amz-Expires=43200&X-Amz-Signature=8e788bc5340eaee911d8881605f0d54d3afe1ff7251ca6671b3ccd32b25d10c0&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


