---
type: Image
title: icon_AWSBackup
description: null
createdAt: '2025-11-15T15:26:09.937Z'
creationDate: 2025-11-15 18:56
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 4553
width: 486
height: 481
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/9c79e2c1-9cad-4fd4-979c-6e4e90c6201c/raw.svg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T081039Z&X-Amz-Expires=43200&X-Amz-Signature=7ff4c54b60c9e3145964def7817382ab5452ca2ef689a25df8370992c338d004&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


