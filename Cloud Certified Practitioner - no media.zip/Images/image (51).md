---
type: Image
title: image
description: null
createdAt: '2025-11-16T11:28:30.364Z'
creationDate: 2025-11-16 14:58
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 12469
width: 400
height: 400
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/cbde6f8f-fb93-4135-b75b-2b5c3b5a12ac/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080157Z&X-Amz-Expires=43200&X-Amz-Signature=63d21caceb01ddf09ad8aa59b6b9857ac23c4665ca025af946d3b2fdc8388b29&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


