---
type: Image
title: image
description: null
createdAt: '2025-11-18T19:36:06.174Z'
creationDate: 2025-11-18 23:06
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 203664
width: 1680
height: 383
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/3e5ecedb-9d79-4534-8571-b7061475ee82/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T193606Z&X-Amz-Expires=43200&X-Amz-Signature=09c24608e0b95f8d12bad335700b917843b80a558f3ec3dac06470e0e1de2cc2&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


