---
type: Image
title: image
description: null
createdAt: '2025-11-17T12:54:08.226Z'
creationDate: 2025-11-17 16:24
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 79324
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/2d086941-ebb1-43e8-a205-652111d02ad2/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T125408Z&X-Amz-Expires=43200&X-Amz-Signature=4b00c06357dcdbafc54d4b5981f9eb766c30446bb94b271f6a596d7a75eccbd9&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


