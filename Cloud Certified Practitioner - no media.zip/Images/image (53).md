---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:08:47.208Z'
creationDate: 2025-11-16 21:38
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 88022
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/9773e398-ffe4-442d-8590-2fad6d0aaea8/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T180847Z&X-Amz-Expires=43200&X-Amz-Signature=8319fef77a9ac6603ec301bff672e26b59a3af366ef1b805d2ed0a2f7460380f&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


