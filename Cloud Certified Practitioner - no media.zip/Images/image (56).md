---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:19:40.864Z'
creationDate: 2025-11-16 21:49
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 23932
width: 400
height: 400
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/71d442c4-fd94-4079-ac97-b3dca5ddb2c8/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T181941Z&X-Amz-Expires=43200&X-Amz-Signature=1ec9f756afd6bb2db2904824b854c579acb72249873dedcf305db31651b3e93a&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


