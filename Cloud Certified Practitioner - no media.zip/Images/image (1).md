---
type: Image
title: image
description: null
createdAt: '2025-11-08T21:58:43.791Z'
creationDate: 2025-11-09 01:28
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 384277
width: 1680
height: 758
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/f6d68213-dd25-4811-8b1d-fcc40f7a9734/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251109%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251109T114026Z&X-Amz-Expires=43200&X-Amz-Signature=cdbeb67cf1533bd052547f95371a856199cc68ec8454089f0d074f10d159b8ac&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


