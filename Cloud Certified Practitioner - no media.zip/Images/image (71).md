---
type: Image
title: image
description: null
createdAt: '2025-11-17T13:16:18.680Z'
creationDate: 2025-11-17 16:46
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 72032
width: 1356
height: 509
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/c38f55a0-c592-44ea-b7a4-ad165370c72b/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T131619Z&X-Amz-Expires=43200&X-Amz-Signature=faeca8cc62c301b2493a054c975d74ba221b796d5a15c3b503fa816033b7cf4d&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


