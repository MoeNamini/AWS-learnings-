---
type: Image
title: image
description: null
createdAt: '2025-11-17T09:52:19.702Z'
creationDate: 2025-11-17 13:22
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 108551
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/8d6bc5d9-e5bb-4ce7-bbd3-01635789d02a/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T095220Z&X-Amz-Expires=43200&X-Amz-Signature=01c0cf90b024b9eb54fa95f73c6baaaf2bc32280ef7cb35e6bc0149d14590d6c&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


