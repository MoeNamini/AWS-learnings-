---
type: Image
title: image
description: null
createdAt: '2025-11-18T16:45:49.335Z'
creationDate: 2025-11-18 20:15
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 36239
width: 300
height: 300
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/d980e736-5d90-4159-8cbe-c54015806113/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T164550Z&X-Amz-Expires=43200&X-Amz-Signature=b703f058c6b4b19f4885bdd16fdd87377eee85a8a88410eb6447ea4260102491&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


