---
type: Image
title: image
description: null
createdAt: '2025-11-09T18:02:59.231Z'
creationDate: 2025-11-09 21:32
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 672895
width: 1680
height: 1245
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/2fff991a-9ce5-40f0-ae66-c124b2b595bc/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251109%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251109T180259Z&X-Amz-Expires=43200&X-Amz-Signature=cb334cbffc1b5d4de604352216b516ec6a429918178c50765e613a2ab0e3420a&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


