---
type: Image
title: image
description: null
createdAt: '2025-11-10T15:55:26.809Z'
creationDate: 2025-11-10 19:25
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 142348
width: 1148
height: 443
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/eaee6781-f77e-43d2-acca-0a283b60d5f5/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251110%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251110T155527Z&X-Amz-Expires=43200&X-Amz-Signature=52f235ff7935b7b6bb8fcccf6bf8b402ffc708af6fe67f3dcffbddeac37f721c&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


