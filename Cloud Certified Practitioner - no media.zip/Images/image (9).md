---
type: Image
title: image
description: null
createdAt: '2025-11-10T20:42:06.511Z'
creationDate: 2025-11-11 00:12
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 558274
width: 1680
height: 838
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/aecc9f75-442c-497d-8f25-e1c0486da6a7/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251110%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251110T204206Z&X-Amz-Expires=43200&X-Amz-Signature=506a709254169ceef8d44d0dafb207fb0b1f1eaea47868f4434bc304de7a15bb&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


