---
type: Image
title: icon_AmazonRDS
description: null
createdAt: '2025-11-14T17:56:47.184Z'
creationDate: 2025-11-14 21:26
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 3288
width: 481
height: 481
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/24a0a382-293f-42c3-8ddc-4e1d4274822d/raw.svg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101024Z&X-Amz-Expires=43200&X-Amz-Signature=8ffad423e1bf57aeca4a5a53a0955ffb64df95755d7477ecccee59be718349d8&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


