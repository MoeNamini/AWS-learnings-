---
type: Image
title: image
description: null
createdAt: '2025-11-09T17:59:45.780Z'
creationDate: 2025-11-09 21:29
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 187953
width: 1680
height: 860
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/66bd9022-881d-463f-83a7-3ebdecd1cf0f/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251109%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251109T175946Z&X-Amz-Expires=43200&X-Amz-Signature=0b0b26dc02e12971c5032653c81599ea74de872d4ed5d3c8d7deb154a28ad4f1&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


