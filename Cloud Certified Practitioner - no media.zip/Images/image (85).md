---
type: Image
title: image
description: null
createdAt: '2025-11-18T08:24:30.492Z'
creationDate: 2025-11-18 11:54
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 198859
width: 1680
height: 838
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/8202d6a7-74b0-45f2-ace2-e04f21251706/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T082431Z&X-Amz-Expires=43200&X-Amz-Signature=1c193a86826cd6bdb811f0992ae0f484c01370ff5ff7936fac8845c08d56fa63&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


