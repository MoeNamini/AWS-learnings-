---
type: Image
title: icon_AmazonElasticache
description: null
createdAt: '2025-11-15T11:02:46.321Z'
creationDate: 2025-11-15 14:32
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 4996
width: 481
height: 486
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/c61ea045-c128-456c-8b38-8e58591f197b/raw.svg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101024Z&X-Amz-Expires=43200&X-Amz-Signature=74aae010977d19fbcca5e5454cda9cfdcf522954584b26283ece3a9fbc8871fa&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


