---
type: Image
title: icon_AmazonAurora
description: null
createdAt: '2025-11-14T17:59:32.666Z'
creationDate: 2025-11-14 21:29
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 3257
width: 481
height: 481
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/68fd80ce-7deb-4732-bf33-2606e93f44a7/raw.svg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101024Z&X-Amz-Expires=43200&X-Amz-Signature=a2f1327c54081dfca66c9ca96d5e2b18875280c7dbcf6b06ccf2c642ef7755d9&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


