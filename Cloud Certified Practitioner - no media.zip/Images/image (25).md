---
type: Image
title: image
description: null
createdAt: '2025-11-12T12:55:35.018Z'
creationDate: 2025-11-12 16:25
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 415316
width: 1508
height: 599
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/0f6a1359-4993-4442-bf92-c1f263a8257f/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=182ce4875fb26d9063fda3fdaa2f04d32c380cef35e2abb3b2cfb73cbaa4b6d9&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


