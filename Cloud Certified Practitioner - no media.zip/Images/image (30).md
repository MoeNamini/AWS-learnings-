---
type: Image
title: image
description: null
createdAt: '2025-11-15T10:20:47.063Z'
creationDate: 2025-11-15 13:50
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 201839
width: 734
height: 664
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/6fdd1cdb-b5dc-4693-9a90-16a943a2fdc8/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T101024Z&X-Amz-Expires=43200&X-Amz-Signature=492a0fb9abadf9e64144f5bb350fc185365be464c6bf8b41ea8e5ec3694b8cf6&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


