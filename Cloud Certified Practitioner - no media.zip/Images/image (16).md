---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:59:12.487Z'
creationDate: 2025-11-11 14:29
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 262618
width: 1680
height: 676
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/fda6f4ea-da26-4f14-96f9-7501362d288f/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251111%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251111T105913Z&X-Amz-Expires=43200&X-Amz-Signature=c68691255f7a5be690e4f44700e907a74cf325034c0eadf6b9ce28ec3d7fe411&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


