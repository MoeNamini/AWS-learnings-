---
type: Image
title: image
description: null
createdAt: '2025-11-11T15:39:37.921Z'
creationDate: 2025-11-11 19:09
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 782105
width: 2441
height: 1175
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/c338fb7c-fe72-426a-a395-d68fa95c971b/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251111%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251111T153938Z&X-Amz-Expires=43200&X-Amz-Signature=2df77547debad67621c0a4ca77c3dc15efd5682b3a39825cb0a659a435c9f4df&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


