---
type: Image
title: image
description: null
createdAt: '2025-11-15T17:50:42.926Z'
creationDate: 2025-11-15 21:20
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 362555
width: 1512
height: 667
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/71fcf1a8-9185-4f61-978f-5dc07802ca82/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=7866f4b102e1fe7141a545ac0fe79222e739ddeb0d4afcca4e95feb96a516987&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


