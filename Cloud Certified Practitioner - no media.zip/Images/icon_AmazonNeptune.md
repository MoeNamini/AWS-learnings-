---
type: Image
title: icon_AmazonNeptune
description: null
createdAt: '2025-11-15T15:22:40.680Z'
creationDate: 2025-11-15 18:52
tags: []
source: upload
url: null
mimeType: image/svg+xml
fileSize: 4962
width: 486
height: 486
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/2e371183-8647-4125-9566-76a06101dd59/raw.svg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T081039Z&X-Amz-Expires=43200&X-Amz-Signature=f37aa82e65e1ab43a89abdb9ef66c0e1fbde2fb1b9a56b983f7e7448364d2548&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


