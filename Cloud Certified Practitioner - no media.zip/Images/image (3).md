---
type: Image
title: image
description: null
createdAt: '2025-11-09T17:01:09.159Z'
creationDate: 2025-11-09 20:31
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 141591
width: 1652
height: 1475
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/541d8f3a-66b8-4b44-a40c-6880f56c2cca/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251109%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251109T170109Z&X-Amz-Expires=43200&X-Amz-Signature=ab0502f6fcb76ca5a425f2e944c52556ebb95d237b176fadbd58eec22c9b237b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


