---
type: Image
title: image
description: null
createdAt: '2025-11-11T15:43:04.622Z'
creationDate: 2025-11-11 19:13
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 766214
width: 2146
height: 1005
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/bfe4aeaf-b6ae-4d6c-94a9-6edc0a911b6e/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=cbc7271efa5eb069e5ab58310e317e0a1c4be83e3c0a61c0ed60bbc848cfcc81&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


