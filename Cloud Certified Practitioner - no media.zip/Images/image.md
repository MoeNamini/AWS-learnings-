---
type: Image
title: image
description: null
createdAt: '2025-11-09T11:58:26.815Z'
creationDate: 2025-11-09 15:28
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 367522
width: 1148
height: 720
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/6d841d9e-6297-4ee5-a13b-b3290824a94c/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251109%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251109T115827Z&X-Amz-Expires=43200&X-Amz-Signature=c4f6e4167d794f2cddaef851939260e259c01cee8a3e7c3b291c0791a852cb94&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


