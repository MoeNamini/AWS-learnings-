---
type: Image
title: image
description: null
createdAt: '2025-11-11T15:52:59.323Z'
creationDate: 2025-11-11 19:22
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 194345
width: 1680
height: 381
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/30aa0160-99fa-4e71-b21e-b97c20766a51/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=6c834fbd822ce53a281562296cd72b27947103f6f0f5114c21bd47b987b15a6b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


