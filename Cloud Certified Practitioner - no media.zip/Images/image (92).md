---
type: Image
title: image
description: null
createdAt: '2025-11-18T10:56:25.563Z'
creationDate: 2025-11-18 14:26
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 12843
width: 479
height: 479
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/35aba176-a021-40d7-8887-14254f3e4dcc/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T105626Z&X-Amz-Expires=43200&X-Amz-Signature=f8090c9f227199d7b09836e14ad699d63dc369e167508e716cd1642878671f59&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


