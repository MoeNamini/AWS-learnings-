---
type: Image
title: image
description: null
createdAt: '2025-11-16T10:06:53.425Z'
creationDate: 2025-11-16 13:36
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 582579
width: 1403
height: 702
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/f6df2444-cd52-40db-9e2a-7acee0df3e60/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080156Z&X-Amz-Expires=43200&X-Amz-Signature=caff4a994179b57772f9b371e4ebedbea19c581dbe83472f28bbe81080def498&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


