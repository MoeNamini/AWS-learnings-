---
type: Image
title: infographic_servicesManaged-crop
description: null
createdAt: '2025-11-12T09:51:51.960Z'
creationDate: 2025-11-12 13:21
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 24052
width: 764
height: 610
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/682f07c3-b48c-4d6c-a9e7-507224450ef6/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T100000Z&X-Amz-Expires=43200&X-Amz-Signature=9b5a584647ed317e22a1a946a9f76a651b08054789f7d57052f7986c0c929adb&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


