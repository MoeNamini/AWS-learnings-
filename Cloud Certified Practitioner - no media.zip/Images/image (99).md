---
type: Image
title: image
description: null
createdAt: '2025-11-18T16:53:30.789Z'
creationDate: 2025-11-18 20:23
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 12227
width: 479
height: 479
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/71291bcd-d277-4453-b31c-208a8bfddfaa/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T165331Z&X-Amz-Expires=43200&X-Amz-Signature=356740ec7b43a36f25151c0c151f623616a3ed04cc78668e2bb8c810d3c55523&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


