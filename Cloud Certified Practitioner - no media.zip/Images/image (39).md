---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:36:47.017Z'
creationDate: 2025-11-15 22:06
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 77340
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/a1c96f20-c0ba-4395-8166-a9d9c53e0a06/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080156Z&X-Amz-Expires=43200&X-Amz-Signature=84aeb088fb3ccc91b5b27c3fe7a077843aae9660853e495dcff48a59e5370d8b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


