---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:22:59.274Z'
creationDate: 2025-11-15 21:52
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 82571
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/835c4558-e9f0-4cd1-ad8d-251343f48209/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080156Z&X-Amz-Expires=43200&X-Amz-Signature=ef3d0c4312be3b0e9706b3091e63b76c2c6bc9c498960242fddf121d25c5ba3b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


