---
type: Image
title: image
description: null
createdAt: '2025-11-15T18:47:04.368Z'
creationDate: 2025-11-15 22:17
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 100792
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/55250098-4946-43cc-a8f6-a4e6b05a53b1/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251117%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251117T080157Z&X-Amz-Expires=43200&X-Amz-Signature=b88939f15957a1de916e6fdf4b1d676f94f8e53d16b57f602a33dc914275b19b&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


