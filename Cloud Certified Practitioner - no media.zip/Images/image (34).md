---
type: Image
title: image
description: null
createdAt: '2025-11-15T17:36:25.983Z'
creationDate: 2025-11-15 21:06
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 389694
width: 963
height: 652
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/28fdb120-1736-4a9f-a91e-a0844d5b7862/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=9f1aaf1ff01b73591d685787af8c8d12cf6216bce59f561cdf674060a2adaee7&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


