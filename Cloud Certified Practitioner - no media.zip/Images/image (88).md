---
type: Image
title: image
description: null
createdAt: '2025-11-18T09:57:45.406Z'
creationDate: 2025-11-18 13:27
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 143743
width: 1680
height: 458
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/3834b2e8-3ce2-4070-8b43-401626391a51/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T095746Z&X-Amz-Expires=43200&X-Amz-Signature=a0af01593a3c3c0806478b4dd25badc027e0cb22f3e7d0ab2deae4204617adba&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


