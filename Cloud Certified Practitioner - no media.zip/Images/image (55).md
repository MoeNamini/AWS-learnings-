---
type: Image
title: image
description: null
createdAt: '2025-11-16T18:10:57.629Z'
creationDate: 2025-11-16 21:40
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 83830
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/e64ff494-569b-47b3-ac75-a71ca5c47f2b/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T181058Z&X-Amz-Expires=43200&X-Amz-Signature=fbd1a4053cafb61d75f0200f2556a1a70ddcbeb425aca86943f48a43f9320c42&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


