---
type: Image
title: image
description: null
createdAt: '2025-11-18T19:54:04.978Z'
creationDate: 2025-11-18 23:24
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 364503
width: 1586
height: 895
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/1bc441d3-3166-4cba-810d-15aff26f8354/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T195405Z&X-Amz-Expires=43200&X-Amz-Signature=ea728158efd14809aa2faf585dad430c234cc64f281ab0bb8aaf7080abe70366&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


