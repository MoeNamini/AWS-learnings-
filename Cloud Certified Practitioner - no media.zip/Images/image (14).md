---
type: Image
title: image
description: null
createdAt: '2025-11-11T10:31:25.506Z'
creationDate: 2025-11-11 14:01
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 177834
width: 1680
height: 576
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/693ec012-eb84-4228-914f-ac52503580f3/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251111%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251111T103126Z&X-Amz-Expires=43200&X-Amz-Signature=d03db8eab63e6e3ba7ca1cfeffaba7ed667d30943e2501b98017cce9e44111c1&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


