---
type: Image
title: image
description: null
createdAt: '2025-11-18T10:52:19.910Z'
creationDate: 2025-11-18 14:22
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 89786
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/d46def91-9756-440e-97cc-7ce3b00daa40/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T105221Z&X-Amz-Expires=43200&X-Amz-Signature=71f06bcd19d45899dc6c0c2462a6b85f8c3401a8e701aef76a40df23d7cd3c59&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


