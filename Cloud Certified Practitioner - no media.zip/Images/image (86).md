---
type: Image
title: image
description: null
createdAt: '2025-11-18T08:49:02.527Z'
creationDate: 2025-11-18 12:19
tags: []
source: upload
url: null
mimeType: image/png
fileSize: 87638
width: 512
height: 512
---


Media: ![Image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/8cafc35d-ea73-45f9-85fa-63dcb4dc3cd1/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T084903Z&X-Amz-Expires=43200&X-Amz-Signature=3cf8b26f413a26df3c831f5297857db66d9235f74bc38c0baebe4139e1164066&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


