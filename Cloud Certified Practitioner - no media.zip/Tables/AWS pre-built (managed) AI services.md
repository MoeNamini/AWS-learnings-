---
type: Table
title: AWS pre-built (managed) AI services
description: null
icon: null
tags: []
coverImage: null
---

| **Service**                   | **Category / Use Case**              | **What It Does / Key Features**                                                                                                                                                               |
| :---------------------------- | :----------------------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Amazon Bedrock**            | Generative AI                        | Gives access to foundation models (LLMs, FMs) so you can build generative AI apps (chatbots, summarization, etc.) without managing your own model infrastructure. (Amazon Web Services, Inc.) |
| **Amazon Q**                  | Generative AI / Assistant            | An AI-powered assistant for work, built on top of Amazon’s foundation models, that can answer questions, summarize documents, help with cloud-ops. (Wikipedia)                                |
| **Amazon Comprehend**         | Language / NLP                       | Natural Language Processing: sentiment analysis, entity recognition, topic modeling, language detection. (Medium)                                                                             |
| **Amazon Comprehend Medical** | Language / Healthcare NLP            | Extracts medical information from clinical text: medical conditions, medications, relationships, PHI (protected health info). (AWS Documentation)                                             |
| **Amazon Lex**                | Conversational Interfaces / Chatbots | Build chatbots / conversational UI (text + voice). Uses NLP to understand intent, manage dialog. (AWS Documentation)                                                                          |
| **Amazon Polly**              | Speech (Text → Speech)               | Converts text into realistic, lifelike speech (supports many languages / voices). (Amazon Web Services, Inc.)                                                                                 |
| **Amazon Transcribe**         | Speech (Speech → Text)               | Automatically converts speech audio into text (real-time & batch). (Amazon Web Services, Inc.)                                                                                                |
| **Amazon Translate**          | Language Translation                 | Neural machine translation between many languages. (Amazon Web Services, Inc.)                                                                                                                |
| **Amazon Rekognition**        | Computer Vision                      | Pre-trained image/video analysis: object recognition, face detection, moderation, text in images. (Wikipedia)                                                                                 |
| **Amazon Textract**           | Document / Text Extraction           | Extracts text, tables, and forms from scanned documents, PDFs, images. (Amazon Web Services, Inc.)                                                                                            |
| **Amazon Kendra**             | Search / Knowledge Retrieval         | Enterprise search powered by ML: you can ask questions in natural language and retrieve relevant content from many sources. (AWS Documentation)                                               |
| **Amazon Forecast**           | Forecasting / Time Series            | Predicts future business metrics (demand, sales, capacity) using ML-driven forecasting models. (Medium)                                                                                       |
| **Amazon Personalize**        | Recommendation / Personalization     | Provides real-time personalized recommendations (product, content, etc.) using ML. (kravigupta.in)                                                                                            |
| **Amazon Fraud Detector**     | Fraud / Anomaly Detection            | Detects fraudulent activity using ML models trained on your data + Amazon’s fraud expertise. (AWS Documentation)                                                                              |
| **Amazon Augmented AI (A2I)** | Human-in-the-loop / Labeling         | Lets you build workflows where human reviewers validate or correct ML predictions (for higher accuracy or trust). (AWS Documentation)                                                         |


### Notes


