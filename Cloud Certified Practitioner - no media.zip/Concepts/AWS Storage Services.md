---
type: Concept
title: 'AWS Storage Services '
modificationDate: 2025-11-18 13:40
tags: [AWS, IT]
relatedProject: [AWS, Cloud Certified Practitioner]
relatedIdeas: [IT common knowledge, AWS Workflows]
---

AWS offers a comprehensive portfolio of storage services that fall into three main categories: **Object**, **Block**, and **File** storage, plus services dedicated to **Hybrid Cloud** and **Data Transfer**.

Here is a breakdown of all the storage services, including those integrated into or supporting other services.

## 🗄️ AWS Storage Service Types

---

### 1. Object Storage (Unstructured Data)

Object storage is designed for massive scalability, durability, and web access, treating data as self-contained objects in a flat structure (buckets).

- **Amazon S3 (Simple Storage Service):** The primary object storage service. It includes several **Storage Classes** that are technically different forms of storage within S3:

    - **S3 Standard:** For frequently accessed data.

    - **S3 Standard-IA (Infrequent Access):** For less frequently accessed data that needs millisecond retrieval.

    - **S3 One Zone-IA:** For infrequently accessed, non-critical data stored in a single Availability Zone (AZ).

    - **S3 Glacier Instant Retrieval:** For archival data that needs to be instantly accessible.

    - **S3 Glacier Flexible Retrieval (formerly S3 Glacier):** For long-term archives with retrieval times from minutes to hours.

    - **S3 Glacier Deep Archive:** The lowest-cost option for archives retrieved once or twice per year.

    - **S3 Intelligent-Tiering:** Automatically moves data between access tiers based on usage patterns to optimize cost.

    - **S3 Express One Zone:** A new, high-performance class for single-digit millisecond latency storage for compute-intensive workloads within a single AZ.

    - **S3 on Outposts:** Object storage service running on your on-premises AWS Outposts hardware.

---

### 2. Block Storage (Low-Latency, High-Performance)

Block storage is used by operating systems and databases, treating storage as raw blocks that require low-latency access.

- **Amazon EBS (Elastic Block Store):** **Persistent** block-level storage volumes attached to a single EC2 instance. It offers different volume types (General Purpose SSD, Provisioned IOPS SSD, etc.) to meet specific performance needs.

- **EC2 Instance Store:** **Non-persistent** block storage directly attached to the physical host machine of an EC2 instance. It provides extremely high I/O performance but data is lost when the instance is stopped or terminated.

- **Amazon Elastic Volumes:** Although not a separate service, this is a feature of EBS that allows you to dynamically change the volume type, size, or IOPS capacity of an EBS volume with minimal downtime.

---

### 3. File Storage (Shared Access)

File storage is used for workloads that need to be shared across multiple compute instances using a standard file system protocol.

- **Amazon EFS (Elastic File System):** A simple, serverless, **elastic NFS** (Network File System) for Linux-based workloads that can be shared across multiple EC2 instances and AZs.

- **Amazon FSx Family:** A managed service for specific commercial and open-source file systems:

    - **FSx for Windows File Server (SMB):** For lift-and-shift of Windows-based applications requiring the SMB protocol and Active Directory integration.

    - **FSx for Lustre:** Optimized for high-performance computing (HPC) and fast-processing workloads like machine learning.

    - **FSx for NetApp ONTAP:** Provides the rich data management features (snapshots, replication, deduplication) of NetApp's ONTAP file system.

    - **FSx for OpenZFS:** Provides a fully managed OpenZFS file system, great for I/O-intensive workloads.

---

### 4. Hybrid Cloud & Data Transfer

These services bridge your on-premises environment with AWS cloud storage or facilitate the physical movement of large data sets.

- **AWS Storage Gateway:** A family of services that provide on-premises applications with access to cloud storage via a local appliance (VM, physical, or container):

    - **File Gateway:** Integrates S3 or FSx with on-premises applications using the NFS and SMB protocols.

    - **Volume Gateway:** Presents cloud-backed storage as **iSCSI volumes** to on-premises servers (Cached or Stored mode).

    - **Tape Gateway:** Provides a virtual tape library (VTL) to replace physical tape infrastructure, archiving backups to S3 Glacier.

- **AWS Snow Family:** Physical devices used for transferring petabytes of data into and out of AWS and for running edge computing applications:

    - **AWS Snowcone:** Small, rugged, and secure device for edge computing and data transfer.

    - **AWS Snowball Edge (Storage Optimized / Compute Optimized):** Larger devices for massive data migration and running local compute/storage workloads in remote environments.

    - **AWS Snowmobile:** A massive 45-foot shipping container pulled by a semi-trailer truck for exabyte-scale data transfer.

- **AWS DataSync:** A data transfer service that simplifies, automates, and accelerates moving large amounts of data between on-premises storage and AWS storage services (S3, EFS, FSx).



The video below gives an overview of the main AWS storage services, including S3, EBS, and EFS. [AWS Storage Explained | EBS vs EFS vs S3 | AWS Training](https://www.youtube.com/watch?v=C9StEK6EMQY)

[http://googleusercontent.com/youtube_content/18](http://googleusercontent.com/youtube_content/18)

[This table combines the most important services and dimensions for quick differentiation.](Tables/This%20table%20combines%20the%20most%20important%20services%20and%20dimensions%20for%20quick%20differe.md)

[aws storages - NotebokkLM](Tables/aws%20storages%20-%20NotebokkLM.md)

## EBS Snapshots Service

| **Requirement**                                                                  | **EBS Snapshots / Feature**                             | **Explanation**                                                                                                                                                                                                                                                                                                                                                     |
| :------------------------------------------------------------------------------- | :------------------------------------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Create regular data backups**                                                  | **EBS Snapshots** (Automated via AWS DLM or AWS Backup) | Snapshots are the native backup mechanism for EBS volumes. Automation tools allow for policy-driven, scheduled backups.                                                                                                                                                                                                                                             |
| **Create duplicate environments for testing**                                    | **Snapshot Restore/Copy**                               | A snapshot is a perfect, point-in-time copy of the data. You can restore this snapshot to a **new EBS volume** in seconds, which can then be attached to a test EC2 instance to quickly create a duplicate of the production environment.                                                                                                                           |
| **Create a disaster recovery strategy**                                          | **Cross-Region Snapshot Copy**                          | Snapshots can be easily copied to a different AWS Region, providing the necessary **geographic redundancy** for a robust disaster recovery plan.                                                                                                                                                                                                                    |
| **Create full or incremental backups without impacting application performance** | **Incremental Nature & Background Operation**           | The first snapshot is a full copy, but subsequent snapshots are **incremental** (they only save the blocks that have changed since the last snapshot). They are taken while the volume is in use and are stored asynchronously in Amazon S3, minimizing impact on the running application's performance.                                                            |
| **Provide cost-effective for long-term storage**                                 | **Incremental Storage & S3 Integration**                | Because snapshots are incremental, you only pay for the blocks of data that have changed, which significantly lowers storage costs over time compared to storing full copies repeatedly. Additionally, AWS offers **EBS Snapshot Archive**, a storage tier integrated with S3, providing up to 75% savings for snapshots that need to be retained for over 90 days. |
