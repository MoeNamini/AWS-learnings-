---
type: Concept
title: AWS Shared Responsibility Model - SRM
modificationDate: 2025-11-18 14:29
tags: [AWS]
relatedProject: []
relatedIdeas: []
---







## Databases

**Fully managed services**

---

For fully managed services, AWS handles nearly all operational tasks like provisioning, scaling, patching, backups, performance optimization, and security patches. AWS also provides built-in monitoring and metrics. Fully managed AWS database services only require customers to be responsible for designing data structures and managing access controls.


---

![infographic_servicesFullyManaged-crop](https://capacities-files.s3.eu-central-1.amazonaws.com/private/cae5163c-29f0-4d18-934c-f6c4e75a956c/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=c8c173d7245adc11664c516df1d8fea7a2c18674e2e7c6d945e3f3939a3665f0&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)
[infographic_servicesFullyManaged-crop](Images/infographic_servicesFullyManaged-crop%20(1).md)

---

**Managed services**

---

With managed database services, AWS handles routine tasks like backups, patching, and hardware provisioning while customers are responsible for database configuration, query optimization, and performance tuning decisions.


---

![infographic_servicesManaged-crop](https://capacities-files.s3.eu-central-1.amazonaws.com/private/3954122c-43be-4b32-83f9-14c94910bbeb/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=eff3b8e29cb18ddc00c3e4d54396c8fc1ac61556f7818bd486ffe804b458d8a3&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)
[infographic_servicesManaged-crop](Images/infographic_servicesManaged-crop%20(1).md)

---



**Unmanaged services**

---

With unmanaged databases, customers are responsible for installation, configuration, patching, maintenance tasks, database security, backups, high availability setup, and performance optimization. An example of an unmanaged database in AWS would be a database management system like MySQL installed directly on an Amazon Elastic Compute Cloud (Amazon EC2) instance.


---

![infographic_servicesUnmanaged-crop](https://capacities-files.s3.eu-central-1.amazonaws.com/private/9c5ef7dd-2bd6-45ff-812f-74fdfb265326/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T095959Z&X-Amz-Expires=43200&X-Amz-Signature=b81c00d1add80f267c65453522b8e9a2257186288f18a6238714d7d56458e57f&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)
[infographic_servicesUnmanaged-crop](Images/infographic_servicesUnmanaged-crop%20(1).md)

---

## Security 

### AWS shared responsibility model

Cloud security is a shared responsibility between customers and AWS. Let's examine this relationship using the AWS shared responsibility model.

**Customers: Security** ***in*** **the cloud**

When using AWS services, customers maintain complete control over their content. As a result, customers are responsible for securing everything they create and manage in the AWS Cloud. This includes the following:

- Managing the security of data, systems, and applications

- Deciding what data and workloads to store or run in AWS

- Determining which AWS services to use

- Controlling who has access to environments and resources

**AWS: Security** ***of*** **the cloud**

AWS is responsible for security *of* the cloud. AWS operates, manages, and controls the components at all layers of the infrastructure. This includes securing the following:

- The foundational software that powers AWS services

- The virtualization layer

- The hardware and global infrastructure that supports the data centers from which services operate. This includes protection for AWS Regions, Availability Zones, and edge locations.

![image](https://capacities-files.s3.eu-central-1.amazonaws.com/private/220bfb1b-ec8f-49db-aecc-a23ecc594b06/raw.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251118%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251118T105924Z&X-Amz-Expires=43200&X-Amz-Signature=27eaced6d0398ee236e273d955b5c8344e76d0917ea15c394980523bb0f24c8f&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)
[image](Images/image%20(28).md)

### AWS security controls

AWS offers multiple security mechanisms to protect your cloud resources. These controls can help you do the following:

- *Prevent* security incidents through proper permission and access management.

- *Protect* networks, applications, and data.

- *Detect and respond* to security incidents as they occur.

