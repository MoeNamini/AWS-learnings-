---
type: File
title: genai_development_paths
description: null
icon: null
createdAt: '2025-11-16T11:16:59.801Z'
creationDate: 2025-11-16 14:46
modificationDate: 2025-11-16 14:47
tags: []
mimeType: text/html
fileSize: 17927
---


Media: ![File](https://capacities-files.s3.eu-central-1.amazonaws.com/private/1c3770bd-c3f9-4831-ac2f-98ec4df80bcd/raw.html?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Credential=AKIA5VTNRR6EBR56K2NK%2F20251116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Date=20251116T111700Z&X-Amz-Expires=43200&X-Amz-Signature=5a51a1060cae694505d86dc09b30278ffe2fa42319258fc5f4165581b00bebc7&X-Amz-SignedHeaders=host&x-amz-checksum-mode=ENABLED&x-id=GetObject)


